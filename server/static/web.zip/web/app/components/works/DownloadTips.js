/**
 * Created by xijinling on 2017/7/23.
 */
import React, {Component} from 'react'

class DownloadTips extends Component {
  render() {
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent)
    const url = isIOS ? 'https://itunes.apple.com/cn/app/%E7%A9%BA%E4%B8%AD%E7%BB%BF%E6%B4%B2/id1231916319?mt=8' : ''
    return <div className="m-download-tips">
      <div className="logo"></div>
      <div className="text">{`{发现 / 新坐标}`}</div>
      <a className="button" href={url}>打开</a>
    </div>
  }
}

export default DownloadTips