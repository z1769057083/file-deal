import React, { Component, PropTypes } from 'react'
import { connect } from 'react-redux'
import {bindActionCreators } from 'redux'
import Header from 'components/Header'
import CornerBar from 'components/CornerBar'
import UpgradeTips from 'components/UpgradeTips'
import UserHeader from 'components/UserHeader'
import * as userActions from 'actions/user'

class User2 extends Component {
  constructor(props) {
    super(props)
    this.state = {
      pending: true,
      init: false,
      userInfo: {}
    }
  }
  
  componentDidMount() {
    const {id, oasisId} = this.props.params
    this.getUserInfo(id, oasisId)
  }
  
  componentWillReceiveProps(props) {
    const {id, oasisId} = props.params
    const {prevId, prevOasisId} = this.props.params
    if (id !== prevId || oasisId != prevOasisId) {
      this.getUserInfo(id, oasisId)
    }
  }
  
  getUserInfo(id, oasisId) {
    const userId = oasisId || id
    const method = oasisId ? 'loadUserInfoByOasisId' : 'loadUserInfo'

    const success = (state) => {
      this.setState({
        pending: false,
        init: true,
        userInfo: state.response.data
      })
    }
    const fail = () => {
      this.setState({
        pending: false,
        init: true,
        userInfo: {}
      })
    }
    this.props.actions[method](userId, success, fail)
  }
  
  render() {
    const {init, userInfo} = this.state
    const userId = parseInt(userInfo.ownerId)
    
    return (
      <div className="m-user m-user-new m-header--wrap">
        <Header />
        <UpgradeTips width={1030}/>
        {init ? <UserHeader
          userInfo={userInfo}
          userId={userId}
          location={this.props.location}
          params={this.props.params} />: null}
        {init ? this.props.children: null}
        <CornerBar />
      </div>
    )
  }
}

function mapStateToProps (state) {
  return {
  }
}

function mapDispatchToProps (dispatch) {
  return {
    actions: bindActionCreators({
      loadUserInfo: userActions.loadUserInfo,
      loadUserInfoByOasisId: userActions.loadUserInfoByOasisId,
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(User2)
