import React, { Component, PropTypes } from 'react'

class WorksItem extends Component {
  render() {
    return (
      <div className="m-works-item">
        <div className="name">
          <select defaultValue={this.props.name} className="m-text">
            <option value="项目名称">项目名称</option>
            <option value="设计者">设计者</option>
            <option value="设计地点">设计地点</option>
            <option value="项目面积">项目面积</option>
            <option value="建设时间">建设时间</option>
          </select>
        </div>
        <div className="value">
          <input type="text" className="m-text" defaultValue={this.props.value} />
        </div>
        {this.props.canDelete ?
          <div className="action">
            <div className="icon icon-delete"></div>
          </div>: null
        }
      </div>
    )
  }
}

WorksItem.propTypes = {

}

export default WorksItem
