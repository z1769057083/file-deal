import React, { Component, PropTypes } from 'react'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import AuthSingleCard from 'components/AuthSingleCard'

class TeamVerified extends Component {
  render() {
    return (
      <AuthSingleCard closeAuthModal={this.props.closeAuthModal}>
        <div className="card-main team-verified">
          <div className="header">备案</div>
          <div className="main">
            <p className="account">{this.props.name}</p>
            <div className="icon icon-success"></div>
            <p className="p1">indie备案成功！</p>
          </div>
          <div className="footer flexbox single-button">
            <a href="/" className="btn btn-primary">首页</a>
          </div>
        </div>
      </AuthSingleCard>
    )
  }
}

function mapStateToProps(state, ownProps) {
  return {
    name: state.global.getIn(['authWindowPrams', 'name']),
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(TeamVerified)
