import React, { Component, PropTypes } from 'react'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import AuthSingleCard from 'components/AuthSingleCard'
import classNames from 'classnames'
import PhoneInput from 'components/forms/PhoneInput'
import {
  sendCode,
  verifyCode,
  updateCode,
  updateCodePassword,
  updatePhonePassword
} from 'actions/register'
import {
  LOGIN_USER_START,
  RETRIEVE_TEAM_START,
  RETRIEVE_USER,
  REGISTER_USER_START,
} from 'config/authPage'
import {
  Form,
  Input,
  Button
} from 'react-validation/lib/build/validation.rc'
import {SubmitDecorator} from 'decorators'
import validator from 'validator'

const COUNT_DOWN_SECONDS = 60
class PasswordRetrieveStart extends Component {
  constructor(props, context) {
    super(props, context)
    this.state = {
      type: 'personal',
      phone: '',
      code: '',
      email: '',
      codeSent: false,
      countDown: false,
      seconds: 0,
      interval: null
    }
    this.handleNext = this.handleNext.bind(this)
    this.handleCode = this.handleCode.bind(this)
    this.sendQRCode = this.sendQRCode.bind(this)
  }
  handlePhone(value) {
    this.setState({
      phone: value
    })
  }
  handleCode(e) {
    this.setState({
      code: e.target.value,
    })
  }
  sendQRCode() {
    const {phone, seconds} = this.state
    if (!validator.isMobilePhone(phone.replace(/ /g, ''), 'zh-CN')) {
      return
    }
    if (seconds > 0) {
      return
    }
    this.countDown()
    this.props.actions.sendCode({
      phone,
      channel: 1,
      afterSuccess: () => {
        this.props.actions.updatePhonePassword(phone)
      }
    })
  }
  countDown() {
    this.setState({
      codeSent: true,
      seconds: COUNT_DOWN_SECONDS
    })
    this.state.seconds = COUNT_DOWN_SECONDS
    this.state.interval = setInterval(() => {
      const seconds = this.state.seconds - 1
      if (seconds >= 0) {
        this.setState({
          seconds: this.state.seconds - 1
        })
      } else {
        clearInterval(this.state.interval)
      }
    }, 1000)
  }
  handleNext(event) {
    event.preventDefault()

    const {phone, code} = this.state
    this.props.actions.verifyCode({
      phone,
      verifyCode: code,
      channel: 1,
      afterSuccess: () => {
        this.props.actions.updatePhonePassword(phone)
        this.props.actions.updateCodePassword(code)
        this.props.switchPage(RETRIEVE_USER)
      },
      afterError: (state) => {
        this.props.showError(state.message || '验证失败')
      }
    })
  }
  render() {
    const {seconds} = this.state
    return (
      <AuthSingleCard closeAuthModal={this.props.closeAuthModal}>
        <Form className="card-main password-retrieve-start modal-form"
              ref={c => {this.form = c}}
              onSubmit={this.handleNext}
          >
          <div className="header">密码找回</div>
          <div className="main">
            <div className="personal">
              <div className="input phone">
                <div className="m-input-with-qrcode">
                  <PhoneInput
                    className="m-text"
                    containerClassName="field-wrapper"
                    errorClassName="error"
                    value={this.state.phone}
                    placeholder="手机"
                    name="phone"
                    onChange={(value) => this.handlePhone(value)}
                    validations={['required', 'phone']}
                    />
                  <div className="qr-code"
                       onClick={this.sendQRCode}>
                    {seconds > 0 ? `${seconds}s` : '验证码'}
                  </div>
                </div>
              </div>
              <div className="input m-input-with-msg">
                <Input type="text"
                       className="m-text"
                       containerClassName="field-wrapper"
                       errorClassName="error"
                       onChange={this.handleCode}
                       value={this.state.code}
                       validations={['required']}
                       placeholder="验证码"
                  />
              </div>
              <div className="bottom flexbox">
                <span className="register" onClick={() => {this.props.switchPage(REGISTER_USER_START)}}>注册帐号</span>
                <div className="has-account">
                  已有帐号？<span className="login clickable" onClick={() => {this.props.switchPage(LOGIN_USER_START)}}>登录</span>
                </div>
              </div>
            </div>
          </div>
          <div className="footer flexbox single-button btn-footer field-wrapper">
            <Button
              type="submit"
              className="btn btn-primary">
              下一步
            </Button>
            {this.props.error && <div className="form-error active">{this.props.error}</div>}
          </div>
        </Form>
      </AuthSingleCard>
    )
  }
}

PasswordRetrieveStart.propTypes = {
  switchPage: PropTypes.func
}

function mapStateToProps(state) {
  return {}
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      verifyCode,
      sendCode,
      updateCode,
      updatePhonePassword,
      updateCodePassword}, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(
  SubmitDecorator(PasswordRetrieveStart)
)
