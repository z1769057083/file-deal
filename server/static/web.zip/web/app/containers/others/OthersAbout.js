import React, { Component, PropTypes } from 'react'
import { connect } from 'react-redux'
import About from 'components/About'

class OthersAbout extends Component {
  render() {
    return (
      <div className="m-others-about">
        <About />
      </div>
    )
  }
}

function mapStateToProps (state) {
  return {}
}

OthersAbout.propTypes = {

}

export { OthersAbout }
export default connect(mapStateToProps)(OthersAbout)
