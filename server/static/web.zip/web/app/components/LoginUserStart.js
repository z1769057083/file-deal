import React, { Component, PropTypes } from 'react'
import AuthDoubleCard from 'components/AuthDoubleCard'
import PhoneInput from 'components/forms/PhoneInput'
import Spinner from 'components/global/Spinner'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import {
  LOGIN_TEAM_START,
  REGISTER_USER_START,
  RETRIEVE_USER_START
} from 'config/authPage'
import {loginUser} from 'actions/auth'
import * as globalActions from 'actions/global'
import {
  Form,
  Input,
  Button
} from 'react-validation/lib/build/validation.rc'
import {SubmitDecorator} from 'decorators'
import Storage from 'util/storage'

class LoginUserStart extends Component {
  constructor(props, context) {
    super(props, context)
    this.state = {
      phone: '',
      pwd: '',
      loading: false,
    }
    this.onSubmit = this.onSubmit.bind(this)
    this.phoneChanged = this.phoneChanged.bind(this)
    this.pwdChanged = this.pwdChanged.bind(this)
    this.showError = this.showError.bind(this)
    this.afterSuccess = this.afterSuccess.bind(this)
    this.weibo = this.weibo.bind(this)
  }

  phoneChanged(phone) {
    this.setState({
      phone
    })
  }

  pwdChanged(e) {
    this.setState({
      pwd: e.target.value
    })
  }

  afterSuccess({response}) {
    window.setTimeout(() => {
      this.setState({loading: false})
      this.forceUpdate()
      this.props.actions.addToast({
        type: 'black',
        message: '已成功登录',
        pic: this.props.avatar,
        timeout: 3000,
      })
      this.props.closeAuthModal()
      Storage.set('token', response.data.token)
    }, 1000)
  }

  showError() {
    this.setState({
      loading: false,
    })
    this.props.showError('用户名或密码错误')
  }

  onSubmit(event) {
    event.preventDefault()

    const {phone, pwd} = this.state
    this.setState({loading: true})
    this.props.actions.loginUser({
      phone,
      pwd,
      afterSuccess: this.afterSuccess,
      afterError: this.showError
    })
  }

  weibo() {
    window.open('https://api.weibo.com/oauth2/authorize?client_id=3713629030&response_type=code&' +
      'redirect_uri=http://www.airoases.com/api/v1/open/auth/wblogin')
  }

  render() {
    return (
      <AuthDoubleCard closeAuthModal={this.props.closeAuthModal}>
        <div className="nav">
          <div className="item active">个人</div>
          <div className="item"
               onClick={() => {this.props.switchPage(LOGIN_TEAM_START)}}>indie
          </div>
        </div>
        <Form className="user modal-form"
              ref={c => {this.form = c}}
              onSubmit={this.onSubmit}
          >
          <div className="input m-input-with-msg">
            <PhoneInput className="m-text"
                        containerClassName="field-wrapper"
                        errorClassName="error"
                        onChange={this.phoneChanged}
                        value={this.state.phone}
                        placeholder="手机"
                        name="phone"
                        validations={['required', 'phone']}
              />
          </div>
          <div className="input">
            <Input type="password"
                   name="password"
                   className="m-text"
                   containerClassName="field-wrapper"
                   errorClassName="error"
                   onChange={this.pwdChanged}
                   value={this.state.pwd}
                   validations={['required', 'password']}
                   placeholder="密码"
              />
          </div>
          <div className="forget-register flexbox">
            <div className="forget clickable" onClick={() => {this.props.switchPage(RETRIEVE_USER_START)}}>忘记密码</div>
            <div className="register clickable" onClick={() => {this.props.switchPage(REGISTER_USER_START)}}>用户注册</div>
          </div>
          <div className="field-wrapper btn-footer">
            <Button
              type="submit"
              className="btn btn-primary btn-block">
              {this.state.loading ? <Spinner /> : '登录'}
            </Button>
            {this.props.error && <div className="form-error active">{this.props.error}</div>}
          </div>

          {/*<div className="p1">第三方登录</div>*/}
          {/*<ThirdLogin afterSuccess={this.props.closeAuthModal} />*/}
        </Form>
      </AuthDoubleCard>
    )
  }
}

LoginUserStart.propTypes = {
  switchPage: PropTypes.func
}

function mapStateToProps(state, ownProps) {
  return {
    avatar: state.auth.get('pic')
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      loginUser,
      addToast: globalActions.addToast
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(
  SubmitDecorator(LoginUserStart)
)
