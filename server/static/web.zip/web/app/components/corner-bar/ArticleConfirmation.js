import React, {PropTypes} from 'react'
import Modal from 'react-modal'
import {connect} from 'react-redux'

const customStyles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    overflow: 'scroll',
    zIndex: 300
  },
  content: {
    border: 'none',
    padding: '0px 0 20px 0',
    position: 'relative',
    borderRadius: '6px',
    width: '400px',
    top: 150,
  }
}
class ArticleConfirmation extends React.Component {
  render() {
    const {isOpen, onRequestClose, giveUp, article} = this.props
    const filter = item => item.get('pic') !== ''
    const data = article.get('articles').filter(filter)
    const url = data.get('pic') || '/assets/images/default_pic.svg'
    const styles = {background: `url(${url}) no-repeat center center #F1F1F1`}
    return (
      <Modal
        isOpen={isOpen}
        onRequestClose={onRequestClose}
        style={customStyles}
        overlayClassName="modal-new-pin"
        contentLabel="Modal">
        <div className="header white-version">
          <div className="title">签出手贴</div>
          <div className="icon icon-close-white" onClick={onRequestClose} />
        </div>
        <div className="main">
          <div className="m-multi-modal">
            <div className="modal-article-success">
              <div className="article__img" style={styles} />
              <div className="article__tips">
                如果签出该手贴，无法恢复或找回，请慎重操作
              </div>
              <div
                className="article__view btn btn-primary"
                onClick={giveUp}>
                放弃
              </div>
              <div className="article__ignore btn" onClick={onRequestClose}>
                签出
              </div>
            </div>
          </div>
        </div>
        <div className="footer" />
      </Modal>
    )
  }
}

ArticleConfirmation.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  onRequestClose: PropTypes.func.isRequired,
  giveUp: PropTypes.func.isRequired
}

const mapStateToProps = state => ({
  article: state.article
})

export default connect(mapStateToProps)(ArticleConfirmation)
