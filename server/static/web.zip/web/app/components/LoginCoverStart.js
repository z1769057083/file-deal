import React, { Component, PropTypes } from 'react'
import AuthCover from 'components/AuthCover'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import {
  LOGIN_USER_START,
} from 'config/authPage'
import {loginUser} from 'actions/auth'
import * as globalActions from 'actions/global'
import {
  Form,
  Input,
  Button
} from 'react-validation/lib/build/validation.rc'
import {SubmitDecorator} from 'decorators'

class LoginCoverStart extends Component {
  constructor(props, context) {
    super(props, context)
    this.state = {
      phone: '',
      pwd: '',
      loading: false,
    }
    this.onSubmit = this.onSubmit.bind(this)
    this.phoneChanged = this.phoneChanged.bind(this)
    this.pwdChanged = this.pwdChanged.bind(this)
    this.showError = this.showError.bind(this)
    this.afterSuccess = this.afterSuccess.bind(this)
    this.weibo = this.weibo.bind(this)
    this.handleLogin = this.handleLogin.bind(this)
  }

  phoneChanged(phone) {
    this.setState({
      phone
    })
  }

  pwdChanged(e) {
    this.setState({
      pwd: e.target.value
    })
  }

  afterSuccess() {
    window.setTimeout(() => {
      this.setState({loading: false})
      this.forceUpdate()
      this.props.actions.addToast({
        type: 'black',
        message: '已成功登录',
        pic: this.props.avatar,
        timeout: 3000,
      })
      this.props.closeAuthModal()
    }, 1000)
  }

  showError() {
    this.setState({
      loading: false,
    })
    this.props.showError('用户名或密码错误')
  }

  onSubmit(event) {
    event.preventDefault()

    const {phone, pwd} = this.state
    this.setState({loading: true})
    this.props.actions.loginUser({
      phone,
      pwd,
      afterSuccess: this.afterSuccess,
      afterError: this.showError
    })
  }

  weibo() {
    window.open('https://api.weibo.com/oauth2/authorize?client_id=3713629030&response_type=code&' +
      'redirect_uri=http://www.airoases.com/api/v1/open/auth/wblogin')
  }

  handleLogin() {
    this.props.closeAuthModal()
    this.props.actions.showAuthWindow(LOGIN_USER_START)
  }

  render() {
    return (
      <AuthCover closeAuthModal={this.props.closeAuthModal}>
        <div className="btn__wrap">
          <div className="btn__login" onClick={this.handleLogin}>登录</div>
          <div className="btn__close" onClick={this.props.closeAuthModal}>乱入</div>
        </div>
      </AuthCover>
    )
  }
}

LoginCoverStart.propTypes = {
  switchPage: PropTypes.func
}

function mapStateToProps(state, ownProps) {
  return {
    avatar: state.auth.get('pic')
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      loginUser,
      addToast: globalActions.addToast,
      showAuthWindow: globalActions.showAuthWindow,
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(
  SubmitDecorator(LoginCoverStart)
)
