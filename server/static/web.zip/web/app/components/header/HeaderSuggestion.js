/**
 * Created by xijinling on 2017/7/19.
 */
import React, {Component, PropTypes} from 'react'
import {bindActionCreators} from 'redux'
import {connect} from 'react-redux'
import {getSearchHistory} from 'util/local'
import cx from 'classnames'

class HeaderSuggestion extends Component {
  render() {
    const {suggestion, keyword, isOpen} = this.props
    const data = keyword === '' && isOpen ? getSearchHistory() : suggestion
    return (
      <div className={cx('suggestion--wrap', {'suggestion--active': isOpen})}>
        <div className="suggestion__item suggestion__item--top">
          <div className="suggestion__item--tips">近期搜索</div>
        </div>
        {data.map((word, key) => {
          return (
            <div className="suggestion__item" key={key}>
              <a
                href={`/search?word=${word}`}
                dangerouslySetInnerHTML={{__html: word.replace(keyword, `<b>${keyword}</b>`)}}
                className="suggestion__item--inner">
              </a>
            </div>
          )
        })}
      </div>
    )
  }
}

function mapStateToProps(state) {
  return {
    isOpen: state.search.get('isOpen'),
    suggestion: state.search.get('suggestion'),
    keyword: state.search.get('keyword')
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({}, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(HeaderSuggestion)
