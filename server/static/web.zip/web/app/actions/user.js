/**
 * User/:id actions
 */
import { CALL_API, CHAIN_API } from 'middleware/api'

export const LOAD_USER_INFO_SUCCESS = Symbol('LOAD_USER_INFO_SUCCESS')
export function loadUserInfo(userId, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'get',
      path: '/api/v1/open/oasis/homepage',
      query: {
        owner: userId
      },
      successType: LOAD_USER_INFO_SUCCESS,
      afterSuccess,
      afterError
    }
  }
}

/**
 * 根据绿洲ID获取用户信息
 */
export function loadUserInfoByOasisId(oasisId, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'get',
      path: '/api/v1/open/oasis/homepage',
      query: {
        oasescode: oasisId
      },
      successType: LOAD_USER_INFO_SUCCESS,
      afterSuccess,
      afterError
    }
  }
}

export const CLEAR_USER_INFO = Symbol('CLEAR_USER_INFO')
export function clearUserInfo() {
  return {
    type: CLEAR_USER_INFO
  }
}

export const FOLLOW_SUCCESS = Symbol('FOLLOW_SUCCESS')
/**
 * @param ownerId
 * @param optValue 0：取消关注；1：关注。
 */
export function follow(params, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/oasis/attention',
      body: {
        ownerId: params.ownerId,
        optValue: params.optValue
      },
      successType: FOLLOW_SUCCESS,
      afterSuccess,
      afterError
    }
  }
}

export const GET_FOLLOWING_SUCCESS = Symbol('GET_FOLLOWING_SUCCESS')
/**
 * 我关注的
 * @param params.ownerId
 * @param params.attentiontype 0：普通用户；1：pro；2：团体; 不传该参数，查询所有
 * @param params.sortId
 */
export function getFollowing(params) {
  return {
    [CALL_API]: {
      method: 'get',
      path: '/api/v1/open/oasis/listattentionusers',
      query: params,
      successType: GET_FOLLOWING_SUCCESS,
    }
  }
}

export const GET_FOLLOWERS_SUCCESS = Symbol('GET_FOLLOWERS_SUCCESS')
/**
 * @param params.ownerid
 * @param params.attentiontype 0：普通用户；1：pro；2：团体
 * @param params.sortid
 */
export function getFollowers(params) {
  return {
    [CALL_API]: {
      method: 'get',
      path: '/api/v1/open/oasis/listfans',
      query: params,
      successType: GET_FOLLOWERS_SUCCESS,
    }
  }
}
export const RESET_FOLLOWERS = Symbol('RESET_FOLLOWERS')
export function resetFollowers() {
  return {
    type: RESET_FOLLOWERS
  }
}

export const GET_COLLECTED_ARTS_SUCCESS = Symbol('GET_COLLECTED_ARTS_SUCCESS')
/**
 * 获取用户中心手贴的数据
 * @param params.lastSortId 最后记录的排序id
 * @param params.userId 用户id(默认为当前用户)
 */
export function getCollectedArts(params) {
  return {
    [CALL_API]: {
      method: 'get',
      path: '/api/v1/open/airoases/user/articles',
      query: params,
      successType: GET_COLLECTED_ARTS_SUCCESS,
    }
  }
}
export const RESET_COLLECTED_CARDS = Symbol('RESET_COLLECTED_CARDS')
export function resetCollectedCards() {
  return {
    type: RESET_COLLECTED_CARDS
  }
}

export const LOAD_ORG_HOMEPAGE_INFO = Symbol('LOAD_ORG_HOMEPAGE_INFO')
/**
 * 获取团体主页信息
 */
export function loadOrgHomepageInfo(orgid, afterSuccess) {
  return {
    [CALL_API]: {
      method: 'get',
      path: '/api/v1/open/user/loadorghomepageinfo',
      query: {
        orgid
      },
      successType: LOAD_ORG_HOMEPAGE_INFO,
      afterSuccess
    }
  }
}

export const MODIFY_ORG_HOMEPAGE_SUCCESS = Symbol('MODIFY_ORG_HOMEPAGE_SUCCESS')
/**
 * 修改团体主页信息
 */
export function modifyOrgHomepage(payload, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'post',
      body: payload,
      path: '/api/v1/open/user/modifyorghomepage',
      successType: MODIFY_ORG_HOMEPAGE_SUCCESS,
      afterSuccess,
      afterError
    }
  }
}

export const MODIFY_ORG_HOMEPAGE_PLAIN = Symbol('MODIFY_ORG_HOMEPAGE_PLAIN')
/**
 * 修改团体主页信息
 */
export function modifyOrgHomepagePlain(formInfo) {
  return {
    type: MODIFY_ORG_HOMEPAGE_PLAIN,
    formInfo
  }
}

export const CHECK_PRO_USER = Symbol('CHECK_PRO_USER')
export function checkProUser(authorCode, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'get',
      query: {
        oasiscode: authorCode
      },
      path: '/api/v1/open/user/checkprouser',
      successType: CHECK_PRO_USER,
      afterSuccess,
      afterError
    }
  }
}

export const CHECK_OASES_CODE = Symbol('CHECK_OASES_CODE')
/**
 * 检查 oases code是否可用
 */
export function checkOasesCode(code, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'get',
      query: {code},
      path: '/api/v1/open/user/checkoasescode',
      successType: CHECK_OASES_CODE,
      afterSuccess,
      afterError
    }
  }
}

export const MODIFY_OASES_CODE = Symbol('MODIFY_OASES_CODE')
/**
 * 修改绿洲id
 */
export function modifyOasesCode(code, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'get',
      query: {code},
      path: '/api/v1/open/user/modifyoasescode',
      successType: MODIFY_OASES_CODE,
      afterSuccess,
      afterError
    }
  }
}

/**
 * 用户发布的手帖
 *
 */
export const GET_USER_ARTICLES = Symbol('GET_USER_ARTICLES')
export function getUserArticles(payload, afterSuccess) {
  return {
    [CALL_API]: {
      method: 'get',
      query: payload,
      path: '/api/v1/open/airoases/user/articles',
      successType: GET_USER_ARTICLES,
      afterSuccess
    }
  }
}
export const GET_USER_ARTICLES_DETAIL = Symbol('GET_USER_ARTICLES_DETAIL')
export function getUserArticlesDetail(payload, afterSuccess) {
  return {
    [CALL_API]: {
      method: 'get',
      query: {
        articleId: payload},
      path: '/api/v1/open/theme/article/detail',
      successType: GET_USER_ARTICLES_DETAIL,
      afterSuccess
    }
  }
}

/**
 * 用户创建的主题
 *
 */
export const GET_USER_THEMES = Symbol('GET_USER_THEMES')
export function getUserThemes(payload, afterSuccess) {
  return {
    [CALL_API]: {
      method: 'post',
      query: payload,
      path: '/api/v1/open/airoases/user/themes',
      successType: GET_USER_THEMES,
      afterSuccess
    }
  }
}

export const GET_USER_THEME_ARTICLES = Symbol('GET_USER_THEME_ARTICLES')
export function getUserThemeArticles(payload, afterSuccess) {
  return {
    [CALL_API]: {
      method: 'get',
      query: payload,
      path: '/api/v1/open/theme/articles',
      successType: GET_USER_THEME_ARTICLES,
      afterSuccess
    }
  }
}