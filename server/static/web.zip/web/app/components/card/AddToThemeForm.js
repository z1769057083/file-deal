import React, {PropTypes} from 'react'
import {connect} from 'react-redux'
import {bindActionCreators} from 'redux'
import Spinner from 'components/global/Spinner'
import * as articleActions from 'actions/article'
import * as globalActions from 'actions/global'
import * as userActions from 'actions/user'
import * as auth from 'actions/auth';

class AddToThemeForm extends React.Component {
  state = {
    themeId: 0,
    themes: [],
    userInfo: {}
  }

  componentDidMount() {
    this.getList()
  }

  getList = () => {
    const {userActions, authActions, userId} = this.props
    const payload = {imageCount: 1, userId }
    const success = ({response}) => this.setState({themes: response.data});
    userActions.getUserThemes(payload, success);
  }

  message(message) {
    const {globalActions} = this.props
    globalActions.addToast({
      type: 'singleMsg',
      message,
      timeout: 1500
    })
  }

  selectTheme = theme => () => {
    const {themeId} = this.state
    const {img} = this.props
    const {actions, articleId, handleClose, globalActions} = this.props
    if (themeId === 0) {
      const success = () => {
        this.setState({themeId: 0})
        globalActions.addToast({
          type: 'savedToOases',
          pic: img,
          link: `/topic/${theme.id}`,
          timeout: 5000
        })
        handleClose()
      }
      const fail = () => {
        this.message('系统错误，发贴失败')
        this.setState({themeId: 0})
      }
      const payload = {articleId, themeId: theme.id}
      this.setState({themeId: theme.id})
      actions.addToTheme(payload, success, fail)
    }
  }

  render() {
    const {img, createSubject} = this.props
    const {themes, themeId} = this.state
    const leftImg = img || '/assets/images/default_pic.svg'
    const size = img ? '/cover' : ''
    const styles = {
      background: `url(${leftImg}) center center ${size} no-repeat #F1F1F1`
    }
    return (
      <div className="m-form-base no-margin-bottom">
        <div className="m-article-creation">
          <div className="article__main">
            <div className="article__col article__col--left">
              <div className="article__img" style={styles} />
            </div>
            <div className="article__col">
              <div className="article__subject">
                <div className="subject__title">主题</div>
                {themes.map((theme, key) => {
                  const image = theme.images.find(item => item.url !== '')
                  const url = image
                    ? image.url
                    : '/assets/images/default_pic.svg'
                  const size = image ? '/cover' : ''
                  const styles = {
                    background: `url(${url}) center center ${size} no-repeat #F1F1F1`
                  }
                  const pending = themeId === theme.id
                  return (
                    <div className="subject__row" key={key}>
                      <div className="subject__img" style={styles} />
                      <div className="subject__text">
                        {theme.name}
                      </div>
                      <div
                        className="subject__button"
                        onClick={this.selectTheme(theme)}>
                        <div className="icon icon-tag">
                          {pending
                            ? <Spinner />
                            : <div className="icon icon-tag-text" />}
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          </div>
          <div className="article__footer">
            <div className="footer__create" onClick={createSubject}>
              <span className="icon icon-create" />
              <span className="create__text">创建主题</span>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

AddToThemeForm.propTypes = {
  img: PropTypes.string.isRequired,
  articleId: PropTypes.number.isRequired,
  handleClose: PropTypes.func.isRequired,
  createSubject: PropTypes.func.isRequired
}

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators(articleActions, dispatch),
  userActions: bindActionCreators(userActions, dispatch),
  globalActions: bindActionCreators(globalActions, dispatch),
  authActions: bindActionCreators(auth, dispatch)
})
function mapStateToProps (state) {
  return {
    userId: state.auth.get('id')
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(AddToThemeForm)
