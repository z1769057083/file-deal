/**
 * 可以计数的Textarea
 */
import React, { Component, PropTypes } from 'react'
import classNames from 'classnames'
import {Textarea} from 'react-validation/lib/build/validation.rc'

class CountedTextarea extends Component {
  render() {
    return (
      <div className="m-counted-textarea">
        {
          this.props.validations ?
          <Textarea {...this.props} errorContainerClassName="error-wrap" />:
            <textarea {...this.props}></textarea>

        }
        {
          this.props.maxLength ?
            <div className="count">
              {this.props.value.length} / {this.props.maxLength}
            </div>: null
        }
      </div>
    )
  }
}

CountedTextarea.propTypes = {
  placeholder: PropTypes.string,
  className: PropTypes.string,
  maxLength: PropTypes.number,
  value: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired,
  name: PropTypes.string,
  validations: PropTypes.array,
}

export default CountedTextarea