import React, {PropTypes} from 'react'
import cx from 'classnames'

class BlockImage extends React.Component {
  picId = `pic${Math.random()}`
  upload = event => {
    const {onUpload, afterUpload} = this.props
    const name = 'picFile'
    const formData = new FormData()
    formData.append(name, event.target.files[0])
    onUpload(formData, state => {
      afterUpload(state.response.data)
    })
  }

  render() {
    const {data, preview, handleDelete} = this.props
    const url = data.pic || '/assets/images/default_pic.svg'
    const size = data.pic ? '/cover' : ''
    let styles = {background: `url(${url}) no-repeat center center${size} #F1F1F1`}
    if (preview && !data.pic) {
      styles = {background: '#F1F1F1'}
    }

    if (data.pic && !preview) {
      return (
        <div className="block__image" style={styles}>
          <span className="icon icon-block-delete" onClick={handleDelete} />
        </div>
      )
    }

    if (!data.pic && !preview) {
      return (
        <div className="block__image" style={styles}>
          <label htmlFor={this.picId} className="block__label"></label>
          <input
            type="file"
            id={this.picId}
            name="userPic"
            className="block__file"
            onChange={this.upload}
          />
        </div>
      )
    }
    return <div className="block__image" style={styles} />
  }
}
BlockImage.propTypes = {
  data: PropTypes.shape({
    pic: PropTypes.string
  }),
  preview: PropTypes.bool.isRequired,
  onUpload: PropTypes.func.isRequired,
  handleDelete: PropTypes.func.isRequired,
  afterUpload: PropTypes.func.isRequired
}

class BlockImages extends React.Component {
  state = {
    hoverIndex: -1
  }

  mouseOver = hoverIndex => this.setState({hoverIndex})

  mouseOut = () => this.setState({hoverIndex: -1})

  onUpload = index => {
    return this.props.onUpload(index)
  }

  afterUpload = index => {
    return this.props.afterUpload(index)
  }

  render() {
    const {data, onFocus, current, preview, onDelete} = this.props
    const {hoverIndex} = this.state
    const hoverData = data[hoverIndex] || {}
    const hoverUrl = hoverData.pic || ''
    return (
      <div className="m-block-images">
        <div className="block__col">
          <div
            className={cx('block__item block__item--full', {
              'block__item--active': current === 0
            })}
            onMouseOver={() => this.mouseOver(0)}
            onMouseOut={() => this.mouseOut()}
            onClick={() => onFocus(0)}>
            <BlockImage
              preview={preview}
              data={data[0] || {}}
              onUpload={this.onUpload(0)}
              handleDelete={onDelete(0)}
              afterUpload={this.afterUpload(0)}
            />
          </div>
        </div>
        <div className="block__col block__col--center">
          <div
            className={cx('block__item', {
              'block__item--active': current === 1
            })}
            onMouseOver={() => this.mouseOver(1)}
            onMouseOut={() => this.mouseOut()}
            onClick={() => onFocus(1)}>
            <BlockImage
              preview={preview}
              data={data[1] || {}}
              onUpload={this.onUpload(1)}
              handleDelete={onDelete(1)}
              afterUpload={this.afterUpload(1)}
            />
          </div>
          <div
            className={cx('block__item block__item--last', {
              'block__item--active': current === 2
            })}
            onMouseOver={() => this.mouseOver(2)}
            onMouseOut={() => this.mouseOut()}
            onClick={() => onFocus(2)}>
            <BlockImage
              preview={preview}
              data={data[2] || {}}
              onUpload={this.onUpload(2)}
              handleDelete={onDelete(2)}
              afterUpload={this.afterUpload(2)}
            />
          </div>
        </div>
        <div className="block__col">
          <div
            className={cx('block__item block__item--tr', {
              'block__item--active': current === 3
            })}
            onMouseOver={() => this.mouseOver(3)}
            onMouseOut={() => this.mouseOut()}
            onClick={() => onFocus(3)}>
            <BlockImage
              preview={preview}
              data={data[3] || {}}
              onUpload={this.onUpload(3)}
              handleDelete={onDelete(3)}
              afterUpload={this.afterUpload(3)}
            />
          </div>
          <div
            className={cx('block__item block__item--last block__item--br', {
              'block__item--active': current === 4
            })}
            onMouseOver={() => this.mouseOver(4)}
            onMouseOut={() => this.mouseOut()}
            onClick={() => onFocus(4)}>
            <BlockImage
              preview={preview}
              data={data[4] || {}}
              onUpload={this.onUpload(4)}
              handleDelete={onDelete(4)}
              afterUpload={this.afterUpload(4)}
            />
          </div>
        </div>
        {hoverUrl !== '' && <div className="block__preview">
          {hoverUrl !== '' && <img src={hoverUrl} alt="" />}
        </div>}
      </div>
    )
  }
}

BlockImages.propTypes = {
  data: PropTypes.arrayOf(
    PropTypes.shape({
      pic: PropTypes.string
    })
  ).isRequired,
  preview: PropTypes.bool,
  current: PropTypes.number,
  onFocus: PropTypes.func,
  onUpload: PropTypes.func,
  onDelete: PropTypes.func,
  afterUpload: PropTypes.func
}

BlockImages.defaultProps = {
  current: 0,
  preview: false,
  onDelete: () => () => {},
  onFocus: () => {},
  onUpload: () => () => {},
  afterUpload: () => () => {}
}

export default BlockImages
