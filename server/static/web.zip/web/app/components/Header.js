import React, { Component, PropTypes } from 'react'
import {Link} from 'react-router'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import Auth from 'components/Auth'
import {logout} from 'actions/auth'
import Dropdown from 'components/forms/Dropdown'
import HeaderSearch from 'components/header/HeaderSearch'
import HeaderSuggestion from 'components/header/HeaderSuggestion'
import * as globalActions from 'actions/global'
import {
  LOGIN_USER_START,
} from 'config/authPage'
import { getSearchHistory, addSearchHistory } from 'util/local'

class Header extends Component {
  constructor(props) {
    super(props)
    this.state = {
      isOpen: false,
      hideProfileMenu: false,
    }
    this.openModal = this.openModal.bind(this)
    this.onRequestLogout = this.onRequestLogout.bind(this)
  }

  componentDidMount() {
    document.addEventListener('keyup', this.onKeyup)
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.onKeyup)
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.word !== this.props.word) {
      this.setState({keyword: nextProps.word})
    }
  }

  openModal() {
    this.state.hideProfileMenu = true
    this.forceUpdate()
    this.props.actions.showAuthWindow(LOGIN_USER_START)
    setTimeout(() => this.setState({hideProfileMenu: false}), 1000)
  }

  onRequestClose() {
    this.props.actions.hideAuthWindow()
  }

  onRequestLogout(event) {
    sessionStorage.removeItem('newtopic');
    this.props.actions.logout()
  }

  getAuthenticatedRender() {
    const {auth} = this.props

    return (
      <Dropdown
        iconClassName="icon-profile icon-menu"
        itemContainerClassName="user"
        >
        <div className="header-items">
          <div className="user-info">
            <Link to={`/${auth.get('code')}`} className="user-avatar" activeClassName="active">
              <img src={auth.get('pic').trim()? auth.get('pic'): "/assets/images/default_avatar.svg"}/>
            </Link>

            <div className="name">
              {auth.get('name') || auth.get('nickName')}
            </div>
          </div>

          <div className="btn btn-logout" onClick={this.onRequestLogout}>退出</div>
        </div>
      </Dropdown>
    )
  }

  getUnAuthenticatedRender() {
    return (
      <Dropdown
        iconClassName="icon-profile icon-menu"
        itemContainerClassName="user"
        >
        <div className="header-items">
          <div className="item" onClick={this.openModal}>登录</div>
        </div>
      </Dropdown>
    )
  }

  render() {
    const {auth, hotWords} = this.props
    const isLogin = !!auth.get('id')
    return (
      <div className="m-header m-header--fixed flexbox">
        <div className="side left-side">
          <Link to="/" className="icon icon-logo-black">
          </Link>
        </div>
        <HeaderSearch/>
        <HeaderSuggestion/>
        <div className="side right-side">
          <Link to="/" className="icon icon-tie" onlyActiveOnIndex activeClassName="active" />
          <Link to="/designer" className="icon icon-community" activeClassName="active" />
          <Dropdown
            iconClassName="icon-menu"
            itemContainerClassName="more-items"
            >
            <div className="hot--wrap">
              {hotWords.map((hotWord, key) =>
                <a href={`/search?word=${hotWord}`} className="hot__item" key={key}>{hotWord}</a>
              )}
            </div>
            <div className="nav--wrap">
              <a href="/" className="nav__item">首頁</a>
              {isLogin && <a href={`/user/${auth.get('homePage')}/profile`} className="nav__item">设置</a>}
              <a href="/others" className="nav__item">下载</a>
              <a href="/others/about" className="nav__item">关于</a>
              <a href="/others/legal" className="nav__item">法务</a>
              <a href="/others/feedback" className="nav__item">反馈</a>
            </div>
          </Dropdown>
          {auth.get('id') ? this.getAuthenticatedRender() : this.getUnAuthenticatedRender()}
        </div>
        <Auth isOpen={this.props.global.get('showAuthWindow')}
              onRequestClose={this.onRequestClose.bind(this)} />
      </div>
    )
  }
}

function mapStateToProps(state) {
  return {
    auth: state.auth,
    global: state.global,
    word: state.search.get('word'),
    hotWords: state.search.get('hotWords')
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      logout,
      showAuthWindow: globalActions.showAuthWindow,
      hideAuthWindow: globalActions.hideAuthWindow,
      addToast: globalActions.addToast,
    }, dispatch)
  }
}


export default connect(mapStateToProps, mapDispatchToProps)(Header)
