import React, {Component, PropTypes} from 'react'
import {bindActionCreators} from 'redux'
import {connect} from 'react-redux'
import * as cardActions from 'actions/card'
import {Link} from 'react-router'
import CommunitySlick from 'components/CommunitySlick'
import RecommendSlick from 'components/RecommendSlick'
import _ from 'lodash'

class CommunityUserRow extends Component {
  prevPage() {
    this.props.actions.prevSlideOfCommunitySlide(this.props.index)
  }

  nextPage() {
    const data = this.props.data

    const currentIndex = data.currentIndex
    const maxPage = data.maxPage
    if (currentIndex < maxPage) {
      this.props.actions.nextSlideOfCommunitySlide(this.props.index)
    } else if (currentIndex == maxPage) {
      if (!data.isLast) {
        this.props.actions.loadProArtByAuthorId({
          authorId: data.id,
          sortId: data.lastArtSortId
        })
      }
    }
  }

  renderDesignerLeft(data) {
    return (
      <div className="col-1 flexbox">
        <div className="avatar-wrap">
          <Link className="avatar" to={`/user/${data.id}`}>
            {data.pic ? <img src={data.pic} alt="" /> : null}
          </Link>
        </div>
        <div className="flex info-wrap">
          <Link className="name" to={`/user/${data.id}`}>
            {data.actualName || '无名'}
          </Link>
          <div className="sign">
            {data.city}
          </div>
          <div className="desc">
            {data.focus}
          </div>
          <div className="desc">
            {data.userDesc}
          </div>
        </div>
      </div>
    )
  }

  renderRecommendLeft(data, firstImage) {
    return (
      <div className="recommend flexbox">
        <div className="avatar-wrap">
          {firstImage
            ? <img className="bgcover" src={firstImage.pic} />
            : <div className="bgcover" />}
          <Link className="avatar" to={`/user/${data.userId}`}>
            {data.userPic ? <img src={data.userPic} alt="" /> : null}
          </Link>
        </div>
        <div className="flex info-wrap">
          <Link className="name" to={`/topic/${data.id}`}>
            {data.className || '无名'}
          </Link>
          <div className="sign">
            {data.location}
          </div>
          <div className="desc">
            <div className="desclabel">设计师语：</div>
            {data.wishes}
          </div>
          <div className="desc">
            <div className="desclabel">亮点：</div>
            {data.description}
          </div>
        </div>
      </div>
    )
  }

  render() {
    const {data} = this.props
    let slideData = ''
    if (this.props.activeType === 'recommend') {
      if (data.artList.length === 0) return null
      slideData = _.chunk(data.artList, 3)
    } else {
      slideData = _.chunk(data.themeResultList, 3)
    }
    
    return (
      <div className="community-user-row flexbox">
        {this.props.activeType === 'recommend'
          ? this.renderRecommendLeft(data.themeDetailResult, data.artList[0])
          : this.renderDesignerLeft(data)}
        {this.props.activeType === 'recommend'
          ? <RecommendSlick
              type={this.props.type}
              pics={slideData}
              themeData={data.themeDetailResult}

            />
          : <CommunitySlick type={this.props.type} pics={slideData} designerId={data.id}/>}
      </div>
    )
  }
}

CommunityUserRow.propTypes = {
  type: PropTypes.number.isRequired
}

function mapStateToProps(state) {
  return {
    activeType: state.artisan.get('activeType')
  }
}
function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(
      {
        loadProArtByAuthorId: cardActions.loadProArtByAuthorId,
        prevSlideOfCommunitySlide: cardActions.prevSlideOfCommunitySlide,
        nextSlideOfCommunitySlide: cardActions.nextSlideOfCommunitySlide
      },
      dispatch
    )
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(CommunityUserRow)
