import React, { Component, PropTypes } from 'react'
import AuthSingleCard from 'components/AuthSingleCard'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import {
  PRO_APPLY
} from 'config/authPage'
import PhoneInput from 'components/forms/PhoneInput'

class RegisterUserSuccess extends AuthSingleCard {
  render() {
    const {phone} = this.props
    return (
      <AuthSingleCard closeAuthModal={this.props.closeAuthModal}>
        <div className="card-main register-success">
          <div className="header">注册</div>
          <div className="main">
            <p className="account">
              <PhoneInput className="m-text read-only"
                          readOnly={true}
                          onChange={() => {}}
                          value={phone}
                          placeholder=""
                />
            </p>
            <div className="icon icon-success"></div>
            <p className="p2">注册成功！</p>
          </div>
          <div className="footer">
            <a href="/" className="btn btn-primary">首页</a>
          </div>
        </div>
      </AuthSingleCard>
    )
  }
}

RegisterUserSuccess.propTypes = {
  switchPage: PropTypes.func,
}

function mapStateToProps(state) {
  return {
    phone: state.auth.get('regPhone')
  }
}

export default connect(mapStateToProps)(RegisterUserSuccess)
