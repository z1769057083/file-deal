import React, { Component, PropTypes } from 'react'

class Download extends Component {
  render() {
    return (
      <div>
        <div className="m-others-slogan">
          <div className="title">灵感，随你而动</div>
          <p className="subtitle">利用智能手机随时随地提取最新行业资讯，<br/> 即刻下载即刻获取。</p>
        </div>
        <div className="center-logo">
          <div className="figure"><img src="/assets/images/oasis_ico_128x128.png"/></div>
          <p className="text">空 中 绿 洲</p>
        </div>
        <div className="app-download">
          <a href="https://itunes.apple.com/cn/app/%E7%A9%BA%E4%B8%AD%E7%BB%BF%E6%B4%B2/id1231916319?mt=8" className="btn btn-download"><span className="app-store"></span>iOS下载</a>
          <a href="/assets/apk/app-release20170908_1.0.0.apk" className="btn btn-download"><span className="app-store"/>android下载</a>
          <div className="btn btn-download">
            <span className="icon-wechat"></span>微信公众号
            <div className="qrcode-box">
              <div className="arrow"></div>
              <img className="qrcode" src="assets/images/qrcode.png"/>
            </div>
          </div>
        </div>

        <div className="icp-footer">
          <p>© 2016-2017 空中绿洲 airoases.com All Rights Reserved.</p>
          <p>京ICP备16037424号</p>
        </div>
      </div>
    )
  }
}

Download.propTypes = {

}

export default Download
