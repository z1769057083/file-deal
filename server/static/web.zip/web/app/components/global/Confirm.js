/**
 * Confirm Window
 */
import React, { Component, PropTypes } from 'react'
import Modal from 'react-modal'
import modalStyle from 'components/style/modal'

const Confirm = props => {
  const {isOpen, close, title, message, onConfirm, onCancel} = props
  const modalProps = {isOpen, close}
  return (
    <Modal {...modalProps} style={modalStyle} contentLabel="Modal">
      <div className="auth-card auth-single-card">
        <div className="card">
          <div className="card-main modal-confirm">
            <div className="header">
              <span>{title}</span>
              <span className="icon icon-close-white" onClick={close}></span>
            </div>
            <div className="main">
              {message}
            </div>
            <div className="footer flexbox btn-footer">
              <div className="btn btn-link" onClick={onCancel || close}>放弃</div>
              <div className="btn btn-primary" onClick={onConfirm}>确认</div>
            </div>
          </div>
        </div>
      </div>
    </Modal>
  )
}
Confirm.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  close: PropTypes.func.isRequired,

  title: PropTypes.string.isRequired,
  message: PropTypes.string.isRequired,
  onConfirm: PropTypes.func.isRequired,
  onCancel: PropTypes.func
}

export default Confirm