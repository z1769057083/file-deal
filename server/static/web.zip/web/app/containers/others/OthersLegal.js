import React, { Component, PropTypes } from 'react'
import { connect } from 'react-redux'
import Legal from 'components/Legal'

class OthersLegal extends Component {
  render() {
    return (
      <div className="m-others-legal">
        <Legal />
      </div>
    )
  }
}

function mapStateToProps (state) {
  return {}
}

OthersLegal.propTypes = {

}

export { OthersLegal }
export default connect(mapStateToProps)(OthersLegal)
