import React, { Component, PropTypes } from 'react'
import {Link} from 'react-router'

class AuthSingleCard extends Component {
  render() {
    return (
      <div className="auth-card auth-single-card">
        <div className="footer">© 2016-2017 airoases.com All Rights Reserved.</div>
        <div className="card">
          <div className="close icon sssasasass icon-close-white"
               onClick={this.props.closeAuthModal}></div>
          {this.props.children}
          <div className="agreement">
            如果继续则表示您已同意接受 <br/>
            <a href="/others/legal#legal" target="_blank">法律声明</a>、
            <a href="/others/legal#service" target="_blank">服务协议</a>、
            <a href="/others/legal#policy" target="_blank">隐私政策</a>。
          </div>
        </div>
      </div>
    )
  }
}

AuthSingleCard.propTypes = {
  closeAuthModal: PropTypes.func
}
AuthSingleCard.defaultProps = {
  closeAuthModal: () => {}
}

export default AuthSingleCard
