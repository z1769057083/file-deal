import React, { Component, PropTypes } from 'react'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import * as cardActions from 'actions/card'
import {Link} from 'react-router'
import CommunitySlide from 'components/CommunitySlide'
import classNames from 'classnames'

class CommunityUserItem extends Component {
  prevPage() {
    this.props.actions.prevSlideOfCommunitySlide(this.props.index)
  }

  nextPage() {
    const data = this.props.data

    const currentIndex = data.currentIndex
    const maxPage = data.maxPage
    if ( currentIndex < maxPage) {
      this.props.actions.nextSlideOfCommunitySlide(this.props.index)
    } else if (currentIndex == maxPage) {
      if (!data.isLast) {
        this.props.actions.loadProArtByAuthorId({
          authorId: data.id,
          sortId: data.lastArtSortId
        })
      }
    }
  }

  render() {
    const data = this.props.data
    const slideData = data.artList.slice(0, 3)
    const more = Math.max(data.articleCnt - 3, 0)
    return (
      <div className="community-user-item flexbox">
        <div className="col-1 flexbox">
          <div className="avatar-wrap">
            <Link className="avatar" to={`/user/${data.id}`}>
              {data.pic ? <img src={data.pic} alt=""/>: null}
            </Link>
          </div>
          <div className="flex info-wrap">
            <Link className="name" to={`/${data.code}`}>{data.name || '无名'}</Link>
            <div className="sign">{data.sign}</div>
            <div className="sign">{data.focus}</div>
          </div>
        </div>
        <div className="col-2 album">
          <CommunitySlide
            type={this.props.type} pics={slideData} />
        </div>
        <div className="col-3 more flexbox">
          <Link className="plus" to={`/user/${data.id}`}>+{more}</Link>
        </div>
      </div>
    )
  }
}

CommunityUserItem.propTypes = {
  type: PropTypes.number.isRequired
}

function mapStateToProps(state) {
  return {
  }
}
function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      loadProArtByAuthorId: cardActions.loadProArtByAuthorId,
      prevSlideOfCommunitySlide: cardActions.prevSlideOfCommunitySlide,
      nextSlideOfCommunitySlide: cardActions.nextSlideOfCommunitySlide,
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(CommunityUserItem)
