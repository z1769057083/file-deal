import React, {Component, PropTypes} from 'react'
import {bindActionCreators} from 'redux'
import {connect} from 'react-redux'
import {browserHistory} from 'react-router'
import {addSearchHistory} from 'util/local'
import Slider from 'react-slick'
import Header from 'components/Header'
import Waterfall from 'components/Waterfall'
import CornerBar from 'components/CornerBar'
import PageStatus from 'components/PageStatus'
import UpgradeTips from 'components/UpgradeTips'
import ICPFooter from 'components/global/ICPFooter'
import * as searchActions from 'actions/search'

class Search extends Component {
  constructor(props, context) {
    super(props, context)
    const {word} = this.props.location.query
    this.state = {
      loading: false,
      word: word
    }
    this.onScroll = this.onScroll.bind(this)
  }

  componentDidMount() {
    const {word} = this.state
    if (!word) {
      return browserHistory.push('/')
    }
    const {actions} = this.props
    actions.updateSearch('word', word)
    actions.updateSearch('keyword', word)
    addSearchHistory(word)
    window.addEventListener('scroll', this.onScroll)
    this._loadCards()
  }

  shouldComponentUpdate(props, state) {
    if (props.cards.equals(this.props.cards) == false) {
      return true
    }
    if (this.state.loading !== state.loading) {
      return true
    }
    return false
  }

  componentWillUnmount() {
    this.props.actions.reset()
    window.removeEventListener('scroll', this.onScroll)
  }

  onScroll() {
    const inModal = this.props.cards.get('inModal')
    if (inModal) {
      return
    }
    const isBottom =
      window.innerHeight + window.scrollY >= document.body.offsetHeight
    if (isBottom) {
      this._loadCards()
    }
  }

  _loadCards() {
    const {cards} = this.props
    const {word} = this.state
    const isEnd = cards.get('isEnd')
    const sortId = cards.get('sortId')
    const hasModal = this.props.hasModal
    if (!isEnd && !hasModal && !this.state.loading) {
      this.setState({
        loading: true
      })
      this.props.actions.getArticleSearch(
        {
          sortId: sortId,
          word
        },
        this._disableLoading.bind(this),
        this._disableLoading.bind(this)
      )
    }
  }

  _disableLoading() {
    this.setState({
      loading: false
    })
  }

  renderSwipeToSlide(classList) {
    if (classList.size === 0) return null
    const settings = {
      dots: false,
      infinite: false,
      speed: 500,
      slidesToShow: 6,
      slidesToScroll: 3,

      swipe: true,
      touchMove: true
    }
    const bgColorList = [
      '#B25C43',
      '#76664D',
      '#8D4256',
      '#B3CEC5',
      '#CED3CD',
      '#ED5734',
      '#B6C8CD',
      '#494166',
      '#415065',
      '#B36E61',
      '#A98275',
      '#F13000',
      '#C6262A',
      '#CA6924',
      '#D9B612',
      '#A88462',
      '#789263',
      '#9D2A32',
      '#8AC0A7',
      '#CBBC95'
    ]
    return (
      <div className="slick__container">
        <Slider {...settings}>
          {classList.map((item, key) => {
            let color = bgColorList[(key + 1) % bgColorList.length]
            return (
              <a href={`/search?word=${encodeURIComponent(item)}`} className="slick-slide" key={key}>
                <div
                  className="search-cate__item"
                  style={{backgroundColor: color}}>
                  {item}
                </div>
              </a>
            )
          })}
        </Slider>
      </div>
    )
  }

  render() {
    let pageStatus = 'default'
    let statusHeight = 0
    const {cards} = this.props
    const isEnd = cards.get('isEnd')
    const sortId = cards.get('sortId')

    if (isEnd) {
      pageStatus = 'isEnd'
      if (cards.get('list').size === 0) {
        pageStatus = 'empty'
      }
    } else if (this.state.loading) {
      pageStatus = 'loading'
    }

    const items = this.props.cards.get('list')

    if (items.size < 1) {
      statusHeight = 600
    }

    return (
      <div className="m-home m-header--wrap">
        <Header />
        <UpgradeTips width={1030} />
        {this.renderSwipeToSlide(cards.get('classList'))}
        <Waterfall cards={items} type={0} location={this.props.location} />
        <PageStatus status={pageStatus} height={statusHeight} />
        <CornerBar />
        <ICPFooter />
      </div>
    )
  }
}

function mapStateToProps(state) {
  return {
    cards: state.search,
    hasModal: state.global.get('hasModal')
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(
      {
        updateSearch: searchActions.updateSearch,
        reset: searchActions.reset,
        getArticleSearch: searchActions.getArticleSearch
      },
      dispatch
    )
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Search)
