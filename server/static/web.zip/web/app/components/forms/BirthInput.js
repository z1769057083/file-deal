import React, { Component, PropTypes } from 'react'
import {Input} from 'react-validation/lib/build/validation.rc'

function formatPhone(phone) {
  if(!phone) return ''
  let formatted = ''
  const purePhone = phone.replace(/[^\d]/g, '')
  const one = purePhone.slice(0, 4)
  const two = purePhone.slice(4, 6)
  const three = purePhone.slice(6, 8)

  if(one) formatted += one
  if(two) formatted += ' / '+(two.length == 1 && parseInt(two) > 1 ? '0'+two : two)
  if(three) formatted += ' / '+(three.length == 1 && parseInt(three) > 3 ? '0'+three : three)

  return formatted
}
function unformatPhone(formatPhone) {
  return formatPhone.replace(/[^\d]/g, '')
}
/*
 * Best Practices
 * http://brewhouse.io/blog/2015/03/24/best-practices-for-component-state-in-reactjs.html
 */
class BirthInput extends Component {
  constructor(props) {
    super(props)
    this.onChange = this.onChange.bind(this)
  }
  onChange(e) {
    this.props.onChange(unformatPhone(e.nativeEvent.target.value))
  }
  renderDefault() {
    return (
      <input type="text"
        className={this.props.className}
        readOnly={this.props.readOnly}
        onChange={this.onChange}
        value={formatPhone(this.props.value)}
        placeholder={this.props.placeholder}
      />
    )
  }
  renderValidate() {
    return (
      <Input
        type="text"
        name={this.props.name}
        className={this.props.className}
        containerClassName={this.props.containerClassName}
        errorClassName={this.props.errorClassName}
        onChange={this.onChange}
        value={formatPhone(this.props.value)}
        validations={this.props.validations}
        placeholder={this.props.placeholder}
      />
    )
  }
  render() {
    if (this.props.validations) {
      return this.renderValidate()
    } else {
      return this.renderDefault()
    }
  }
}

export default BirthInput
