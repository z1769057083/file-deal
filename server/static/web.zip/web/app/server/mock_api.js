let _ = require('lodash')

function question (id) {
  let sampleContent = '--the question content--'
  return {
    id,
    content: `sample-${id}: ${sampleContent}`,
    user_id: id
  }
}

export const questions = _.range(1, 10).map((i)=> question(i))
export function getUser (id) {
  return {
    id,
    name: `user name - ${id}`
  }
}
export function getQuestion (id) {
  if (id === 'not-found') {
    return null
  }
  return question(id)
}
export const cards = Array.from([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], x => {
  return {
    img: {
      url: '',
      width: 470,
      height: Math.ceil(Math.max(Math.random(0, 1) * 1000, 266))
    }
  }
})
export const userList = Array.from([1, 2, 3, 4, 5, 6], x => {
  return {
    user: {
    },
    album:[
    ]
  }
})

const oasisMaps = {
  'U000jdHP': '5000075',
  'U000jdGT': '5000027',
  'U000jdGc': '5000036',
  'U000jdGd': '5000037',
  'U000jdGa': '5000034',
  'U000jdGC': '5000010'
}

export function getUserId(oasisId) {
  return oasisMaps[oasisId] || '5000076'
}