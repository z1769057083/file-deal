import { combineReducers } from 'redux'
import cards from 'reducers/cards'
import userList from 'reducers/userList'
import auth from 'reducers/auth'
import register from 'reducers/register'
import article from 'reducers/article'
import global from 'reducers/global'
import user from 'reducers/user'
import search from 'reducers/search'
import subject from 'reducers/subject'
import artisan from 'reducers/artisan'

const rootReducer = combineReducers({
  cards,
  userList,
  auth,
  register,
  article,
  global,
  user,
  search,
  subject,
  artisan
})

export default rootReducer
