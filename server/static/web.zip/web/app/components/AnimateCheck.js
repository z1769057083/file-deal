/**
 * reference: http://stackoverflow.com/questions/26558916/draw-a-check-mark-css-animation-from-left-down-to-right-up
 */
import React, { Component, PropTypes } from 'react'
import ReactDOM from 'react-dom'

class AnimateCheck extends Component {
  componentDidMount() {
    let canvas = ReactDOM.findDOMNode(this.refs.canvas)
    let ctx = canvas.getContext('2d')

    var start = 100;
    var mid = 145;
    var end = 250;
    var width = 12;
    var leftX = start;
    var leftY = start;
    var rightX = mid - (width / 2.7);
    var rightY = mid + (width / 2.7) + 1;
    var animationSpeed = 10;

    ctx.scale(0.2,0.2)
    ctx.lineWidth = width;
    ctx.strokeStyle = 'rgba(255, 255, 255, 1)';

    for (let i = start; i < mid; i++) {
      var drawLeft = window.setTimeout(function () {
        ctx.beginPath();
        ctx.moveTo(start, start);
        ctx.lineTo(leftX, leftY);
        ctx.stroke();
        leftX++;
        leftY++;
      }, 1 + (i * animationSpeed) / 3);
    }

    for (let i = mid; i < end; i++) {
      var drawRight = window.setTimeout(function () {
        ctx.beginPath();
        ctx.moveTo(leftX, leftY);
        ctx.lineTo(rightX, rightY);
        ctx.stroke();
        rightX++;
        rightY--;
      }, 1 + (i * animationSpeed) / 3);
    }
  }
  render() {
    return (
      <div className="m-animate-check">
        <canvas height="35" width="73" ref="canvas"></canvas>
      </div>
    )
  }
}

export default AnimateCheck