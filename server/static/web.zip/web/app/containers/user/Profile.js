/**
 * 帐户页面
 */
import React, { Component, PropTypes } from 'react'
import { connect } from 'react-redux'
import {bindActionCreators } from 'redux'
import Header from 'components/Header'
import ProfileHeader from 'components/ProfileHeader'
import * as authActions from 'actions/auth'

class Profile extends Component {
  constructor(props) {
    super(props)
    const {auth} = this.props
    const user = auth.toJS()
    this.state = {
      user,
      inited: !!user.id,
    }
  }
  componentWillReceiveProps(nextProps) {
    const {auth} = nextProps
    if (auth.get('id') != '' && !this.state.inited) {
      this.setState({
        user: auth.toJS(),
        inited: true
      })
    }
  }
  render() {
    return (
      <div className="m-profile m-header--wrap">
        <Header />
        {this.state.inited ? <ProfileHeader userId={this.props.params.id} />: null}
        {this.state.inited ? this.props.children: null}
      </div>
    )
  }
}

function mapStateToProps (state) {
  return {auth: state.auth}
}
function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      updateAvatar: authActions.updateAvatar
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Profile)
