import React, { Component, PropTypes } from 'react'
import AuthSingleCard from 'components/AuthSingleCard'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import * as registerActions from 'actions/register'
import {
  REGISTER_TEAM_SUCCESS
} from 'config/authPage'
import {
  Form,
  Input,
  Button
} from 'react-validation/lib/build/validation.rc'
import {SubmitDecorator} from 'decorators'

class RegisterTeam extends Component {
  constructor(props) {
    super(props)
    const register = this.props.register
    this.state = {
      email: register.get('teamEmail'),
      pwd: register.get('teamPwd'),
      repeatPwd: '',
      nickname: '',
    }
    this.handlePwd = this.handlePwd.bind(this)
    this.handleRepeatPwd = this.handleRepeatPwd.bind(this)
    this.handleNickName = this.handleNickName.bind(this)
    this.onSubmit = this.onSubmit.bind(this)
  }
  handlePwd(e) {
    this.setState({
      pwd: e.target.value,
    })
  }
  handleRepeatPwd(e) {
    this.setState({
      repeatPwd: e.target.value,
    })
  }
  handleNickName(e) {
    this.setState({
      nickname: e.target.value
    })
  }
  onSubmit(event) {
    event.preventDefault()

    const {pwd, email, nickname} = this.state
    this.props.actions.registerTeam({
      email,
      pwd,
      nickname,
      afterSuccess: () => {
        this.props.actions.updateTeamEmailPWD(email, pwd)
        this.props.switchPage(REGISTER_TEAM_SUCCESS)
      },
      afterError: (state) => {
        const error = state.message || '注册失败'
        this.props.showError(error)
      }
    })
  }
  render() {
    const {email} = this.state
    return (
      <AuthSingleCard closeAuthModal={this.props.closeAuthModal}>
        <Form className="card-main register-user modal-form"
              ref={c => {this.form = c}}
              onSubmit={this.onSubmit}
          >
          <div className="header">注册</div>
          <div className="main">
            <Input type="text"
                   name="nickname"
                   className="m-text"
                   containerClassName="input field-wrapper"
                   errorClassName="error"
                   onChange={this.handleNickName}
                   value={this.state.nickname}
                   validations={['required']}
                   placeholder="个人或工作室名称"
            />
            <Input type="password"
                   name="pwd"
                   className="m-text"
                   containerClassName="input field-wrapper"
                   errorClassName="error"
                   onChange={this.handlePwd}
                   value={this.state.pwd}
                   validations={['required', 'password', 'passwordConfirm']}
                   placeholder="密码（字母、数字至少8位）"
              />
            <Input type="password"
                   name="repeatPwd"
                   className="m-text"
                   containerClassName="input field-wrapper"
                   errorClassName="error"
                   onChange={this.handleRepeatPwd}
                   value={this.state.repeatPwd}
                   validations={['required', 'password', 'passwordConfirm']}
                   placeholder="再次输入密码"
              />
          </div>
          <div className="footer flexbox single-button field-wrapper btn-footer">
            <Button type="submit" className="btn btn-primary btn-block">下一步</Button>
            {this.props.error && <div className="form-error active">{this.props.error}</div>}
          </div>
        </Form>
      </AuthSingleCard>
    )
  }
}

RegisterTeam.propTypes = {
  switchPage: PropTypes.func,
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      registerTeam: registerActions.registerTeam,
      updateTeamEmailPWD: registerActions.updateTeamEmailPWD,
    }, dispatch)
  }
}

function mapStateToProps(state) {
  return {register: state.register}
}

export default connect(mapStateToProps, mapDispatchToProps)(
  SubmitDecorator(RegisterTeam)
)

