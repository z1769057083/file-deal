import { CALL_API } from 'middleware/api'
/**
 * 匠说
 */

export const UPDATE_ARTISAN = Symbol('UPDATE_ARTISAN')
export function updateArtisan(keyPath, value) {
  return {
    type: UPDATE_ARTISAN,
    keyPath,
    value
  }
}

/**
 * 设计师首页
 */
export const GET_ARTISAN_DESIGNER_HOME = Symbol('GET_ARTISAN_DESIGNER_HOME')
export function getArtisanDesignerHome(afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'get',
      path: '/api/v1/open/artisan/designer/home',
      successType: GET_ARTISAN_DESIGNER_HOME,
      afterSuccess,
      afterError
    }
  }
}

/**
 * 设计师详情
 *
 */
export const GET_ARTISAN_DESIGNER = Symbol('GET_ARTISAN_DESIGNER')
export function getArtisanDesigner(payload, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'get',
      path: '/api/v1/open/artisan/designer',
      query: {
        designerIds: payload},
      successType: GET_ARTISAN_DESIGNER,
      afterSuccess,
      afterError
    }
  }
}

export const GET_ARTISAN_RECOMMEND = Symbol('GET_ARTISAN_RECOMMAND')
export function getArtisanRecommend(payload, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'get',
      path: '/api/v1/open/artisan/recommend',
      query: payload,
      successType: GET_ARTISAN_RECOMMEND,
      afterSuccess,
      afterError
    }
  }
}