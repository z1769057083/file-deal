/**
 * 关注/取消关注
 */
import React, {Component, PropTypes} from 'react'
import { connect } from 'react-redux'
import {bindActionCreators } from 'redux'
import cx from 'classnames'
import Spinner from 'components/global/Spinner'
import * as userActions from 'actions/user'
import * as globalActions from 'actions/global'

const propTypes = {
  isSelf: PropTypes.bool,
  isAttention: PropTypes.string,
  toId: PropTypes.number,
  userPic: PropTypes.string
}
class Follow extends Component {
  constructor(props) {
    super(props)
    this.state = {
      isAttention: props.isAttention,
      pending: false
    }
    this.switchStatus = this.switchStatus.bind(this)
    this.success = this.success.bind(this)
    this.fail = this.fail.bind(this)
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.toId !== this.props.toId) {
      this.setState({isAttention: nextProps.isAttention})
    }
  }

  success() {
    setTimeout(() => {
      const {isAttention} = this.state
      const {userPic} = this.props
      const newValue = isAttention === '0' ? '1' : '0'
      const text = newValue === '1' ? '已成功关注': '已取消关注'
      this.setState({pending: false, isAttention: newValue})
      this.props.actions.addToast({
        type: 'black',
        message: text,
        pic: userPic,
        timeout: 1500
      })
    }, 300)
  }

  fail() {
    this.props.actions.addToast({
      type: 'singleMsg',
      message: `关注失败`,
      timeout: 1000
    })
    this.setState({pending: false})
  }

  switchStatus() {
    if (this.state.pending) {
      return
    }

    const {toId} = this.props
    const {isAttention} = this.state
    this.state.pending = true
    this.forceUpdate()
    this.props.actions.follow({
      ownerId: toId,
      optValue: isAttention !== "1" ? 1 : 0
    }, this.success, this.fail)
  }

  render() {
    const {isAttention, pending} = this.state
    const {fromId, toId} = this.props
    const followed = isAttention !== '0'
    const isSelf = fromId == toId
    if (isSelf) {
      return null
    }

    const text = isAttention === '0' ? '关注' : '取消关注'
    return (
      <div className={cx('icon icon-follow', {followed})}
           onClick={this.switchStatus}>
        {pending ? <Spinner /> : text}
      </div>
    )
  }
}

Follow.propTypes = propTypes

function mapStateToProps(state) {
  return {
    fromId: state.auth.get('id'),
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      follow: userActions.follow,
      addToast: globalActions.addToast,
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Follow)