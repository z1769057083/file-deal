/**
 * NavLink
 * support isActive
 */
import React, { Component, PropTypes } from 'react'
import {Link} from 'react-router'
import cx from 'classnames'

const NavLink = props => {
  const {to, activeClassName, className, isActive} = props
  const active = isActive(to) ? ` ${activeClassName}` : ""
  return (
    <Link className={className + active} to={to}>
      {props.children}
    </Link>
  )
}
NavLink.propTypes = {
  isActive: PropTypes.func.isRequired
}

export default NavLink