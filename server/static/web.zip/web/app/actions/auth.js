/**
 * Login and manage profile info
 */
import { CALL_API, CHAIN_API } from 'middleware/api'
import Storage from 'util/storage'

export const GET_AUTH_INFO = Symbol('GET_AUTH_INFO')
export function getAuthInfo(afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'get',
      path: '/api/v1/open/user/loadselfbaseinfo',
      successType: GET_AUTH_INFO,
      afterSuccess,
      afterError
    }
  }
}

export const GET_PRO_AUTH_INFO = Symbol('GET_PRO_AUTH_INFO')
export function getProAuthInfo(afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'get',
      path: '/api/v1/open/user/loadproinfo',
      successType: GET_PRO_AUTH_INFO,
      afterSuccess,
      afterError
    }
  }
}

export const UPDATE_BASE_INFO_SUCCESS = Symbol('UPDATE_BASE_INFO_SUCCESS')
export function updateBaseInfo(payload, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/user/modifybaseinfo',
      body: payload,
      successType: UPDATE_BASE_INFO_SUCCESS,
      afterSuccess,
      afterError,
    }
  }
}

/**
 * 提交PRO信息
 */
export const UPDATE_PRO_INFO_SUCCESS = Symbol('UPDATE_PRO_INFO_SUCCESS')
export function updateProInfo(payload, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/user/modifyProInfo',
      body: payload,
      successType: UPDATE_PRO_INFO_SUCCESS,
      afterSuccess,
      afterError,
    }
  }
}

export const UPDATE_USER_PASSWORD = Symbol('UPDATE_USER_PASSWORD')
export function updateUserPassword(opwd, npwd, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/user/modifypwd',
      body: {
        opwd,
        npwd
      },
      successType: UPDATE_USER_PASSWORD,
      afterSuccess,
      afterError
    }
  }
}

export const LOGIN_SUCCESS = Symbol('LOGIN_SUCCESS')
export const LOGIN_ERROR = Symbol('LOGIN_ERROR')
export function loginUser(params) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/user/reqlogin',
      query: {phone: params.phone, pwd: params.pwd, token: 'web'},
      successType: LOGIN_SUCCESS,
      afterSuccess: params.afterSuccess,
      afterError: params.afterError
    }
  }
}

export const LOG_OUT = Symbol('LOG_OUT')
export function logout() {
  Storage.remove('token')
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/user/logout',
      successType: LOG_OUT,
      errorType: LOG_OUT
    }
  }
}

export function loginTeam(params) {
  return {
    [CHAIN_API]: [
      () => {
        return {
          [CALL_API]: {
            method: 'post',
            path: '/api/v1/open/user/orgreqlogin',
            query: {
              email: params.email,
              pwd: params.pwd,
              token: 'web'
            },
            afterSuccess: params.afterLogin,
            successType: LOGIN_SUCCESS,
            afterError: params.afterError
          }
        }
      },
      () => {
        return {
          [CALL_API]: {
            method: 'get',
            path: '/api/v1/open/user/loadselfbaseinfo',
            successType: GET_AUTH_INFO,
            afterSuccess: params.afterSuccess,
            afterError: params.afterError
          }
        }
      }
    ]
  }

}

export const UPDATE_AVATAR_SUCCESS = Symbol('UPDATE_AVATAR_SUCCESS')
export function updateAvatar(formData, afterSuccess) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/user/changeuserpic',
      body: formData,
      successType: UPDATE_AVATAR_SUCCESS,
      afterSuccess
    }
  }
}

export const APPLY_PRO_SUCCESS = Symbol('APPLY_PRO_SUCCESS')
/**
 * payload:
 {
    name: '',
    birthday: '',
    gender: '',
    location: '',

    focus: '',
    sign: '',
    occupation: '',
    workorg: '',
    pic: '',
 }
 */
export function applyPro(payload, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/user/reqprocheck',
      body: payload,
      successType: APPLY_PRO_SUCCESS,
      afterSuccess,
      afterError
    }
  }
}
