/**
 * React-validation Rules
 */
import React from 'react'
import validator from 'validator'

export const Rules = {
  // Key name maps the rule
  required: {
    // Function to validate value
    // NOTE: value might be a number -> force to string
    rule: value => {
      return value.toString().trim();
    },
    // Function to return hint
    // You may use current value to inject it in some way to the hint
    hint: value => {
      return <span className='form-error'>此项为必填</span>
    }
  },
  email: {
    rule: value => {
      return validator.isEmail(value);
    },
    hint: value => {
      return <span className='form-error'>请输入有效的邮箱</span>
    }
  },
  nickName: {
    rule: value => {
      const str = value.toString().trim()
      return str.length > 0 && str.length <= 18
    },
    hint: value => {
      return <span className="form-error">昵称应为1-18个字符</span>
    }
  },
  number: {
    rule: value => {
      return value === '' || validator.isNumeric(value);
    },
    hint: value => {
      return <span className='form-error'>请输入有效的数字</span>
    }
  },
  numberRange: {
    rule: value => {
      return validator.isNumeric(value) && value >= 1 && value <= 100;
    },
    hint: value => {
      return <span className='form-error'>仅可填写1-100的数值</span>
    }
  },

  // modal-form fields
  password: {
    rule: value => {
      const str = value.toString().trim()
      return str.length >= 8
    },
    hint: value => {
      return <span className="form-error">字母、数字至少8位</span>
    }
  },
  phone: {
    rule: value => {
      return validator.isMobilePhone(value.replace(/ /g, ''), 'zh-CN')
    },
    hint: value => {
      return <span className="form-error">需11位手机号码</span>
    }
  },
  passwordConfirm: {
    rule: (value, components) => {
      const password = components.pwd.state;
      const passwordConfirm = components.repeatPwd.state;
      const isBothUsed = password
        && passwordConfirm
        && password.isUsed
        && passwordConfirm.isUsed
      const isBothChanged = isBothUsed && password.isChanged && passwordConfirm.isChanged;

      if (!isBothUsed || !isBothChanged) {
        return true
      }

      return password.value === passwordConfirm.value;
    },
    hint: () => {
      return <span className="form-error">两次输入的密码不一致</span>
    }
  },
  gender: {
    rule: value => {
      return value == 0 || value == 1 || value == -1
    },
    hint: value => {
      return <span className="form-error">请选择性别</span>
    }
  },
  date: {
    rule: value => {
      return /^\d{4} \/ \d{2} \/ \d{2}$/g.test(value)
    },
    hint: value => {
      return <span className='form-error'>请输入有效的日期</span>
    }
  },

  oasesCode: {
    rule: value => {
      return /^[a-zA-Z0-9]{3,16}$/g.test(value)
    },
    hint: value => {
      return <span className="form-error">请输入3-16位的数字字母组合</span>
    }
  },
  oasesCodeConfirm: {
    rule: (value, components) => {
      const homePage = components.homePage.state;
      const repeatHomePage = components.repeatHomePage.state;
      const isBothUsed = homePage
        && repeatHomePage
        && homePage.isUsed
        && repeatHomePage.isUsed
      const isBothChanged = isBothUsed && homePage.isChanged && repeatHomePage.isChanged;

      if (!isBothUsed || !isBothChanged) {
        return true
      }

      return homePage.value === repeatHomePage.value;
    },
    hint: () => {
      return <span className="form-error">两次输入不一致</span>
    }
  },
  url: {
    rule: value => {
      return value == '' || /^http(s?):\/\/.*/.test(value)
    },
    hint: () => {
      return <span className="form-error">网址需以http开头</span>
    }
  }
}
