/**
 * 法律声明
 */
import React, {Component, PropTypes} from 'react'
import {fromJS} from 'immutable'
import _ from 'lodash'

const options = [
  {
    key: "0",
    value: "著作权归个人所有。",
  },
  {
    key: "1",
    value: "此作品为多方合作成果，本发布人已事先获得多方书面确认同意上传发布。",
  },
  {
    key: "2",
    value: "著作权归个人所有，未经本发布人许可，不可以任何形式转载或用于商业用途。",
  }
]
class LegalNotice extends Component {
  componentDidMount() {
    const data = this.props.data
    if (!options[data.key]) {
      this.props.onChange('legalNotice', fromJS(options[0]))
    }
  }
  _onChange(key) {
    this.props.onChange('legalNotice', fromJS(options[key]))
  }
  render() {
    const data = this.props.data
    return (
      <div className="m-legal-notice">
        <select value={data.key} className="m-text"
                onChange={(e) => this._onChange(e.target.value)}>
          {
            options.map((item, key) => {
              return (
                <option value={item.key} key={key}>{item.value}</option>
              )
            })
          }
        </select>
      </div>
    )
  }
}

LegalNotice.propTypes = {
  data: PropTypes.shape({
    key: PropTypes.string,
    value: PropTypes.string
  }),
  onChange: PropTypes.func.isRequired
}

export default LegalNotice
