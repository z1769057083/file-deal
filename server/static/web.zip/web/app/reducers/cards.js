import * as ActionType from 'actions/card'
import {fromJS} from 'immutable'
import _ from 'lodash'

let defaultState = fromJS({
  sortId: -1,
  isEnd: false,
  list: [],
  page: 0,
  articles: [], //从第二页开始，所有的文章id

  proArtSortId: -1,
  proArtIsEnd: false,
  proArt: [], //有料

  ortArtSortId: -1,
  orgArtIsEnd: false,
  orgArt: [], //云库

  inModal: false,
  contextCards: [],
  returnTo: '/'
})
function cardsReducer(state = defaultState, action) {
  switch (action.type) {
    case ActionType.LOADED_CARDS: {
      const newData = action.response.data
      const isEnd = newData.artList.length < newData.pageSize
      const sortId = newData.lastSortId
      newData.artList[newData.artList.length - 1].nextPage = {
        isEnd,
        path: '/api/v1/open/article/listforwardart',
        query: {
          sortid: sortId
        }
      }
      return state
        .set('list', state.get('list').concat(fromJS(newData.artList)))
        .set('isEnd', isEnd)
        .set('sortId', sortId)
    }

    case ActionType.LOAD_FIRST_PAGE_CARDS: {
      const {firstPage, articles} = action.response.data
      const isEnd = articles.length <= 1
      if (firstPage.length > 0 && !isEnd) {
        const query = articles[1].reduce((calc, item) => {
          calc.push(`articleIds=${item}`)
          return calc
        }, []).join('&')
        firstPage[firstPage.length - 1].nextPage = {
          isEnd,
          path: '/api/v1/open/popular/article',
          query
        }
      }
      return state
        .set('list', fromJS(firstPage))
        .set('page', 0)
        .set('articles', fromJS(articles))
        .set('isEnd', isEnd)
    }

    case ActionType.LOAD_NEXT_PAGE_CARDS: {
      const {data} = action.response
      //老接口,用于搜索页面
      if (data.artList) {
        const isEnd = data.artList.length < data.pageSize
        const sortId = data.lastSortId
        data.artList[data.artList.length - 1].nextPage = {
          isEnd,
          path: '/api/v1/open/article/listforwardart',
          query: {
            sortid: sortId
          }
        }
        return state.set('contextCards', state.get('contextCards')
          .concat(fromJS(data.artList)))
      }
      const page = state.get('page')
      const articles = state.get('articles')
      if (articles.size > page && data.length > 0) {
        const isEnd = page + 1 >= articles.size
        if (!isEnd) {
          const query = articles.get(page+2).reduce((calc, item) => {
            calc.push(`articleIds=${item}`)
            return calc
          }, []).join('&')
          data[data.length - 1].nextPage = {
            isEnd,
            path: '/api/v1/open/popular/article',
            query
          }
        }
        return state
          .set('page', page + 1)
          .set('isEnd', isEnd)
          .set('list', state.get('list').concat(fromJS(data)))
          .set('contextCards',
            state.get('contextCards').concat(fromJS(data)))
      }
      return state
    }

    case ActionType.LOAD_PRO_ARTS_SUCCESS: {
      const newData = action.response.data
      const filteredData = _.filter(
        newData.objList,
        item => item.artList.length > 0
      )
      const next = state
        .set('proArt', state.get('proArt').concat(fromJS(filteredData)))
        .set('proArtIsEnd', newData.objList.length < newData.pageSize)
        .set('proArtSortId', newData.lastSortId)
      return next
    }

    case ActionType.UPDATE_CARD_MODE: {
      const params = action.params
      let next = state
      if (params.inModal !== undefined) {
        next = next.set('inModal', params.inModal)
      }
      if (params.contextCards !== undefined) {
        console.log("zxl",params.contextCards)
        next = next.set('contextCards', fromJS(params.contextCards))
      }
      if (params.returnTo !== undefined) {
        console.log("zxl2",params.returnTo)
        next = next.set('returnTo', params.returnTo)
      }
      return next
    }

    case ActionType.LOAD_PRO_ART_BY_AUTHOR_ID: {
      const data = action.response.data

      if (data.objList.length < 1) {
        return state
      }

      const authorId = action.query.authorid
      const index = _.findKey(state.get('proArt').toJS(), item => {
        return item.id === authorId
      })
      const prev = state.getIn(['proArt', index]).toJS()
      prev.artList = prev.artList.concat(data.objList)
      prev.currentIndex = prev.currentIndex > 0 ? prev.currentIndex + 1 : 2
      prev.lastArtSortId = data.lastSortId
      prev.isLast = data.objList.length < data.pageSize
      prev.maxPage = prev.currentIndex
      return state.setIn(['proArt', index], fromJS(prev))
    }

    case ActionType.COMMUNITY_SLIDE_NEXT:
      const prevIndex = state.getIn(['proArt', action.index, 'currentIndex'])
      return state.setIn(
        ['proArt', action.index, 'currentIndex'],
        prevIndex + 1
      )

    case ActionType.COMMUNITY_SLIDE_PREV: {
      const currentIndex = state.getIn(['proArt', action.index, 'currentIndex'])
      const nextIndex = currentIndex > 1 ? currentIndex - 1 : 1
      return state.setIn(['proArt', action.index, 'currentIndex'], nextIndex)
    }

    case ActionType.LOAD_ORG_ARTS_SUCCESS: {
      const newData = action.response.data
      const next = state
        .set('orgArt', state.get('orgArt').concat(fromJS(newData.objList)))
        .set('orgArtIsEnd', newData.objList.length < newData.pageSize)
        .set('orgArtSortId', newData.lastSortId)
      return next
    }

    case ActionType.UPDATE_CARD_LIKE: {
      const {id, isLike} = action
      let list = state.get('list')
      list = list.update(
        list.findIndex(item => {
          return item.get('id') === id
        }),
        function(item) {
          return item.set('isFavorite', isLike ? '1' : '0')
        }
      )

      const next = state.set('list', list)

      return next
    }

    case ActionType.UPDATE_CARD_TREAD: {
      const {id, isTread} = action
      let list = state.get('list')
      list = list.update(
        list.findIndex(item => {
          return item.get('id') === id
        }),
        function(item) {
          return item.set('tread', isTread ? true : false)
        }
      )

      const next = state.set('list', list)

      return next
    }

    default:
      return state
  }
}

export default cardsReducer
