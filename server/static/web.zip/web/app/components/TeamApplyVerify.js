import React, {Component, PropTypes} from 'react'
import {bindActionCreators} from 'redux'
import {connect} from 'react-redux'
import AuthSingleCard from 'components/AuthSingleCard'
import Spinner from 'components/global/Spinner'
import PhoneInput from 'components/forms/PhoneInput'
import * as globalActions from 'actions/global'
import * as registerActions from 'actions/register'
import * as articleActions from 'actions/article'
import Avatar from 'components/Avatar'
import {VERIFY_TEAM_SUCCESS} from 'config/authPage'
import {Form, Input, Button} from 'react-validation/lib/build/validation.rc'
import {SubmitDecorator} from 'decorators'
import validator from 'validator'

const COUNT_DOWN_SECONDS = 60
class TeamApplyVerify extends Component {
  state = {
    loading: false,
    seconds: 0,
    countDown: false,

    phone: '',
    verifyCode: '',
    email: '',
    pic: this.props.pic
  }
  interval = null

  componentWillUnmount() {
    clearInterval(this.interval)
  }

  onChange(key, value) {
    this.setState({[key]: value})
    console.log('value',value)
  }

  uploadLogo(event) {
    const name = 'picFile'
    const formData = new FormData()
    formData.append(name, event.target.files[0])
    this.props.actions.uploadImg(formData, state => {
      const {fileName} = state.response.data
      console.log('value',fileName)
      this.onChange('pic', fileName)
    })
  }

  countDown() {
    this.setState({
      seconds: COUNT_DOWN_SECONDS
    })
    this.state.seconds = COUNT_DOWN_SECONDS
    this.interval = setInterval(() => {
      const seconds = this.state.seconds - 1
      if (seconds >= 0) {
        this.setState({
          seconds: this.state.seconds - 1
        })
      } else {
        clearInterval(this.interval)
      }
    }, 1000)
  }

  afterSuccess = () => {
    const {actions} = this.props
    window.setTimeout(() => {
      actions.showAuthWindow(VERIFY_TEAM_SUCCESS, {
        name: this.state.phone
      })
    }, 1000)
  }

  canBeSubmit = () => {
    const {pic, phone, verifyCode} = this.state
    return pic !== '' && this.isPhone(phone) && verifyCode !== ''
  }
  
  handleVerify = evt => {
    evt.preventDefault()
    const {verifyCode, phone} = this.state
    const {actions} = this.props
    actions.verifyCode({
      phone,
      verifyCode,
      channel: 4,
      afterSuccess: this.onSubmit,
      afterError: () => this.props.showError('验证码不正确')
    })
  }

  onSubmit = () => {
    const code = this.props.code
    const {pic, verifyCode, phone} = this.state
    if (code) {
      const payload = {
        confirmationtoken: code,
        email: this.props.email,
        pic,
        verifyCode,
        phone
      }
      this.setState({loading: true})
      this.props.actions.submitOrgVerifyInfo(
        payload,
        this.afterSuccess,
        state => {
          this.setState({loading: false})
          this.props.showError(state.message || '验证失败')
        }
      )
    } else {
      this.props.showError('缺失验证码')
    }
  }

  isPhone(phone) {
    return validator.isMobilePhone(phone.replace(/ /g, ''), 'zh-CN')
  }

  sendQRCode = () => {
    const {phone, seconds} = this.state
    if (!this.isPhone(phone)) {
      return this.props.showError('手机号无效')
    }
    if (seconds > 0) {
      return
    }
    const success = () => this.countDown()
    this.props.actions.sendCode({
      phone,
      channel: 4,
      afterSuccess: success
    })
  }

  render() {
    const {pic, phone, verifyCode, seconds, loading} = this.state
    return (
      <AuthSingleCard closeAuthModal={this.props.closeAuthModal}>
        <Form
          className="card-main team-apply-verify modal-form"
          onSubmit={this.handleVerify}>
          <div className="header">备案</div>
          <div className="main">
            <div className="step-2">
              <div className="m-change-avatar flexbox">
                <div className="action">
                  <input
                    type="file"
                    name="userPic"
                    id="avatar-file"
                    style={{display: 'none'}}
                    onChange={this.uploadLogo.bind(this)}
                  />
                  <label htmlFor="avatar-file">
                    <div className="change-avatar">
                      <Avatar
                        pic={pic}
                        defaultPic="/assets/images/default_avatar.svg"
                        width={60}
                      />

                      <div className="action">
                        <input
                          type="file"
                          name="userPic"
                          id="avatar-file"
                          style={{display: 'none'}}
                          onChange={this.uploadLogo.bind(this)}
                        />
                        <label htmlFor="avatar-file">修改头像</label>
                      </div>
                    </div>
                  </label>
                </div>
              </div>
              <div className="input">
                <div className="m-input-with-qrcode">
                  <PhoneInput
                    className="m-text"
                    containerClassName="field-wrapper"
                    errorClassName="error"
                    onChange={value => this.onChange('phone', value)}
                    value={phone}
                    placeholder="联系手机"
                    name="phone"
                    validations={['required', 'phone']}
                  />
                  <div className="qr-code" onClick={this.sendQRCode}>
                    {seconds > 0 ? `${seconds}s` : '验证码'}
                  </div>
                </div>
                <div className="input__tips">根据国家规定用户需要绑定个人手机号码</div>
              </div>
              <div className="input">
                <Input
                  type="text"
                  name="verifyCode"
                  className="m-text"
                  containerClassName="field-wrapper"
                  errorClassName="error"
                  onChange={e => this.onChange('verifyCode', e.target.value)}
                  value={verifyCode}
                  validations={['required']}
                  placeholder="验证码"
                />
              </div>
            </div>
          </div>
          <div className="footer flexbox btn-footer field-wrapper">
            <div />
            <Button
              type="submit"
              disabled={loading || !this.canBeSubmit()}
              className="btn btn-primary">
              {loading ? <Spinner /> : '下一步'}
            </Button>
            <div />
            {this.props.error &&
              <div className="form-error active">
                {this.props.error}
              </div>}
          </div>
        </Form>
      </AuthSingleCard>
    )
  }
}

function mapStateToProps(state) {
  return {
    code: state.global.getIn(['authWindowPrams', 'code']),
    email: state.global.getIn(['authWindowPrams', 'email']),
    pic: state.global.getIn(['authWindowPrams', 'pic']),
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(
      {
        showAuthWindow: globalActions.showAuthWindow,
        submitOrgVerifyInfo: registerActions.submitOrgVerifyInfo,
        sendCode: registerActions.sendCode,
        verifyCode: registerActions.verifyCode,
        addToast: globalActions.addToast,
        uploadImg: articleActions.uploadImg
      },
      dispatch
    )
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(
  SubmitDecorator(TeamApplyVerify)
)
