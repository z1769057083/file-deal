import React, { Component, PropTypes } from 'react'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import * as artisanActions from 'actions/artisan'
import Header from 'components/Header'
import CornerBar from 'components/CornerBar'
import ArtisanHeader from 'components/ArtisanHeader'
import CommunityUserList from 'components/CommunityUserList'
import PageStatus from 'components/PageStatus'
import UpgradeTips from 'components/UpgradeTips'

class HotRecommend extends Component {
  constructor(props, context) {
    super(props, context)
    this.state = {
      loading: false
    }
    this.onScroll = this.onScroll.bind(this)
  }

  componentDidMount() {
    window.addEventListener('scroll', this.onScroll)
    this._loadCards()
    this.props.actions.updateArtisan(['activeType'], 'recommend')
  }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.onScroll)
  }

  onScroll() {
    const isBottom = (window.innerHeight + window.scrollY) >= document.body.offsetHeight
    if (isBottom) {
      // this._loadCards()
    }
  }

  _loadCards() {
    if (!this.state.loading) {
      this.setState({
        loading: true
      })
      const payload = {
        page: 1,
        pageSize: 10
      }
      this.props.actions.getArtisanRecommend(payload, this._disableLoading.bind(this), this._disableLoading.bind(this))
    }
  }

  _disableLoading() {
    this.setState({
      loading: false
    })
  }

  render() {
    let items = this.props.recommendList

    let pageStatus = 'default'
    let statusHeight = 0

    if (this.state.loading) {
      pageStatus = 'loading'
    }

    if (items.length < 1) {
      statusHeight = 300
    }

    return (
      <div className="m-community m-header--wrap">
        <Header />
        <UpgradeTips width={1030} />
        <ArtisanHeader />
        <CommunityUserList type={1} items={items} />
        <PageStatus status={pageStatus} height={statusHeight} />
        <CornerBar />
      </div>
    )
  }
}

function mapStateToProps(state) {
  return {
    recommendList: state.artisan.get('recommendList').toJS(),
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      getArtisanRecommend: artisanActions.getArtisanRecommend,
      updateArtisan: artisanActions.updateArtisan
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(HotRecommend)
