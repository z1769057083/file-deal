import React, {Component, PropTypes} from 'react'
import {bindActionCreators} from 'redux'
import {connect} from 'react-redux'
import * as cardActions from 'actions/card'
import * as articleActions from 'actions/article'
import * as globalActions from 'actions/global'
import classNames from 'classnames'
import AnimateCheck from 'components/AnimateCheck'
import Spinner from 'components/global/Spinner'
import Confirm from 'components/global/Confirm'
import AddToTheme from './AddToTheme'
import RemoveFromTheme from './RemoveFromTheme'
import {LOGIN_USER_START} from 'config/authPage'
import {CopyToClipboard} from 'react-copy-to-clipboard'

const propTypes = {
  id: PropTypes.number.isRequired,
  type: PropTypes.number.isRequired,
  themeId: PropTypes.number,
  firstPic: PropTypes.string,
  isFavorite: PropTypes.string,
  title: PropTypes.string.isRequired,
  wechatUrl: PropTypes.string,
  hideLeft: PropTypes.bool,
  showInform: PropTypes.bool,
  showTrend: PropTypes.bool,
  showUnCollect: PropTypes.bool.isRequired
}
const defaultProps = {
  firstPic: '',
  themeId: 0,
  showTrend: false,
  showInform: false
}
class CardActionBar extends Component {
  constructor(props) {
    super(props)
    this.state = {
      collecting: false,
      // 绿洲中，第一次应该显示为 collected: true
      collected: this.props.showUnCollect ? true : false,
      isLiked: this.props.isFavorite === '1',
      isTread: false,
      wechatUrlInit: false,
      showEdit: false,

      // true: like button is pending
      likePending: false,
      treadPending: false,

      confirmOpen: false,

      copied: false,
    }
    this.inform = this.inform.bind(this)
    this.informSuccess = this.informSuccess.bind(this)
    this.informFail = this.informFail.bind(this)
    this.collect = this.collect.bind(this)
    this.handleTread = this.handleTread.bind(this)
  }

  componentWillReceiveProps(props) {
    if (props.isFavorite !== this.props.isFavorite) {
      this.setState({
        isLiked: props.isFavorite === '1'
      })
    }
  }

  like(event) {
    event.stopPropagation()
    event.preventDefault()

    if (!this.checkLogin()) {
      return
    }

    if (this.state.likePending) {
      return
    }

    this.setState({likePending: true})
    this.forceUpdate()

    const success = () => {
      const isLiked = !this.state.isLiked
      window.setTimeout(() => {
        const {id, type} = this.props

        this.setState({
          isLiked,
          likePending: false
        })
        this.forceUpdate()
        const name = type == 0 ? '手贴' : '作品'
        this.props.actions.addToast({
          type: 'black',
          message: isLiked ? `已成功大爱此${name}` : `已取消大爱此${name}`,
          pic: this.props.firstPic,
          timeout: 2500
        })

        if (type == 0) {
          this.props.actions.updateCardLike(id, isLiked)
        }
      }, 500)
    }
    const error = () => {
      this.props.actions.addToast({
        type: 'singleMsg',
        message: '操作失败',
        timeout: 1500
      })
      this.setState({
        likePending: false
      })
    }

    if (this.state.isLiked) {
      this.props.actions.unLikeCard(
        this.props.id,
        this.props.type,
        success,
        error
      )
    } else {
      this.props.actions.likeCard(
        this.props.id,
        this.props.type,
        success,
        error
      )
    }
  }

  handleTread(event) {
    event.stopPropagation()
    event.preventDefault()

    if (!this.checkLogin()) {
      return
    }

    if (this.state.treadPending) {
      return
    }

    this.setState({treadPending: true})
    this.forceUpdate()

    const success = () => {
      const isTread = !this.state.isTread
      window.setTimeout(() => {
        const {id, type} = this.props

        this.setState({
          isTread,
          treadPending: false
        })
        this.forceUpdate()
        const name = type == 0 ? '手贴' : '作品'
        this.props.actions.addToast({
          type: 'black',
          message: isTread ? `已成功踩此${name}` : `已取消踩此${name}`,
          pic: this.props.firstPic,
          timeout: 2500
        })

        if (type == 0) {
          this.props.actions.updateCardTread(id, isTread)
        }
      }, 500)
    }
    const error = () => {
      this.props.actions.addToast({
        type: 'singleMsg',
        message: '操作失败',
        timeout: 1500
      })
      this.setState({
        treadPending: false
      })
    }

    if (this.state.isTread) {
      this.props.actions.removeTread({articleId: this.props.id}, success, error)
    } else {
      this.props.actions.tread({articleId: this.props.id}, success, error)
    }
  }

  collect() {
    this.setState({confirmOpen: false})
    const {firstPic} = this.props
    if (!this.checkLogin()) {
      return
    }
    if (this.state.collecting) {
      return false
    }
    this.setState({
      collecting: true
    })
    this.forceUpdate()

    const successSelect = state => {
      const id = this.props.auth.get('id')
      const {bizMessage, bizCode} = state.response.data
      if (!this.state.collected) {
        this.props.actions.addToast({
          type: 'savedToOases',
          bizMessage,
          bizCode,
          pic: firstPic,
          link: `/user/${id}/oasis`,
          timeout: 5000
        })
      }
      this.setState({
        collecting: false
      })

      if (this.props.showUnCollect) {
        this.setState({collected: true})
      } else {
        window.setTimeout(() => {
          this.setState({
            collected: false
          })
        }, 3000)
      }
    }
    const successUnSelect = () => {
      this.props.actions.addToast({
        type: 'black',
        pic: firstPic,
        message: '签出成功',
        timeout: 2000
      })
      this.setState({
        collected: false,
        collecting: false
      })
    }
    const error = () => {
      this.setState({
        collecting: false
      })
      this.props.actions.addToast({
        type: 'singleMsg',
        message: '操作失败',
        timeout: 2000
      })
    }
    window.setTimeout(() => {
      if (this.state.collected) {
        this.props.actions.unCollectCard(
          this.props.id,
          this.props.type,
          successUnSelect,
          error
        )
      } else {
        this.props.actions.collectCard(
          this.props.id,
          this.props.type,
          successSelect,
          error
        )
      }
    }, 1000)
  }

  checkLogin() {
    if (this.props.auth.get('id') == undefined) {
      this.props.actions.showAuthWindow(LOGIN_USER_START)
      return false
    }
    return true
  }

  share(e) {
    e.stopPropagation()
    e.preventDefault()
  }

  getTitle() {
    const typeMapping = {
      0: '手贴',
      1: '有料',
      2: '云库'
    }
    return encodeURIComponent(
      '空中绿洲 - ' + typeMapping[this.props.type] + ' | ' + this.props.title
    )
  }

  wechat() {
    if (this.props.wechatUrl != '') {
      this.setState({
        wechatUrlInit: true
      })
    }
  }

  weibo() {
    window.open(
      'http://v.t.sina.com.cn/share/share.php?url=' +
        encodeURIComponent(location.href) +
        '&title=' +
        this.getTitle()
    )
  }

  facebook() {
    window.open(
      'http://www.facebook.com/share.php?u=' + encodeURIComponent(location.href)
    )
  }

  edit(e) {
    e.stopPropagation()
    e.preventDefault()
    if (!this.props.auth.get('id')) {
      this.props.actions.addToast({
        type: 'singleMsg',
        message: '请先登录',
        timeout: 2000
      })
      return
    }

    const dictInit = this.props.article.get('dictInit');
    console.log(dictInit,'dictInit')
    if (!dictInit) {
      this.props.actions.loadDict()
    }

    this.props.actions.loadArticleDetail(
      this.props.id,
      this.props.type,
      state => {
        const response = state.response.data
          console.log("alt111",response.alt)
        const article = {
          id: response.id,
          type: response.type,
          serialNo: response.serialNo,
          title: response.title,
          summary: response.summary,
          content: response.content,
          picSuite: response.picSuite,
          projectInfo: response.projectInfo,
          cooperation: response.cooperation,
          legalNotice: response.legalNotice,
            alt:response.alt
        }
        sessionStorage.setItem('article', response.id);

        this.props.actions.editArticle(article)
        this.props.actions.openArticleWindow()
      }
    )
  }

  getCollectStatus() {
    if (this.state.collecting) {
      return <Spinner />
    } else if (this.state.collected) {
      return <AnimateCheck />
    } else {
      return <div className="icon icon-tag-text" />
    }
  }

  informSuccess() {
    this.props.actions.addToast({
      type: 'black',
      message: '举报成功',
      pic: this.props.firstPic,
      timeout: 2500
    })
  }

  informFail() {
    this.props.actions.addToast({
      type: 'singleMsg',
      message: '举报失败',
      timeout: 1500
    })
  }

  inform() {
    const {id, type} = this.props
    const payload = {
      artid: id,
      arttype: type
    }
    this.props.actions.inform(payload, this.informSuccess, this.informFail)
  }

  handleDownload = () => {
    window.open(this.props.firstPic)
  }

  handleCopyLink = () => {
    this.setState({copied: true})
    this.props.actions.addToast({
      type: 'black',
      message: '复制链接成功',
      pic: this.props.firstPic,
      timeout: 2500
    })
  }

  getInformRender() {
    const link = window.location.href
    const index = link.indexOf("alt");
    const alt = index!==-1?link.substr((index+4)):'';
    console.log('alt',typeof alt)
    return (
      <div className="icon icon-inform">
        <div className="m-popover-share shim">
          <div className="menu">
            <div className="popover-title" onClick={this.handleDownload}>下载图片</div>
            <div className="popover-title" onClick={this.inform}>举报该贴</div>
              {
                  alt === 'true' ?
                      <CopyToClipboard text={link}
                                       onCopy={this.handleCopyLink}>
                          <div className="popover-title">复制链接</div>
                      </CopyToClipboard>
                      :
                      <div className="popover-title" style={{cursor:'auto',color:"#ccc"}}>复制链接</div>
              }
          </div>
        </div>
        <input type="hidden" ref="clipboard" value=""/>
      </div>
    )
  }

  getCollectRender() {
    const {firstPic, id, showUnCollect, themeId} = this.props
    if (showUnCollect && this.state.collected) {
      const data = {articleId: id, pic: firstPic || '', themeId}
      return <RemoveFromTheme data={data} />
    } else {
      return <AddToTheme articleId={id} img={firstPic || ''} />
    }
  }

  render() {
    const {type} = this.props
    const name = type === 0 ? '手贴' : '作品'
    const confirmProps = {
      isOpen: this.state.confirmOpen,
      close: () => this.setState({confirmOpen: false}),
      title: '签出绿洲',
      message: `确定将此${name}签出绿洲?`,
      onConfirm: this.collect
    }
    return (
      <div className="actions flexbox">
        {this.props.hideLeft
          ? null
          : <div className="left-side">
              {this.props.canEdit
                ? null
                : <span
                    className={classNames('icon icon-love', {
                      active: this.state.isLiked,
                      pending: this.state.likePending
                    })}
                    onClick={e => this.like(e)}>
                    {this.state.likePending
                      ? <span className="icon icon-pending" />
                      : null}
                  </span>}
              <div className="icon icon-share" onClick={e => this.share(e)}>
                <div className="m-popover-share">
                  <div className="popover-arrow" />
                  <div className="popover-title">分享此帖至</div>
                  <div className="popover-inner flexbox">
                    <div
                      className="item icon icon-wechat"
                      onClick={() => this.wechat()}>
                      {this.state.wechatUrlInit
                        ? <div className="qrcode">
                            <img src={this.props.wechatUrl} />
                          </div>
                        : null}
                    </div>
                    <div
                      className="item icon icon-facebook"
                      onClick={() => this.facebook()}
                    />
                    <div
                      className="item icon icon-weibo"
                      onClick={() => this.weibo()}
                    />
                  </div>
                </div>
              </div>
              {this.props.showTrend &&
                <span
                  className={classNames('icon icon-tread', {
                    active: this.state.isTread,
                    pending: this.state.treadPending
                  })}
                  onClick={this.handleTread}>
                  {this.state.treadPending
                    ? <span className="icon icon-pending" />
                    : null}
                </span>}
              {this.props.showInform && this.getInformRender()}
              {this.props.canEdit
                ? <span
                    className="icon icon-edit"
                    onClick={e => this.edit(e)}
                  />
                : null}
            </div>}
        <div className="right-side flex">
          {this.getCollectRender()}
          <Confirm {...confirmProps} />
        </div>
      </div>
    )
  }
}

CardActionBar.propTypes = propTypes

function mapStateToProps(state, ownProps) {
  return {
    auth: state.auth,
    article: state.article
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(
      {
        collectCard: cardActions.collectCard,
        unCollectCard: cardActions.unCollectCard,
        likeCard: cardActions.likeCard,
        unLikeCard: cardActions.unLikeCard,
        updateCardLike: cardActions.updateCardLike,
        tread: articleActions.tread,
        removeTread: articleActions.removeTread,
        updateCardTread: cardActions.updateCardTread,

        addToast: globalActions.addToast,
        inform: globalActions.inform,
        showAuthWindow: globalActions.showAuthWindow,
        loadArticleDetail: cardActions.loadArticleDetail,
        editArticle: articleActions.editArticle,

        openArticleWindow: articleActions.openArticleWindow,
        loadDict: articleActions.loadDict
      },
      dispatch
    )
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(CardActionBar)
