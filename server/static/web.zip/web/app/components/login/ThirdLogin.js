/**
 * third party login
 */
import React, { Component, PropTypes } from 'react'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import * as authActions from 'actions/auth'
import * as globalActions from 'actions/global'
import _ from 'lodash'

class ThirdLogin extends Component {
  constructor(props) {
    super(props)
    this.wechat = this.wechat.bind(this)
    this.weibo = this.weibo.bind(this)
    this.facebook = this.facebook.bind(this)
    this.success = this.success.bind(this)
    this.fail = this.fail.bind(this)
    this.checkLogin = this.checkLogin.bind(this)
  }

  openWindow(url, title, onClose, fullScreen) {
    const winWidth = 700
    const winHeight = 500
    const left = (screen.width - winWidth) / 2
    const top = (screen.height - winHeight) / 2
    const features = fullScreen ? '' :
      `location=1,status=1,scrollbars=1,width=${winWidth},height=${winHeight},left=${left},top=${top}`
    const win = window.open(url, title, features)

    let cancel = () => {}
    if (onClose && win && !_.isUndefined(win.closed)) {
      const interval = setInterval(() => {
        if (win && win.closed) {
          clearInterval(interval)
          onClose()
        }
      }, 500)

      cancel = () => {
        clearInterval(interval)
        win.close()
      }
    }

    setTimeout(cancel, 10 * 60 * 1000) //最多10分钟
  }

  wechat() {
    const url = 'https://open.weixin.qq.com/connect/qrconnect?appid=wxfbf76eab97a18708&redirect_uri=' +
      'http%3A%2F%2Fwww.airoases.com%2Fapi%2Fv1%2Fopen%2Fauth%2Fwxlogin&response_type=code&' +
      'scope=snsapi_login&state=1#wechat_redirect'
    this.openWindow(url, '微信登录', this.checkLogin)
  }

  weibo() {
    const url = 'https://api.weibo.com/oauth2/authorize?client_id=3713629030&response_type=code&' +
      'redirect_uri=http://www.airoases.com/api/v1/open/auth/wblogin'
    this.openWindow(url, '微博登录', this.checkLogin)
  }

  facebook() {

  }

  success() {
    this.props.actions.addToast({
      type: 'black',
      message: '已成功登录',
      pic: this.props.avatar,
      timeout: 2000,
      callback: this.props.afterSuccess
    })
  }

  fail() {
    this.props.actions.addToast({
      type: 'singleMsg',
      message: '登录失败',
      timeout: 2000,
    })
  }

  checkLogin() {
    this.props.actions.getAuthInfo(() => {
      if (this.props.homePage) {
        this.success()
      } else {
        this.fail()
      }
    }, this.fail)
  }

  render() {
    return (
      <div className="third-party flexbox">
        <div className="item flex">
          <div className="icon icon-wechat" onClick={this.wechat}></div>
        </div>
        <div className="item flex">
          <div className="icon icon-weibo" onClick={this.weibo}></div>
        </div>
        <div className="item flex">
          <div className="icon icon-facebook" onClick={this.facebook}></div>
        </div>
      </div>
    )
  }
}

ThirdLogin.propTypes = {
  afterSuccess: PropTypes.func
}

ThirdLogin.defaultProps = {
  afterSuccess: () => {}
}

function mapStateToProps(state) {
  return {
    homePage: state.auth.get('homePage'),
    avatar: state.auth.get('pic')
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      getAuthInfo: authActions.getAuthInfo,
      addToast: globalActions.addToast
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(ThirdLogin)