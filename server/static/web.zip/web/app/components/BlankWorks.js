import React, {Component, PropTypes} from 'react'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import * as globalActions from 'actions/global'
import {
  PRO_APPLY
} from 'config/authPage'

class BlankWorks extends Component {
  render() {
    const isProOrTeam = this.props.userType !== '0'
    if (this.props.isSelf) {
      if (isProOrTeam) {
        return <div className="m-blank-works">
          <div className="no-works">
            你仍未发布过任何作品， <br/>
            发布作品可以让更多人了解你的经历和背景。
          </div>
        </div>
      } else {
        const applyStatus = this.props.auth.get('applyStatus')
        const tips = applyStatus === 1 ? <p>
          PRO升级正在审核中。<br/>3-5个工作日通过短信和邮件通知。<br/>
        </p>: <p>
          仅 PRO 用户拥有作品展示区， <br/>
          点击 <span className="upgrade"
                   onClick={() => this.props.actions.showAuthWindow(PRO_APPLY)}>此处</span> 将您的账户升级为 PRO。
        </p>
        return (
          <div className="m-blank-works">
            <div className="color-palette flexbox">
              <div className="flex column flexbox">
                <div className="b1"></div>
                <div className="b2"></div>
                <div className="b3"></div>
                <div className="b4"></div>
              </div>
              <div className="flex column flexbox">
                <div className="b5"></div>
                <div className="b7"></div>
                <div className="b7"></div>
                <div className="b8"></div>
              </div>
            </div>
            <div className="tips">
              {tips}
            </div>
          </div>
        )
      }
    } else {
      if (isProOrTeam) {
        return <div className="m-blank-works">
          <div className="no-works">此PRO／团体仍未发布过任何作品。</div>
        </div>
      } else {
        return <div className="m-blank-works">
          <div className="no-works">此用户为个人用户，没有权限发布作品。</div>
        </div>
      }
    }
  }
}

BlankWorks.propTypes = {
  userType: PropTypes.string,
  isSelf: PropTypes.bool,
}

function mapStateToProps(state) {
  return {
    auth: state.auth
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      showAuthWindow: globalActions.showAuthWindow
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(BlankWorks)