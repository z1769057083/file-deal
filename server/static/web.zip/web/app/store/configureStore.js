import { createStore, applyMiddleware } from 'redux'
import thunkMiddleware from 'redux-thunk'
import apiMiddleware from '../middleware/api'
import createLogger from 'redux-logger'
import rootReducer from '../reducers'
import Immutable from 'immutable'
import {canUseDom} from 'util/index'

const logger = createLogger({
  level: 'info',
  collapsed: false,
  logger: console,
  predicate: (getState, action) => true
})

const createStoreWithMiddleware = applyMiddleware(
  thunkMiddleware,
  apiMiddleware,
  logger
)(createStore)

export default function configureStore(initialState) {
  const args = [rootReducer, initialState]
  if (canUseDom() && window.__REDUX_DEVTOOLS_EXTENSION__) {
    args.push(
      window.__REDUX_DEVTOOLS_EXTENSION__({
        serialize: {
          immutable: Immutable
        }
      })
    )
  }
  const store = createStoreWithMiddleware(...args);

  if (module.hot) {
    // Enable Webpack hot module replacement for reducers
    module.hot.accept('../reducers', () => {
      const nextRootReducer = require('../reducers')
      store.replaceReducer(nextRootReducer)
    })
  }

  return store
}
