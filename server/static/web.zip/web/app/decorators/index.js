/**
 * decorators
 */
import React, {Component} from 'react'

/**
 * provide showError/hideError method
 * will hideError() when click on document
 */
const SubmitDecorator = (WrappedComponent) => {
  return class extends Component {
    constructor(props) {
      super(props)
      this.state = {
        error: ''
      }
      this.showError = this.showError.bind(this)
      this.hideError = this.hideError.bind(this)
    }
    componentDidMount() {
      document.addEventListener('click', this.hideError)
    }
    componentWillUnmount() {
      document.removeEventListener('click', this.hideError)
    }
    showError(error) {
      this.setState({error})
    }
    hideError() {
      this.setState({error: ''})
    }
    render() {
      return <WrappedComponent {...this.props}
        error={this.state.error}
        showError={this.showError}
        hideError={this.hideError}
        />
    }
  }
}

export {SubmitDecorator}