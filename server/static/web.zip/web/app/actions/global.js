import { CALL_API, CHAIN_API } from 'middleware/api'

export const UPDATE_GLOBAL = Symbol('UPDATE_GLOBAL')
export function updateGlobal(key, value) {
  return {
    type: UPDATE_GLOBAL,
    key,
    value
  }
}

export const ADD_TOAST = Symbol('ADD_TOAST')
let tid = 0
/**
 * @param toast {type: 'savedToOases', timeout: 0}, type is required, timeout is 0 as default
 */
export function addToast(toast) {
  toast.timemout = toast.timemout || 0
  toast.tid = tid++
  return {
    type: ADD_TOAST,
    toast
  }
}

export const REMOVE_TOAST = Symbol('REMOVE_TOAST')
export function removeToast(tid) {
  return {
    type: REMOVE_TOAST,
    tid
  }
}

export const SHOW_UPGRADE_TIPS = Symbol('SHOW_UPGRADE_TIPS')
export function showUpgradeTips() {
  return {
    type: SHOW_UPGRADE_TIPS
  }
}

export const HIDE_UPGRADE_TIPS = Symbol('HIDE_UPGRADE_TIPS')
export function hideUpgradeTips() {
  return {
    type: HIDE_UPGRADE_TIPS
  }
}

export const SHOW_AUTH_WINDOW = Symbol('SHOW_AUTH_WINDOW')
export function showAuthWindow(authWindowType, params) {
  return {
    type: SHOW_AUTH_WINDOW,
    authWindowType,
    params
  }
}

export const HIDE_AUTH_WINDOW = Symbol('HIDE_AUTH_WINDOW')
export function hideAuthWindow() {
  return {
    type: HIDE_AUTH_WINDOW
  }
}

export const INFORM = Symbol('INFORM')
/**
 * 举报
 * @param query
 * {artid: 123, arttype: 0} // 0：手帖；1：有料；2：云库
 */
export function inform(query, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'get',
      path: '/api/v1/open/inform',
      query,
      successType: INFORM,
      afterSuccess,
      afterError
    }
  }
}