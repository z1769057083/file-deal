import React, {Component, PropTypes} from 'react'
import {bindActionCreators} from 'redux'
import {connect} from 'react-redux'
import * as artisanActions from 'actions/artisan'
import Header from 'components/Header'
import CornerBar from 'components/CornerBar'
import ArtisanHeader from 'components/ArtisanHeader'
import CommunityUserList from 'components/CommunityUserList'
import PageStatus from 'components/PageStatus'
import UpgradeTips from 'components/UpgradeTips'
import {debounce} from 'lodash'

class DesignerHome extends Component {
  constructor(props, context) {
    super(props, context)
    this.state = {
      loading: false,
      pageNum: 0
    }
  }

  doScroll() {
    const dom = document.documentElement; 
    const isBottom = dom.scrollTop + dom.clientHeight >= dom.scrollHeight - 150
    console.log(isBottom)
    if (isBottom) {
      this._loadMoreCards()
      this.props.actions.updateArtisan(['activeType'], 'designer')
    }
  }

  componentDidMount() {
    this._loadCards()
    this.props.actions.updateArtisan(['activeType'], 'designer')
    this.doScroll.bind(this)();
    window.addEventListener('scroll', debounce(this.doScroll.bind(this),150), false);
  }
  _loadMoreCards() {
    if (!this.state.loading) {
      this.setState({
        pageNum: this.state.pageNum+1,
        loading: true
      }, () => {
        if(this.state.pageNum <= this.props.designers.length) {
          this.props.actions.getArtisanDesigner(this.props.designers[this.state.pageNum],this._disableLoading.bind(this),
          this._disableLoading.bind(this))
        }else{
          this.setState({
            loading: false
          });
        }
        
      })
    }
  }
  _loadCards() {
    if (!this.state.loading) {
      this.setState({
        loading: true
      })

      this.props.actions.getArtisanDesignerHome(
        this._disableLoading.bind(this),
        this._disableLoading.bind(this)
      )
    }
  }

  _disableLoading() {
    this.setState({
      loading: false
    })
  }

  render() {
    let items = this.props.firstPage.concat(this.props.designerList);
    console.log(this.props.designerList,'this.props.designerListthis.props.designerList')
    let pageStatus = 'default'
    let statusHeight = 0

    if (this.state.loading) {
      pageStatus = 'loading'
    }

    if (items.length < 1) {
      statusHeight = 300
    }

    return (
      <div className="m-community m-header--wrap">
        <Header />
        <UpgradeTips width={1030} />
        <ArtisanHeader />
        <CommunityUserList type={1} items={items} />
        <PageStatus status={pageStatus} height={statusHeight} />
        <CornerBar />
      </div>
    )
  }
}

function mapStateToProps(state) {
  return {
    firstPage: state.artisan.getIn(['home', 'firstPage']).toJS(),
    designers: state.artisan.getIn(['home', 'designers']).toJS(),
    designerList: state.artisan.get('designerList').toJS()
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(
      {
        getArtisanDesignerHome: artisanActions.getArtisanDesignerHome,
        getArtisanDesigner: artisanActions.getArtisanDesigner,
        updateArtisan: artisanActions.updateArtisan
      },
      dispatch
    )
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(DesignerHome)
