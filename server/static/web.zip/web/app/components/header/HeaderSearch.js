/**
 * Created by xijinling on 2017/7/19.
 */
import React, {Component, PropTypes} from 'react'
import {bindActionCreators} from 'redux'
import {connect} from 'react-redux'
import {addSearchHistory} from 'util/local'
import _ from 'lodash'
import cx from 'classnames'
import * as searchActions from 'actions/search'

class HeaderSearch extends Component {
  constructor() {
    super()
    this.onSearchClick = this.onSearchClick.bind(this)
    this.onSearchFocus = this.onSearchFocus.bind(this)
    this.onSearchChange = this.onSearchChange.bind(this)
    this.onDocumentClick = this.onDocumentClick.bind(this)
    this.onKeyup = this.onKeyup.bind(this)
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.word !== this.props.word) {
      this.setState({keyword: nextProps.word})
    }

    if (nextProps.isOpen !== this.props.isOpen) {
      nextProps.isOpen
        ? document.addEventListener('click', this.onDocumentClick)
        : document.removeEventListener('click', this.onDocumentClick)
    }
  }

  onDocumentClick(evt) {
    const search = this.refs.search
    if (search && !search.contains(evt.target) && this.props.isOpen) {
      this.props.actions.updateSearch('isOpen', false)
    }
  }

  onSearchClick() {
    const {keyword} = this.props
    location.href = `/search?word=${keyword}`
  }

  onSearchFocus() {
    this.props.actions.updateSearch('isOpen', true)
  }

  onSearchChange(e) {
    const keyword = e.target.value
    const {actions} = this.props
    actions.updateSearch('keyword', keyword)
    if (!this.throttledComplete) {
      this.throttledComplete = _.throttle(
        this.props.actions.getArticleComplete,
        500,
        {leading: false}
      )
    }
    if (keyword !== '') {
      this.throttledComplete(keyword)
    }
  }

  clearKeyword() {
    this.props.actions.updateSearch('keyword', '')
    if (location.pathname !== '/') {
      location.href = '/'
    }
  }

  onKeyup(e) {
    const {keyword} = this.props
    if (!keyword) return
    switch (e.keyCode) {
      case 13:
        addSearchHistory(keyword)
        location.href = `/search?word=${keyword}`
        break
    }
  }

  render() {
    const {keyword} = this.props
    const showClose = keyword !== ''
    return (
      <div className="side center-part">
        <div className="search-box" ref="search">
          <div className="icon icon-search" onClick={this.onSearchClick} />
          <input
            type="text"
            value={keyword}
            placeholder="Search"
            onFocus={this.onSearchFocus}
            onKeyUp={this.onKeyup}
            onChange={this.onSearchChange}
          />
          <span
            href="/"
            className={cx("icon icon-clear", {active: showClose})}
            onClick={this.clearKeyword.bind(this)}
          />
        </div>
      </div>
    )
  }
}

function mapStateToProps(state) {
  return {
    isOpen: state.search.get('isOpen'),
    word: state.search.get('word'),
    keyword: state.search.get('keyword')
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(
      {
        updateSearch: searchActions.updateSearch,
        getArticleComplete: searchActions.getArticleComplete
      },
      dispatch
    )
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(HeaderSearch)
