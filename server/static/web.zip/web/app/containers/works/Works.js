import React, { Component, PropTypes } from 'react'
import { connect } from 'react-redux'
import {bindActionCreators } from 'redux'
import Modal from 'react-modal'
import Header from 'components/Header'
import CornerBar from 'components/CornerBar'
import WorksDetail from 'components/works/WorksDetail'
import UpgradeTips from 'components/UpgradeTips'
import Toast from 'components/Toast'
import * as cardActions from 'actions/card'
import { browserHistory } from 'react-router'

const customStyles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    zIndex: 200
  },
  content: {
    top: '0',
    left: '0',
    right: '0',
    height: '100%',
    border: 'none',
    position: 'relative',
    background: 'transparent',
    padding: '0'
  }
}
class Works extends Component {
  constructor(props) {
    super(props)
    this.state = {
      // ReactModal__Content 滑动到底部
      bottom: false
    }
    this._onKeyup = this._onKeyup.bind(this)
    this.parentSelector = this.parentSelector.bind(this)
  }
  componentDidMount() {
    document.addEventListener('keyup', this._onKeyup)
    const {cards} = this.props
    const inModal = cards.get('inModal')
    if (inModal) {
      document.body.classList.add('modal-is-open')
    }
  }
  componentWillUnmount() {
    document.removeEventListener('keyup', this._onKeyup)
    document.body.classList.remove('modal-is-open')
    this._closeModal()
  }
  _onKeyup(e) {
    switch(e.keyCode) {
      // ESC
      case 27:
        this._closeModal()
        break
    }
  }
  _closeModal() {
    if (!this.props.cards.get('inModal')) {
      return
    }
    const returnTo = this.props.cards.get('returnTo')
    this.props.actions.updateCardMode({
      inModal: false,
      contextCards: [],
      returnTo: ''
    })
    browserHistory.push(returnTo)
  }
  parentSelector() {
    return document.querySelector('#m-works')
  }
  render() {
    const cards = this.props.cards
    const inModal = cards.get('inModal')
    const type = this.props.location.query.type || 0
    return inModal ?
      <div className="m-works" id="m-works">
        <Modal
          style={customStyles}
          contentLabel="Modal"
          parentSelector={this.parentSelector}
          isOpen={true}>
          <WorksDetail id={this.props.id}
                       inModal={true}
                       onRequestClose={this._closeModal.bind(this)}
                       type={type} />
          <Toast />
        </Modal>
      </div> :
      <div className="m-works m-header--wrap">
        <Header />
        <CornerBar />
        <WorksDetail
          id={this.props.id}
          type={type}
          inModal={false}
          />
      </div>
  }
}

function mapStateToProps (state, ownProps) {
  return {
    id: ownProps.params.id,
    cards: state.cards
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      updateCardMode: cardActions.updateCardMode
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Works)
