import React, {PropTypes} from 'react'
import Modal from 'react-modal'
import {connect} from 'react-redux'
import BlockImages from './BlockImages'

const customStyles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    overflow: 'scroll',
    zIndex: 300
  },
  content: {
    border: 'none',
    padding: '0px 0px 36px',
    position: 'relative',
    borderRadius: '6px',
    width: '400px'
  }
}
class ArticleSuccess extends React.Component {
  render() {
    const {isOpen, onRequestClose, viewTopic, article} = this.props
    const articles = article.get('articles').toJS()
    return (
      <Modal
        isOpen={isOpen}
        onRequestClose={onRequestClose}
        style={customStyles}
        overlayClassName="modal-new-pin"
        contentLabel="Modal">
        <div className="header white-version">
          <div className="title">完成发布</div>
          <div className="icon icon-close-white" onClick={onRequestClose} />
        </div>
        <div className="main">
          <div className="m-multi-modal">
            <div className="modal-article-success">
              <div className="article__blocks">
                <BlockImages preview={true} data={articles} />
              </div>
              <div className="article__tips">
                已完成发布，签入至「{article.get('theme')}」 主题下
              </div>
              <div
                className="article__view btn btn-primary"
                onClick={viewTopic}>
                去往主题
              </div>
              <div className="article__ignore btn" onClick={onRequestClose}>
                去往首页
              </div>
            </div>
          </div>
        </div>
        <div className="footer" />
      </Modal>
    )
  }
}

ArticleSuccess.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  onRequestClose: PropTypes.func.isRequired,
  viewTopic: PropTypes.func.isRequired
}

const mapStateToProps = state => ({
  article: state.article
})

export default connect(mapStateToProps)(ArticleSuccess)
