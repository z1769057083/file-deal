let config = {
  API_BASE_URL: process.env.API_BASE_URL || '//oasis.apptravel.cn'
}

export default config;
