/**
 * global variables
 */

import * as ActionType from 'actions/global'
import {fromJS} from 'immutable'
import _ from 'lodash'

let defaultState = fromJS({
  worksInModal: false,
  hasModal: false,

  init: false, // loaded user info, set it as true

  showUpgradeTips: false,
  showAuthWindow: false,
  authWindowType: '',
  authWindowPrams: {},

  toasts: []
})

function globalReducer(state = defaultState, action) {
  switch (action.type) {
    case ActionType.UPDATE_GLOBAL:
      return state.set(action.key, action.value)

    case ActionType.ADD_TOAST:
      const toast = action.toast
      return state.set('toasts', fromJS([toast]))

    case ActionType.REMOVE_TOAST:
      const tid = action.tid
      const toasts = state.get('toasts').toJS()
      return state.set('toasts', fromJS(_.filter(toasts, (item) => {
        return item.tid !== tid
      })))

    case ActionType.SHOW_UPGRADE_TIPS:
      return state.set('showUpgradeTips', true)

    case ActionType.HIDE_UPGRADE_TIPS:
      return state.set('showUpgradeTips', false)

    case ActionType.SHOW_AUTH_WINDOW:
      return state.set('showAuthWindow', true)
        .set('authWindowType', action.authWindowType)
        .set('authWindowPrams', fromJS(action.params || {}))

    case ActionType.HIDE_AUTH_WINDOW:
      return state.set('showUpgradeTips', false)
        .set('authWindowType', '')
        .set('authWindowPrams', fromJS({}))

    default:
      return state
  }
}

export default globalReducer