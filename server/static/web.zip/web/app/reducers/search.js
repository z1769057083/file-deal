/**
 * Created by xijinling on 2017/7/19.
 */
import * as ActionType from 'actions/search'
import {fromJS} from 'immutable'

let defaultState = fromJS({
  sortId: -1,
  isEnd: false,
  list: [],
  classList: [],
  word: '',
  keyword: '',//temporary word

  suggestion: [],
  isOpen: false,

  inModal: false,
  contextCards: [],
  returnTo: '/',

  hotWords: []
})

function cardsReducer(state = defaultState, action) {
  switch (action.type) {
    case ActionType.GET_ARTICLE_SEARCH:
      const newData = action.response.data
      const isEnd = newData.artList.length < newData.pageSize
      const sortId = newData.lastSortId
      if (newData.artList.length > 0) {
        newData.artList[newData.artList.length - 1].nextPage = {
          isEnd,
          path: '/api/v1/open/article/search',
          query: {
            sortId: sortId,
            word: state.get('word')
          }
        }
      }
      let newState = state.set('list', state.get('list')
        .concat(fromJS(newData.artList)))
        .set('isEnd', isEnd)
        .set('sortId', sortId)
      if(state.get('classList').size === 0) {
        return newState.set('classList', fromJS(newData.classList))
      }
      return newState

    case ActionType.UPDATE_SEARCH:
      return state.set(action.key, action.value)

    case ActionType.GET_HOT_WORDS:
      return state.set('hotWords', fromJS(action.response.data))

    case ActionType.GET_ARTICLE_COMPLETE:
      return state.set('suggestion', fromJS(action.response.data.slice(0, 10)))

    case ActionType.RESET:
      return defaultState.set('hotWords', state.get('hotWords'))

    default:
      return state
  }
}

export default cardsReducer

