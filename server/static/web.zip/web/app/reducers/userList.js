import * as ActionType from 'actions/userList'
import Immutable from 'immutable'

let defaultState = Immutable.fromJS([])
function userListReducer (state = defaultState, action) {
  switch(action.type) {
    case ActionType.LOADED_USER_LIST:
      return state.concat(Immutable.fromJS(action.response))
    default:
      return state
  }
}

export default userListReducer