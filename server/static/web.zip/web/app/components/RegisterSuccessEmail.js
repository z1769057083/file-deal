import React, {Component, PropTypes} from 'react'
import {bindActionCreators} from 'redux'
import {connect} from 'react-redux'
import AuthSingleCard from 'components/AuthSingleCard'
import * as globalActions from 'actions/global'
import {VERIFY_TEAM_START} from 'config/authPage'

class RegisterSuccessEmail extends Component {
  render() {
    return (
      <AuthSingleCard closeAuthModal={this.props.closeAuthModal}>
        <div className="card-main register-success">
          <div className="header">注册</div>
          <div className="main">
            <p className="account">
              {this.props.email}
            </p>
            <div className="icon icon-success" />
            <p className="p2">邮箱已激活！</p>
          </div>
          <div className="footer flexbox single-button">
            <div
              className="btn btn-primary"
              onClick={() => {
                this.props.actions.showAuthWindow(
                  VERIFY_TEAM_START,
                  this.props.query
                )
              }}>
              indie备案
            </div>
          </div>
        </div>
      </AuthSingleCard>
    )
  }
}

function mapStateToProps(state, ownProps) {
  return {
    email: state.global.getIn(['authWindowPrams', 'email']),
    query: state.global.get('authWindowPrams').toJS()
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(
      {
        showAuthWindow: globalActions.showAuthWindow
      },
      dispatch
    )
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(
  RegisterSuccessEmail
)
