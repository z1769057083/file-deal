import React, {PropTypes} from 'react'
import AddToThemeForm from './AddToThemeForm'
import ThemeNewSubject from './ThemeNewSubject'
import Modal from 'react-modal'

const customStyles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    overflow: 'scroll',
    zIndex: 200
  },
  content: {
    border: 'none',
    padding: '0px 0 20px 0',
    position: 'relative',
    borderRadius: '6px',
    left: 0,
    right: 0
  }
}
class AddToTheme extends React.Component {
  state = {
    isOpen: false,
    page: 'subject' //subject/subject_creation
  }

  handleClick = evt => {
    evt.stopPropagation()
    evt.preventDefault()
    this.setState({isOpen: true})
  }

  handleClose = () => this.setState({isOpen: false})

  handlePage = page => () => this.setState({page})

  render() {
    const {img, articleId} = this.props
    const {isOpen, page} = this.state
    return (
      <div className="icon icon-tag" onClick={this.handleClick}>
        <div className="icon icon-tag-text" />
        <Modal
          isOpen={isOpen}
          onRequestClose={this.handleClose}
          style={customStyles}
          overlayClassName="modal-new-pin"
          contentLabel="Modal">
          <div className="header white-version">
            <div className="title">签入主题</div>
            <div className="icon icon-close-white" onClick={this.handleClose} />
          </div>
          <div className="main">
            {page === 'subject' &&
              <AddToThemeForm
                handleClose={this.handleClose}
                img={img}
                articleId={articleId}
                createSubject={this.handlePage('subject_creation')}
              />}
            {page === 'subject_creation' && <ThemeNewSubject
              img={img}
              articleId={articleId}
              handleNext={this.handlePage('subject')}
            />}
          </div>
        </Modal>
      </div>
    )
  }
}

AddToTheme.propTypes = {
  img: PropTypes.string.isRequired,
  articleId: PropTypes.number.isRequired
}

export default AddToTheme
