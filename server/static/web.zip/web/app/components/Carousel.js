import React, { Component, PropTypes } from 'react'
import ReactSwipe from 'react-swipe';

// generate slide panes
const numberOfSlides = 10;
const paneNodes = Array.apply(null, Array(numberOfSlides)).map((_, i) => {
  return (
    <div key={i}>
    {i==1 ?
        <div className="swiper-slide"><img src="/assets/images/sample.jpg" /></div>
        :<div className="swiper-slide">PANE {i}</div>
    }
    </div>
  );
});

class Carousel extends Component {

  constructor(props, context) {
    super(props, context);
    this.state = {
      currentSlide: this.props.startSlide? this.props.startSlide: 0
    }
    this.onKeyup = this.onKeyup.bind(this)
  }

  onKeyup(e) {
    switch(e.keyCode) {
      case 37:
        this.prev()
        break
      case 39:
        this.next()
        break
      default:
        break
    }
  }

  componentDidMount() {
    document.addEventListener('keyup', this.onKeyup)
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.onKeyup)
  }

  next() {
    this.refs.reactSwipe.next()
    this.setState({currentSlide: this.getPos()})
  }

  prev() {
    this.refs.reactSwipe.prev();
    this.setState({currentSlide: this.getPos()})
  }

  getPos() {
    return this.refs.reactSwipe.getPos()
  }

  getNumSlides(pics) {
    if(!pics){
      return numberOfSlides
    }
    //this.refs.reactSwipe.getNumSlides();
    return pics.length
  }

  renderSwipe(pics) {
    // change Swipe.js options by query params
    const {startSlide} = this.props
    const swipeOptions = {
      startSlide,
      auto: 0,
      speed: 10,
      disableScroll: false,
      continuous: true,
      callback() {
      },
      transitionEnd() {
      }
    };
    return (
      <ReactSwipe ref="reactSwipe" className="swiper-wrapper" swipeOptions={swipeOptions}>
        { pics?
          pics.map((item, key) => {
            return (
              <div className="swiper-slide" key={key}><img src={item.fileName} alt="" /></div>
            )
          }): paneNodes
        }
      </ReactSwipe>
    )
  }

  render() {
    const pics = this.props.pictures
    return (
      <div className="m-carousel">
        <div className="close icon assasss icon-close-white" onClick={(e) => {
          this.props.onRequestClose();
        }}></div>
        <div className="item total">
          <span className="p1">{this.state.currentSlide+1}</span>/
          <span className="p2">{this.getNumSlides(pics)}</span>
        </div>
        <div className="m-swipe">
          {this.renderSwipe(pics)}
          <a className="swiper-btn swiper-btn-prev" type="button" onClick={this.prev.bind(this)}></a>
          <a className="swiper-btn swiper-btn-next" type="button" onClick={this.next.bind(this)}></a>
        </div>
        <div className="item img-intro">{pics[this.state.currentSlide].picDesc}</div>
      </div>
    )
  }

}

Carousel.propTypes = {

}

export default Carousel
