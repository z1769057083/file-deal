/**
 * 团体用户 密码找回最后一步：显示已重置成功，引导重新登录
 */
import React, { Component, PropTypes } from 'react'
import AuthSingleCard from 'components/AuthSingleCard'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import {
  LOGIN_TEAM_START
} from 'config/authPage'

class RetrieveSuccess extends Component {
  constructor(props) {
    super(props)
    this.onClick = this.onClick.bind(this)
  }
  onClick() {
    this.props.switchPage(LOGIN_TEAM_START)
  }
  render() {
    return (
      <AuthSingleCard closeAuthModal={this.props.closeAuthModal}>
        <div className="card-main register-success">
          <div className="header">密码找回</div>
          <div className="main">
            <p className="account">{this.props.register.get('forgetEmail')}</p>
            <div className="icon icon-success"></div>
            <p className="p2">密码重置成功！</p>
          </div>
          <div className="footer flexbox single-button">
            <div className="btn btn-primary" onClick={this.onClick}>重新登录</div>
          </div>
        </div>
      </AuthSingleCard>
    )
  }
}

RetrieveSuccess.propTypes = {
  switchPage: PropTypes.func
}

function mapStateToProps(state) {
  return {
    register: state.register,
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(RetrieveSuccess)
