import React, { Component, PropTypes } from 'react'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import UserList from 'components/UserList'
import TypeNav from 'components/TypeNav'
import * as userActions from 'actions/user'

class UserFollowers extends Component {
  constructor(props) {
    super(props)
    this.state = {
      type: 0
    }
  }
  componentDidMount() {
    const user = this.props.user
    if (!user.get('followersInit')) {
      this._loadData(this.state.type)
    }
  }
  componentWillUnmount() {
    this.props.actions.resetFollowers()
  }
  _loadData(type) {
    const user = this.props.user
    this.props.actions.getFollowers({
      ownerid: user.getIn(['userInfo', 'ownerId']),
      sortid: -1,
      attentiontype: type
    })
  }
  _changeType(type) {
    this._loadData(type)
    this.setState({
      type
    })
  }
  render() {
    if (!this.props.user.get('followersInit')) {
      return null
    }
    const items = this.props.user.getIn(['followers', 'userList']).toJS()
    return (
      <div className="user-followers">
        <TypeNav type={this.state.type} mode="followers"
                 onChange={this._changeType.bind(this)} />
        <UserList items={items} tips="还没有被人关注过。" />
      </div>
    )
  }
}

function mapStateToProps (state) {
  return {
    user: state.user
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      getFollowers: userActions.getFollowers,
      resetFollowers: userActions.resetFollowers,
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(UserFollowers)
