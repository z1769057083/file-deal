/**
 * ICP备案
 */
import React, { Component, PropTypes } from 'react'
import cx from 'classnames'
import cookie from 'react-cookie'

class ICPFooter extends Component {
  constructor(props) {
    super(props)
    this.state = {
      hide: cookie.load('hide_icp') === 1
    }
    this.hideICP = this.hideICP.bind(this)
  }
  hideICP() {
    const maxAge = 30 * 24 * 3600 // 30天
    cookie.save('hide_icp', 1, {path: '/', maxAge})
    this.setState({hide: true})
  }
  render() {
    const {hide} = this.state
    return (
      <div className={cx("m-icp-footer", {hide})}>
        <span>© 2016-2017 空中绿洲 airoases.com All Rights Reserved.</span>
        <span className="icp">京ICP备16037424号</span>
        <div className="icon icon-close-white close" onClick={this.hideICP}></div>
      </div>
    )
  }
}

export default ICPFooter