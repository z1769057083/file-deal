import React, { Component, PropTypes } from 'react'
import AuthSingleCard from 'components/AuthSingleCard'
import PhoneInput from 'components/forms/PhoneInput'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import {
  REGISTER_USER_START,
  LOGIN_USER_START,
  RETRIEVE_USER_SUCCESS
} from 'config/authPage'
import {resetPwd} from 'actions/register'
import {loginUser} from 'actions/auth'
import {
  Form,
  Input,
  Button
} from 'react-validation/lib/build/validation.rc'
import {SubmitDecorator} from 'decorators'

class PasswordRetrieve extends Component {
  constructor(props, context) {
    super(props, context)
    this.state = {
      pwd: '',
      repeatPwd: '',
    }
    this.onSubmit = this.onSubmit.bind(this)
    this.handlePwd = this.handlePwd.bind(this)
    this.handleRepeatPwd = this.handleRepeatPwd.bind(this)

  }
  handlePwd(e) {
    this.setState({
      pwd: e.target.value
    })
  }
  handleRepeatPwd(e) {
    const repeatPwd = e.target.value
    this.setState({
      repeatPwd,
    })
  }
  onSubmit(event) {
    event.preventDefault()
    const {pwd, repeatPwd} = this.state
    if (pwd !== repeatPwd) {
      this.props.showError('密码与重复密码不一致')
      return
    }
    const registerInfo = this.props.register
    const {resetPwd, loginUser} = this.props.actions
    const phone = registerInfo.get('forgetPhone')

    resetPwd({
      pwd,
      phone,
      verifyCode: registerInfo.get('forgetCode'),
      afterSuccess: () => {
        this.props.switchPage(RETRIEVE_USER_SUCCESS)
        loginUser({
          phone,
          pwd
        })
      },
      afterError: (state) => {
        this.props.showError(state.message || '')
      }
    })
  }
  render() {
    const phone = this.props.register.get('forgetPhone') || '18600194729'
    return (
      <AuthSingleCard closeAuthModal={this.props.closeAuthModal}>
        <Form className="card-main password-retrieve modal-form"
          ref={c => {this.form = c}}
          onSubmit={this.onSubmit}
          >
          <div className="header">密码找回</div>
          <div className="main">
            <div className="input m-input-with-msg">
              <Input type="password"
                name="pwd"
                className="m-text"
                containerClassName="field-wrapper"
                errorClassName="error"
                onChange={this.handlePwd}
                value={this.state.pwd}
                validations={['required', 'password', 'passwordConfirm']}
                placeholder="密码（字母、数字至少8位）"
              />
            </div>
            <Input type="password"
              name="repeatPwd"
              className="m-text"
              containerClassName="input field-wrapper"
              errorClassName="error"
              onChange={this.handleRepeatPwd}
              value={this.state.repeatPwd}
              validations={['required', 'password', 'passwordConfirm']}
              placeholder="再次输入密码"
            />
            <div className="bottom flexbox">
              <span className="register" onClick={() => this.props.switchPage(REGISTER_USER_START)}>注册帐号</span>
              <div className="has-account">
                已有帐号？<span className="login clickable" onClick={() => this.props.switchPage(LOGIN_USER_START)}>登录</span>
              </div>
            </div>
          </div>
          <div className="footer flexbox single-button field-wrapper btn-footer">
            <Button type="submit" className="btn btn-primary">提交</Button>
            {this.props.error && <div className="form-error active">{this.props.error}</div>}
          </div>
        </Form>
      </AuthSingleCard>
    )
  }
}

PasswordRetrieve.propTypes = {
  switchPage: PropTypes.func
}

PasswordRetrieve.contextTypes = {
  store: PropTypes.object
}

function mapStateToProps(state) {
  return {register: state.register}
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({resetPwd, loginUser}, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(SubmitDecorator(PasswordRetrieve))
