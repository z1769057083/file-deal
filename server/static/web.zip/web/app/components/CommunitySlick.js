import React, {Component, PropTypes} from 'react'
import {Link} from 'react-router'
import * as util from 'util/index'
import {browserHistory} from 'react-router'
import {bindActionCreators} from 'redux'
import {connect} from 'react-redux'
import * as cardActions from 'actions/card'
import CardActionBar from 'components/card/CardActionBar'
import _ from 'lodash'

class CommunitySlick extends Component {
  state = {
    index: 0
  }

  renderPics(item, key) {
    const data = _.map(
      item.images,
      pic =>
        pic.url +
        '?imageMogr2/thumbnail/!200x200r/format/webp/blur/1x0/quality/75|imageslim'
    )

    let len = data.length
    switch (len) {
      case 0:
        return null
      case 1:
      case 5:
        return <img src={data[0]} alt="" />
      case 2:
        // 左边一个，右边一个
        return (
          <div className="flexbox imgGroup" style={{flexDirection: 'row'}}>
            <div
              className="imgItem"
              style={{
                backgroundImage: `url(${data[0]})`,
                width: 89,
                height: 180
              }}
            />
            <div className="space" style={{width: 2}} />
            <div
              className="imgItem"
              style={{
                backgroundImage: `url(${data[1]})`,
                width: 89,
                height: 180
              }}
            />
          </div>
        )
      case 6:
      case 9:
        // 上面一个，下面一个
        return (
          <div className="flexbox imgGroup" style={{flexDirection: 'column'}}>
            <div
              className="imgItem half"
              style={{backgroundImage: `url(${data[0]})`}}
            />
            <div className="space" style={{height: 2}} />
            <div
              className="imgItem half"
              style={{backgroundImage: `url(${data[1]})`}}
            />
          </div>
        )
      case 3:
        // 上面一个，下面两个
        return (
          <div className="flexbox imgGroup" style={{flexDirection: 'column'}}>
            <div
              className="imgItem half"
              style={{backgroundImage: `url(${data[0]})`}}
            />
            <div className="space" style={{height: 2}} />
            <div
              className="flexbox"
              style={{width: 180, height: 89, flexDirection: 'row'}}>
              <div
                className="imgItem quarter"
                style={{backgroundImage: `url(${data[1]})`}}
              />
              <div className="space" style={{width: 2}} />
              <div
                className="imgItem quarter"
                style={{backgroundImage: `url(${data[2]})`}}
              />
            </div>
          </div>
        )
      case 7:
        // 左面一个，右面两个
        return (
          <div className="flexbox imgGroup" style={{flexDirection: 'row'}}>
            <div
              className="imgItem"
              style={{
                backgroundImage: `url(${data[0]})`,
                width: 89,
                height: 180
              }}
            />
            <div className="space" style={{width: 2}} />
            <div
              className="flexbox"
              style={{width: 89, height: 180, flexDirection: 'column'}}>
              <div
                className="imgItem quarter"
                style={{backgroundImage: `url(${data[1]})`}}
              />
              <div className="space" style={{height: 2}} />
              <div
                className="imgItem quarter"
                style={{backgroundImage: `url(${data[2]})`}}
              />
            </div>
          </div>
        )
      case 9:
        // 左边两个，右边一个
        return (
          <div className="flexbox imgGroup" style={{flexDirection: 'row'}}>
            <div
              className="flexbox"
              style={{width: 89, height: 180, flexDirection: 'column'}}>
              <div
                className="imgItem quarter"
                style={{backgroundImage: `url(${data[1]})`}}
              />
              <div className="space" style={{height: 2}} />
              <div
                className="imgItem quarter"
                style={{backgroundImage: `url(${data[2]})`}}
              />
            </div>
            <div className="space" style={{width: 2}} />
            <div
              className="imgItem"
              style={{
                backgroundImage: `url(${data[0]})`,
                width: 89,
                height: 180
              }}
            />
          </div>
        )
      case 10:
        // 上面两个，下边一个
        return (
          <div className="flexbox imgGroup" style={{flexDirection: 'column'}}>
            <div
              className="flexbox"
              style={{width: 180, height: 89, flexDirection: 'row'}}>
              <div
                className="imgItem quarter"
                style={{backgroundImage: `url(${data[1]})`}}
              />
              <div className="space" style={{width: 2}} />
              <div
                className="imgItem quarter"
                style={{backgroundImage: `url(${data[2]})`}}
              />
            </div>
            <div className="space" style={{height: 2}} />
            <div
              className="imgItem half"
              style={{backgroundImage: `url(${data[0]})`}}
            />
          </div>
        )
      case 4:
      case 8:
        // 四个角各一个
        return (
          <div className="flexbox imgGroup">
            <div
              className="flexbox"
              style={{width: 89, height: 180, flexDirection: 'column'}}>
              <div
                className="imgItem quarter"
                style={{backgroundImage: `url(${data[0]})`}}
              />
              <div className="space" style={{height: 2}} />
              <div
                className="imgItem quarter"
                style={{height: 89, backgroundImage: `url(${data[1]})`}}
              />
            </div>
            <div className="space" style={{width: 2}} />
            <div
              className="flexbox"
              style={{width: 89, height: 180, flexDirection: 'column'}}>
              <div
                className="imgItem quarter"
                style={{backgroundImage: `url(${data[2]})`}}
              />
              <div className="space" style={{height: 2}} />
              <div
                className="imgItem quarter"
                style={{backgroundImage: `url(${data[3]})`}}
              />
            </div>
          </div>
        )
    }
  }

  _linkTo(path) {
    const {index} = this.state
    const contextCards = this.props.pics[index].slice()
    
    this.props.actions.updateCardMode({
      inModal: true,
      contextCards,
      returnTo: location.pathname + location.search
    })
    location.href = path
  }

  handlePrev = () => {
    const {pics} = this.props
    const {index} = this.state
    if (index <= 0) {
      this.setState({index: pics.length - 1})
    } else {
      this.setState({index: index - 1})
    }
  }

  handleNext = () => {
    const {pics} = this.props
    const {index} = this.state
    if (index >= pics.length - 1) {
      this.setState({index: 0})
    } else {
      this.setState({index: index + 1})
    }
  }

  render() {
    const {index} = this.state
    const {designerId} = this.props;
    return (
      <div className="m-community-slick">
        <div className="prev">
          <i className="icon icon-community-prev" onClick={this.handlePrev} />
        </div>
        <div className="slick">
          {this.props.pics[index] &&
            this.props.pics[index].map((item, key) => {
              return (
                <div
                  className="img"
                  key={key}
                  onClick={() => {
                    this._linkTo(`/topic/${item.id}?curr_id=${designerId}`)
                  }}>
                  {this.renderPics(item, key)}

                  <div className="mask" />
                </div>
              )
            })}
        </div>
        <div className="next">
          <i className="icon icon-community-next" onClick={this.handleNext} />
        </div>
      </div>
    )
  }
}

CommunitySlick.propTypes = {
  type: PropTypes.number.isRequired
}

function mapStateToProps(state, ownProps) {
  return {
    cards: state.cards
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(
      {
        updateCardMode: cardActions.updateCardMode
      },
      dispatch
    )
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(CommunitySlick)
