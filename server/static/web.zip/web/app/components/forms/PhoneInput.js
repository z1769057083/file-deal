import React, { Component, PropTypes } from 'react'
import classNames from 'classnames'
import _ from 'lodash'
import {Input} from 'react-validation/lib/build/validation.rc'

function formatPhone(phone) {
  if (!phone) return ''
  let formatted = ''
  const purePhone = phone.replace(/[^\d]/g, '')
  const one = purePhone.slice(0, 3)
  const two = purePhone.slice(3, 8)
  const three = purePhone.slice(8, 11)

  if (one) formatted += one
  if (two) formatted += ' ' + two
  if (three) formatted += ' ' + three

  return formatted
}
function unformatPhone(formatPhone) {
  return formatPhone.replace(/[^\d]/g, '')
}
/*
 * Best Practices
 * http://brewhouse.io/blog/2015/03/24/best-practices-for-component-state-in-reactjs.html
 */
class PhoneInput extends Component {
  constructor(props) {
    super(props)
  }

  _onChange(e) {
    this.props.onChange(unformatPhone(e.nativeEvent.target.value))
  }

  render() {
    if (this.props.readOnly) {
      return (<span className="m-format-phone">{formatPhone(this.props.value)}</span>)
    }

    if (this.props.validations) {
      return (<Input
        type="text"
        className={this.props.className}
        containerClassName={this.props.containerClassName}
        errorClassName={this.props.errorClassName}
        onChange={(e) => this._onChange(e)}
        value={formatPhone(this.props.value)}
        placeholder={this.props.placeholder}
        validations={this.props.validations}
        autoFocus={true}
        name={this.props.name}
        />)
    } else {
      return (
        <input type="text"
               className={this.props.className}
               onChange={(e) => this._onChange(e)}
               value={formatPhone(this.props.value)}
               placeholder={this.props.placeholder}/>
      )
    }
  }
}

PhoneInput.propTypes = {
  placeholder: PropTypes.string,
  className: PropTypes.string,
  value: PropTypes.string.isRequired,
  onChange: PropTypes.func,
  name: PropTypes.string,
  containerClassName: PropTypes.string,
  errorClassName: PropTypes.string,
  validations: PropTypes.array,
}

export default PhoneInput
