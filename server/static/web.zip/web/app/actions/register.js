/**
 * Register, find password and activate
 */
import {CALL_API} from 'middleware/api'

/**
 * Ordinary user actions
 */
export const SEND_CODE_FOR_REGISTER = Symbol('SEND_CODE_FOR_REGISTER')
export const SEND_CODE_FOR_PASSWORD = Symbol('SEND_CODE_FOR_PASSWORD')
export function sendCode(params) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/user/getverifycode',
      query: {phone: params.phone, channel: params.channel, token: 'web'},
      successType: params.channel === 0 ? SEND_CODE_FOR_REGISTER : SEND_CODE_FOR_PASSWORD,
      afterSuccess: params.afterSuccess
    }
  }
}

// check whether the phone is already registered
export function checkPhoneRegister(phone, afterSuccess) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/user/verifyphone',
      body: {
        phone
      },
      afterSuccess
    }
  }
}

export const UPDATE_PHONE = Symbol('UPDATE_PHONE')
export function updatePhone(phone) {
  return {
    type: UPDATE_PHONE,
    phone
  }
}

export const REGISTER = Symbol('REGISTER')
export function registerUser(params) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/user/register',
      query: {
        token: 'web',
        phone: params.phone,
        nickname: params.nickName,
        pwd: params.pwd,
        verifycode: params.verifyCode
      },
      successType: REGISTER,
      afterSuccess: params.afterSuccess,
      afterError: params.afterError
    }
  }
}

export const VERIFY_CODE_REGISTER = Symbol('VERIFY_CODE_REGISTER')
export const VERIFY_CODE_PASSWORD = Symbol('VERIFY_CODE_PASSWORD')
export function verifyCode(params) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/user/verifysmscode',
      query: {
        token: 'web',
        phone: params.phone,
        channel: params.channel,
        verifycode: params.verifyCode
      },
      successType: params.channel === 0 ? VERIFY_CODE_REGISTER : VERIFY_CODE_PASSWORD,
      afterSuccess: params.afterSuccess,
      afterError: params.afterError
    }
  }
}

export const UPDATE_CODE = Symbol('UPDATE_CODE')
export function updateCode(code) {
  return {
    type: UPDATE_CODE,
    code
  }
}

/** forget password **/
export const UPDATE_CODE_PASSWORD = Symbol('UPDATE_CODE_PASSWORD')
export function updateCodePassword(code) {
  return {
    type: UPDATE_CODE_PASSWORD,
    code
  }
}

export const UPDATE_PHONE_PASSWORD = Symbol('UPDATE_PHONE_PASSWORD')
export function updatePhonePassword(phone) {
  return {
    type: UPDATE_PHONE_PASSWORD,
    phone
  }
}

export const RESET_PWD = Symbol('RESET_PWD')
export function resetPwd(params) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/user/resetpwd',
      query: {
        token: 'web',
        phone: params.phone,
        pwd: params.pwd,
        verifycode: params.verifyCode,
      },
      successType: RESET_PWD,
      afterSuccess: params.afterSuccess,
      afterError: params.afterError
    }
  }
}

/**
 * Team only actions
 */
export const UPDATE_TEAM_EMAIL = Symbol('UPDATE_TEAM_EMAIL')
export function updateTeamEmail(email) {
  return {
    type: UPDATE_TEAM_EMAIL,
    email
  }
}

// check whether the email is already registered
export function checkEmailRegister(email, afterSuccess) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/user/verifyemail',
      body: {
        email
      },
      afterSuccess
    }
  }
}

export const TEAM_REGISTER = Symbol('TEAM_REGISTER')
export function registerTeam(params) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/user/orgregister',
      body: {
        token: 'web',
        email: params.email,
        pwd: params.pwd,
        nickname: params.nickname
      },
      afterSuccess: params.afterSuccess,
      successType: TEAM_REGISTER,
      afterError: params.afterError
    }
  }
}

export const UPDATE_TEAM_EMAIL_PWD = Symbol('UPDATE_TEAM_EMAIL_PWD')
export function updateTeamEmailPWD(email, pwd) {
  return {
    type: UPDATE_TEAM_EMAIL_PWD,
    email,
    pwd
  }
}

export const ACTIVATE_TEAM_SUCCESS = Symbol('ACTIVATE_TEAM_SUCCESS')
export function activateTeam(confirmationtoken, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'get',
      path: '/api/v1/open/user/activate',
      query: {
        confirmationtoken
      },
      successType: ACTIVATE_TEAM_SUCCESS,
      afterSuccess,
      afterError
    }
  }
}

export const UPDATE_TEAM_FORGET_EMAIL = Symbol('UPDATE_TEAM_FORGET_EMAIL')
export function updateTeamForgetEmail(email) {
  return {
    type: UPDATE_TEAM_FORGET_EMAIL,
    email
  }
}

export const SEND_TOKEN_EMAIL_SUCCESS = Symbol('SEND_TOKEN_EMAIL_SUCCESS')
/**
 * 团体用户注册或者找回密码时发邮件使用
 * @param params.email 邮箱
 * @param params.channel 类型，0：用户注册；1：找回密码
 */
export function sendTokenEmail(params, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/user/sendtokenemail',
      query: params,
      successType: SEND_TOKEN_EMAIL_SUCCESS,
      afterSuccess,
      afterError
    }
  }
}

export const RESET_PWD_BY_EMAIL = Symbol('RESET_PWD_BY_EMAIL')
/**
 * 团体用户找回密码最后一步：输入新密码点提交
 * @param payload.confirmationToken
 * @param payload.pwd
 */
export function resetPwdByEmail(payload, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/user/resetpwdbyemail',
      body: payload,
      successType: RESET_PWD_BY_EMAIL,
      afterSuccess,
      afterError
    }
  }
}

export const SUBMIT_ORG_VERIFY_INFO = Symbol('SUBMIT_ORG_VERIFY_INFO')
/**
 * 提交团体用户认证资料
 * @returns {{}}
 */
export function submitOrgVerifyInfo(payload, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/user/reqorgcheck',
      query: payload,
      successType: SUBMIT_ORG_VERIFY_INFO,
      afterSuccess,
      afterError
    }
  }
}
