/**
 * 主题
 */
import * as ActionType from 'actions/subject'
import {fromJS} from 'immutable'

const defaultSubject = {
  "name": "",
  "description": "",
  "classId": -1,
  "childrenClassId": -1,
  "label": "",
  "wishes": "",
  "location": ""
}
let defaultState = fromJS({
  modalIsOpen: false,
  error: '',
  isSaving: false,
  firstClass: [],
  secondClass: [],
  classInit: false,
  subject: defaultSubject,
})

function subjectReducer(state = defaultState, action) {
  switch (action.type) {
    case ActionType.PUBLISH_SUBJECT_SUCCESS:
      return state.set('isSaving', false)
        .set('subject', fromJS(defaultSubject))
        .set('modalIsOpen', false)
    case ActionType.UPDATE_SUBJECT_FIELD:
      return state.setIn(['subject', action.key], action.value)
    
    case ActionType.OPEN_SUBJECT_WINDOW:
      return state.set('modalIsOpen', true)
    
    case ActionType.CLOSE_SUBJECT_WINDOW:
      return state.set('modalIsOpen', false)
    
    case ActionType.EDIT_SUBJECT:
      return state.set('subject', fromJS(action.subject))
    
    case ActionType.RESET_SUBJECT:
      return state.set('subject', fromJS(defaultSubject))
    
    case ActionType.GET_FIRST_CLASS: {
      const classId = state.getIn(['subject', 'classId'])
      const {data} = action.response
      let next = state.set('firstClass', fromJS(data))
      if (classId < 1 && data.length > 0) {
        next = next.setIn(['subject', 'classId'], data[0].id)
      }
      return next
    }
    
    case ActionType.GET_SECOND_CLASS: {
      const {data} = action.response
      const classId = state.getIn(['subject', 'childrenClassId'])
      let next = state.set('secondClass', fromJS(action.response.data))
      if (classId < 1 && data.length > 0) {
        next = next.setIn(['subject', 'childrenClassId'], data[0].id)
      }
      return next
    }
    
    default:
      return state
  }
}

export default subjectReducer
