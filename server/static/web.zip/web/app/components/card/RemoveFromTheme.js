import React, {PropTypes} from 'react'
import ArticleEditModal from 'components/corner-bar/ArticleEditModal'

class RemoveFromTheme extends React.Component {
  state = {
    isOpen: false,
    data: this.props.data
  }

  handleClick = evt => {
    evt.stopPropagation()
    evt.preventDefault()
    this.setState({isOpen: true})
  }

  handleClose = () => this.setState({isOpen: false})

  render() {
    const {isOpen, data} = this.state
    return (
      <div className="icon icon-edit" onClick={this.handleClick}>
        {isOpen &&
          <ArticleEditModal
            handleClose={this.handleClose}
            isOpen={isOpen}
            data={data}
          />}
      </div>
    )
  }
}

RemoveFromTheme.propTypes = {
  data: PropTypes.shape({
    articleId: PropTypes.number.isRequired,
    themeId: PropTypes.number.isRequired,
    pic: PropTypes.string.isRequired,
  }).isRequired,
}

export default RemoveFromTheme
