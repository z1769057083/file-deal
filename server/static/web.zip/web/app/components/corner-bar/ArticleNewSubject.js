/**
 * 创建手贴后无满意的主题，需新建主题
 */
import React, {PropTypes} from 'react'
import BlockImages from './BlockImages'
import {connect} from 'react-redux'
import {bindActionCreators} from 'redux'
import {Form} from 'react-validation/lib/build/validation.rc'
import SubjectCreation from './SubjectCreation'
import * as globalActions from 'actions/global'

class ArticleNewSubject extends React.Component {
  message(message) {
    const {globalActions} = this.props
    globalActions.addToast({
      type: 'singleMsg',
      message,
      timeout: 1500
    })
  }

  handlePrev = () => {
    this.props.handleNext('subject')
  }
  
  render() {
    const {article} = this.props
    const articles = article.get('articles').toJS()
    return (
      <div className="m-form-base no-margin-bottom">
        <div className="m-article-creation">
          <div className="article__main">
            <div className="article__col article__col--left">
              <BlockImages preview={true} data={articles} />
            </div>
            <div className="article__col">
              <div className="m-subject-in-article">
                <SubjectCreation afterCreated={this.handlePrev} />
              </div>
            </div>
          </div>
          <div className="article__footer">
            <button
              type="button"
              className="btn btn-primary"
              onClick={this.handlePrev}>
              取消创建
            </button>
          </div>
        </div>
      </div>
    )
  }
}

ArticleNewSubject.propTypes = {
  handleNext: PropTypes.func.isRequired,
}

const mapStateToProps = state => ({
  article: state.article
})

const mapDispatchToProps = dispatch => ({
  globalActions: bindActionCreators(globalActions, dispatch)
})

export default connect(mapStateToProps, mapDispatchToProps)(ArticleNewSubject)
