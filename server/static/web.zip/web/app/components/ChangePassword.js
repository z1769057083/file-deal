import React, { Component, PropTypes } from 'react'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import {Link} from 'react-router'
import * as authActions from 'actions/auth'
import * as globalActions from 'actions/global'
import classNames from 'classnames'
import {
  Form,
  Input,
  Button
} from 'react-validation/lib/build/validation.rc'
import {SubmitDecorator} from 'decorators'

class ChangePassword extends Component {
  constructor(props) {
    super(props)
    this.state = {
      oldPwd: '',
      pwd: '',
      repeatPwd: '',
      loading: false,
    }
    this.handleOldPwd = this.handleOldPwd.bind(this)
    this.handleNewPwd = this.handleNewPwd.bind(this)
    this.handleReenterNewPwd = this.handleReenterNewPwd.bind(this)
    this.onSubmit = this.onSubmit.bind(this)
  }
  handleOldPwd(e) {
    this.setState({
      oldPwd: e.target.value
    })
  }
  handleNewPwd(e) {
    this.setState({
      pwd: e.target.value
    })
  }
  handleReenterNewPwd(e) {
    this.setState({
      repeatPwd: e.target.value
    })
  }
  onSubmit(event) {
    event.preventDefault()

    const {oldPwd, pwd} = this.state
    this.props.actions.updateUserPassword(oldPwd, pwd, ()=> {
      this.props.actions.addToast({
        type: 'black',
        message: '密码修改成功',
        pic: this.props.avatar,
        timeout: 2000
      })
      this.props.closeModal()
    }, (state) => {
      this.props.showError(state.message || '修改失败')
    })
  }
  render() {
    return (
      <Form className="auth-card auth-single-card password-change modal-form"
            ref={c => {this.form = c}}
            onSubmit={this.onSubmit}
        >
        <div className="card">
          <div className="card-main">
            <div className="header">
              <span>修改密码</span>
              <span className="icon icon-close-white" onClick={() => this.props.closeModal()}></span>
            </div>
            <div className="main">
              <div className="input-group">
                <div className="input flexbox">
                  <div className="label">旧密码</div>
                  <Input type="password"
                         name="oldPwd"
                         className="m-text"
                         containerClassName="field-wrapper"
                         errorClassName="error"
                         onChange={this.handleOldPwd}
                         value={this.state.oldPwd}
                         validations={['required']}
                         placeholder="旧密码"
                    />
                </div>
                <div className="input flexbox">
                  <div className="label">新密码</div>
                  <Input type="password"
                         name="pwd"
                         className="m-text"
                         containerClassName="field-wrapper"
                         errorClassName="error"
                         onChange={this.handleNewPwd}
                         value={this.state.pwd}
                         validations={['required', 'password', 'passwordConfirm']}
                         placeholder="新密码"
                    />
                </div>
                <div className="input flexbox">
                  <div className="label">再输入</div>
                  <Input type="password"
                         name="repeatPwd"
                         className="m-text"
                         containerClassName="field-wrapper"
                         errorClassName="error"
                         onChange={this.handleReenterNewPwd}
                         value={this.state.repeatPwd}
                         validations={['required', 'password', 'passwordConfirm']}
                         placeholder="确认密码"
                    />
                </div>
              </div>
            </div>
            <div className="footer flexbox single-button field-wrapper btn-footer">
              <Button
                type="submit"
                className="btn btn-primary">
                提交
              </Button>
              {this.props.error && <div className="form-error active">{this.props.error}</div>}
            </div>
          </div>
        </div>
      </Form>
    )
  }
}
function mapStateToProps (state) {
  return {
    auth: state.auth,
    avatar: state.auth.get('pic')
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      updateUserPassword: authActions.updateUserPassword,
      addToast: globalActions.addToast,
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(
  SubmitDecorator(ChangePassword)
)
