import React, { Component, PropTypes } from 'react'
import CommunityUserRow from 'components/CommunityUserRow'

class CommunityUserList extends Component {
  render() {
    return (
      <div className="community-user-list shim">
        {this.props.items.map((item, key) => {
          return (
            <CommunityUserRow
              type={this.props.type}
              data={item}
              key={key} index={key}>
            </CommunityUserRow>)
        })}
      </div>
    )
  }
}

CommunityUserList.propTypes = {
  items: PropTypes.array.isRequired,
  type: PropTypes.number.isRequired
}

export default CommunityUserList
