import React, {Component, PropTypes} from 'react'
import {connect} from 'react-redux'
import {Link} from 'react-router'
import NavLink from 'components/global/NavLink'
import {chunckNickname} from 'util/index'

const propTypes = {
  userInfo: PropTypes.object.isRequired,
  userId: PropTypes.number.isRequired
}
//判断是否是作品页
const isWorks = () => {
  const path = location.pathname
  if (/^\/user\/\d+$/i.test(path)) {
    return true
  } else if (/^\/[a-z0-9_-]+$/i.test(path)) {
    return true
  } else {
    return false
  }
}
class UserHeader extends Component {
  render() {
    const {auth, user} = this.props
    const formatName = chunckNickname(user.getIn(['userInfo', 'name']) || '')
    const avatar = user.getIn(['userInfo', 'pic']) || ''
    const userType = user.getIn(['userInfo', 'userType'])
    const userId = user.getIn(['userInfo', 'ownerId']) || 0
    const isIndie = userType === '2'
    const styles = avatar
      ? {background: `url(${avatar}) center center/cover no-repeat`}
      : {}
    return (
      <div className="m-user-header m-user-header-new">
        <div className="user-info flexbox">
          <div className="flex">
            <div className="desc">
              {auth.get('sign')}
            </div>
          </div>
          <div className="info info__wrap">
            {formatName.reverse().map((arr, key) =>
              <div className="p2" key={key}>
                {arr.join('')}
              </div>
            )}
          </div>
          <div className="avatar-wrap">
            <div className="avatar" style={styles} />
            {isIndie && <div className="avatar__indie">indie</div>}
          </div>
        </div>

        <div className="bottom__wrap">
          <div className="bottom__title">我的绿洲</div>
          <div className="tabs">
            <NavLink
              className="item"
              to={`/user/${userId}`}
              activeClassName="active"
              isActive={isWorks}>
              <p className="name">主题</p>
            </NavLink>
            <Link
              className="item"
              to={`/user/${userId}/oasis`}
              activeClassName="active">
              <p className="name">手帖</p>
            </Link>
          </div>
        </div>
      </div>
    )
  }
}

UserHeader.propTypes = propTypes

function mapStateToProps(state) {
  return {
    auth: state.auth,
    userId: state.user.getIn(['userInfo', 'ownerId']),
    user: state.user
  }
}

export default connect(mapStateToProps)(UserHeader)
