/**
 * Publish a new card
 */
import { CALL_API, CHAIN_API } from 'middleware/api'

export const PUBLISH_ARTICLE_SUCCESS = Symbol('PUBLISH_ARTICLE_SUCCESS')
export const PUBLISH_ARTICLE_FAILURE = Symbol('PUBLISH_ARTICLE_FAILURE')
export function publishArticle(params) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/article/submitproarticle',
      body: params.payload,
      successType: PUBLISH_ARTICLE_SUCCESS,
      afterError: params.afterError,
      afterSuccess: params.afterSuccess
    }
  }
}

export const UPDATE_ARTICLE_FIELD = Symbol('UPDATE_ARTICLE_FIELD')
export function updateArticleField(index, key, value) {
  return {
    type: UPDATE_ARTICLE_FIELD,
    index,
    key,
    value
  }
}

export const UPDATE_FIELD = Symbol('UPDATE_FIELD')
export function updateField(key, value) {
  return {
    type: UPDATE_FIELD,
    key,
    value
  }
}

export const UPDATE_ARTICLE_THEME = Symbol('UPDATE_ARTICLE_THEME')
export function updateTheme(theme, themeId) {
  return {
    type: UPDATE_ARTICLE_THEME,
    theme,
    themeId,
  }
}

export const LOAD_DICT_SUCCESS = Symbol('LOAD_DICT_SUCCESS')
function loadDictByType(type) {
  return {
    [CALL_API]: {
      method: 'get',
      path: '/api/v1/open/loaddict',
      query: {
        type
      },
      successType: LOAD_DICT_SUCCESS,
    }
  }
}
export function loadDict() {
  return {
    [CHAIN_API]: [
      () => loadDictByType('articleType'),
      () => loadDictByType('projectInfo'),
      () => loadDictByType('picTypeFroArt'),
    ]
  }
}

export const UPLOAD_IMG_SUCCESS = Symbol('UPLOAD_IMG_SUCCESS')
/**
 * upload an image
 * @param formData, must include picFile as the param name
 */
export function uploadImg(formData, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/uploadimage',
      body: formData,
      successType: UPLOAD_IMG_SUCCESS,
      afterSuccess,
      afterError,
    }
  }
}

export const UPLOAD_BASE64_SUCCESS = Symbol('UPLOAD_BASE64_SUCCESS')
/**
 * upload an image
 * @param formData, must include picFile as the param name
 */
export function uploadImgBase64(data, afterSuccess) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/uploadimagebase64',
      body: {
        picFile: data
      },
      successType: UPLOAD_BASE64_SUCCESS,
      afterSuccess
    }
  }
}

/**
 * open article window to add a new article or edit an article
 */
export const OPEN_ARTICLE_WINDOW = Symbol('OPEN_ARTICLE_WINDOW')
export function openArticleWindow() {
  return {
    type: OPEN_ARTICLE_WINDOW
  }
}
export const CLOSE_ARTICLE_WINDOW = Symbol('CLOSE_ARTICLE_WINDOW')
export function closeArticleWindow() {
  return {
    type: CLOSE_ARTICLE_WINDOW
  }
}
export const EDIT_ARTICLE = Symbol('EDIT_ARTICLE')
export function editArticle(article) {
  return {
    type: EDIT_ARTICLE,
    article
  }
}
export const RESET_ARTICLE = Symbol('RESET_ARTICLE')
export function resetArticle() {
  return {
    type: RESET_ARTICLE
  }
}

export const TREAD = Symbol(TREAD)
export function tread(payload, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      successType: TREAD,
      method: 'post',
      path: '/api/v1/open/articles/tread',
      query: payload,
      afterSuccess,
      afterError
    }
  }
}

export const REMOVE_TREAD = Symbol(REMOVE_TREAD)
export function removeTread(payload, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      successType: REMOVE_TREAD,
      method: 'post',
      path: '/api/v1/open/articles/tread/remove',
      query: payload,
      afterSuccess,
      afterError
    }
  }
}

export const GET_ARTICLE_BY_THEME = Symbol('GET_ARTICLE_BY_THEME')
export function getArticlesByTheme(params, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/theme/articles',
      query: params,
      successType: GET_ARTICLE_BY_THEME,
      afterError: afterError,
      afterSuccess: afterSuccess
    }
  }
}

export const BATCH_ADD_ARTICLE = Symbol('BATCH_ADD_ARTICLE')
export function batchAddArticle(payload, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/articles/batchAdd',
      body: payload,
      successType: BATCH_ADD_ARTICLE,
      afterError: afterError,
      afterSuccess: afterSuccess
    }
  }
}

export const SAVE_ARTICLE = Symbol('SAVE_ARTICLE')
export function saveArticle(payload, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/theme/article/update',
      query: payload,
      successType: SAVE_ARTICLE,
      afterError: afterError,
      afterSuccess: afterSuccess
    }
  }
}

export const REMOVE_ARTICLE = Symbol('REMOVE_ARTICLE')
export function removeArticle(payload, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/theme/checkOut',
      query: payload,
      successType: REMOVE_ARTICLE,
      afterError: afterError,
      afterSuccess: afterSuccess
    }
  }
}

export const ADD_TO_THEME = Symbol('ADD_TO_THEME')
export function addToTheme(payload, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/theme/checkIn',
      query: payload,
      successType: ADD_TO_THEME,
      afterError: afterError,
      afterSuccess: afterSuccess
    }
  }
}

export const REMOVE_IMAGE = Symbol('REMOVE_IMAGE')
export function removeImage(index) {
  return {
    type: REMOVE_IMAGE,
    index
  }
}