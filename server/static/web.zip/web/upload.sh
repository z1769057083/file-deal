#!/bin/bash
rsync -rzt -e "ssh -o GSSAPIAuthentication=no" --exclude "upload.sh" ./ idealist@119.23.201.234:/home/idealist/code/web-github