import React, {Component, PropTypes} from 'react'
import {bindActionCreators} from 'redux'
import {connect} from 'react-redux'
import PhotoWall from 'components/PhotoWall'
import * as userActions from 'actions/user'

class TopicPhotoList extends Component {
  state = {
    data: []
  }

  componentDidMount() {
    if (this.props.userId) {
      this._loadData()
    }
  }
  
  componentDidUpdate(prev) {
    if (prev.userId !== this.props.userId) {
      this._loadData()
    }
  }

  _loadData() {
    const succeed = ({response}) => {
      const {data} = response
      this.setState({data})
    }
    const {userId, actions} = this.props
    const payload = {userId, imageCount: 6}
    actions.getUserThemes(payload, succeed)
  }
  render() {
    const {data} = this.state
    const {userId, authUserId} = this.props
    const isSelf = userId === authUserId
    return (
      <div className="m-topic-wall">
        {isSelf && <PhotoWall isCreate />}
        {data.map((item, key) => <PhotoWall key={key} data={item} />)}
      </div>
    )
  }
}

function mapStateToProps(state) {
  return {
    authUserId: state.auth.get('id') || 0,
    userId: state.user.getIn(['userInfo', 'ownerId'])
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(
      {
        getUserThemes: userActions.getUserThemes
      },
      dispatch
    )
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(TopicPhotoList)
