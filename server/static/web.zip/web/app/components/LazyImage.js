import React, { Component, PropTypes } from 'react'

let timeout = null
class LazyImage extends Component {
  constructor(props) {
    super(props)
    this.state = {
      loaded: false
    }
  }
  componentDidMount() {
    timeout = setTimeout(() => {
      const img = new Image()
      img.onload = () => {
        this.setState({
          loaded: true
        })
      }
      img.src = this.props.src
    }, 500)
  }
  componentWillUnmount() {
    clearTimeout(timeout)
  }
  render() {
    return this.state.loaded ? <img src={this.props.src} style={this.props.style} alt="" />: null
  }
}

LazyImage.propTypes = {
  src: PropTypes.string.isRequired,
  style: PropTypes.object
}

export default LazyImage