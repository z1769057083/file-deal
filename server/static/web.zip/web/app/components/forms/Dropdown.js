/**
 * Header dropdown
 */
import React, {Component, PropTypes} from 'react'
import cx from 'classnames'

const propTypes = {
  iconClassName: PropTypes.string,
  itemContainerClassName: PropTypes.string
}
class Dropdown extends Component {
  constructor(props) {
    super(props)
    this.state = {isShow: false}
    this.onDocumentClick = this.onDocumentClick.bind(this)
    this.onIconClick = this.onIconClick.bind(this)
  }

  componentWillUpdate(nextProps, nextState) {
    nextState.isShow ? document.addEventListener('click', this.onDocumentClick) :
      document.removeEventListener('click', this.onDocumentClick)
  }

  onDocumentClick(evt) {
    const dropdown = this.refs.dropdown;
    if ( dropdown && !dropdown.contains(evt.target) && this.state.isShow ) {
      this.setState({isShow: false});
    }
  }

  onIconClick() {
    this.setState({isShow: !this.state.isShow})
  }

  render() {
    const {iconClassName, itemContainerClassName} = this.props
    return (
      <div className="m-dropdown" ref="dropdown">
        <div className={cx("icon", iconClassName)} onClick={this.onIconClick}></div>
        <div className={cx("dropdown", itemContainerClassName, {hide: !this.state.isShow})}>
          {this.props.children}
        </div>
      </div>
    )
  }
}

Dropdown.propTypes = propTypes

export default Dropdown