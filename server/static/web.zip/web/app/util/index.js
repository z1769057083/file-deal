import _ from 'lodash'

export function isEmail(str) {
  return /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(str)
}

export function nullToEmpty(obj) {
  for(const key in obj) {
    if (_.isNull(obj[key])) {
      obj[key] = ""
    }
  }
  return obj
}

export function truncate(str, len) {
  if (!str) {
    return ''
  }
  const r = /[^\x00-\xff]/g
  if (str.replace(r, "mm").length <= len) {
    return str
  }
  const m = Math.floor(len / 2);
  for (let i = m; i < str.length; i++) {
    if (str.substr(0, i).replace(r, "mm").length >= len) {
      return str.substr(0, i) + "..."
    }
  }
  return str
}

/**
 * @param html can only include <br />
 * @param len
 */
export function truncateHtml(html, len) {
  let arr = html.split('<br/>')
  let current = 0
  let end = false

  const r = /[^\x00-\xff]/g
  for (let i = 0, t = arr.length; i < t; i++) {
    const itemLen = arr[i].replace(r, "mm").length
    const next = current + itemLen
    if (next > len) {
      arr = arr.slice(0, i+1)
      arr[i] = truncate(arr[i], len - current)
      end = true
      break
    }
    current = next
  }
  return {
    isOverflow: end,
    content: arr.join('<br/>')
  }
}

/**
 * number functions
 */
export function isOdd(num) {
  return num % 2 === 1
}

/**
 *
 * @param text
 * @param width: width of the container
 * @param lineHeight
 * @param fontSize
 */
export function heightOfText(text, width, lineHeight = '21px', fontSize='16px') {
  let div = document.createElement('div')
  div.innerHTML = text
  const body = document.body
  body.appendChild(div)
  div.style.width = `${width}px`
  div.style.lineHeight = `${lineHeight}px`
  div.style.fontSize = `${fontSize}`
  div.style.visibility = 'none'
  div.style.position = 'absolute'
  div.style.wordBreak = 'break-all'
  div.style.wordWrap = 'break-word'
  const height = div.clientHeight
  body.removeChild(div)
  div = null

  // 20 is padding-top
  return height + 20
}

/**
 * 瀑布流适配大屏幕
 */
const BIG_SCREEN = 1440
export function columnStrategy(oldColumn) {
  let column = oldColumn
  if (typeof window == 'undefined') {
    return column
  }
  const width = window.outerWidth
  /**
   * 适配策略: 首页由4栏变6栏，其他地方由3栏变4栏
   */
  if (width > BIG_SCREEN) {
    if (column == 4) {
      column = 6
    } else if (column == 3) {
      column = 4
    }
  }
  return column
}

export function canUseDom() {
  return typeof document !== 'undefined'
}

export function randomToastBg() {
  const colors = [
    'rgba(120, 151, 61, 0.9)',
    'rgba(156, 219, 239, 0.9)',
    'rgba(237, 146, 36, 0.9)',
    'rgba(217, 0, 137, 0.9)',
    'rgba(14, 185, 157, 0.9)',

    'rgba(227, 78, 44, 0.9)',
    'rgba(195, 148, 187, 0.9)',
    'rgba(177, 179, 25, 0.9)',
    'rgba(108, 143, 167, 0.9)',
    'rgba(98, 64, 109, 0.9)',

    'rgba(63, 57, 123, 0.9)',
    'rgba(92, 106, 172, 0.9)',
    'rgba(126, 28, 29, 0.9)',
    'rgba(167, 202, 227, 0.9)',
    'rgba(171, 144, 57, 0.9)',

    'rgba(156, 196, 164, 0.9)',
    'rgba(150, 195, 62, 0.9)'
  ];

  const len = colors.length;
  return colors[Math.floor(Math.random() * len)];
}

//判断是否是手帖页
export const isShoutie = path => {
  if (/^\/user\/\d+\/oasis$/i.test(path)) {
    return true
  }
  return false
}

export const chunckNickname = nickName => {
  const arr = nickName.split('')
  const size = 5;
  return _.chunk(arr, size)
}


