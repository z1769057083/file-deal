/**
 * user/:id reducers
 */
import * as ActionType from 'actions/user'
import {fromJS} from 'immutable'
import _ from 'lodash'

const initState = {
  init: false,
  userInfo: {},
  articleList: {},

  followers: {},
  followersType: 0,
  followersInit: false,
  followersIsEnd: false,

  following: {},
  followingType: 0,
  followingInit: false,
  followingIsEnd: false,

  oasis: {},
  oasisInit: false,
  oasisIsEnd: false,

  homepageInfo: {},
  homepageInit: false
}
let defaultState = fromJS(initState)
function userReducer(state = defaultState, action = {}) {
  switch (action.type) {
    case ActionType.LOAD_USER_INFO_SUCCESS:
    {
      const data = action.response.data
      const articleList = _.map(data.articleList.artList, (item) => {
        return {
          pic: item.pic,
          authorPic: data.pic,
          authorName: data.name,
          authorSign: data.sign,
          id: item.id,
          title: item.title,
          picHeight: item.picHeight,
          picWidth: item.picWidth,
          readCnt: item.readCnt,
          favoriteCnt: item.favoriteCnt,
          wechatUrl: item.wechatUrl || '',
        }
      })
      delete data.articleList
      return state.set('userInfo', fromJS(data))
        .set('articleList', fromJS(articleList))
        .set('init', true)
    }

    case ActionType.CLEAR_USER_INFO:
      return fromJS(initState)

    case ActionType.FOLLOW_SUCCESS:
      return state.setIn(['userInfo', 'isAttention'], `${action.body.optValue}`)

    case ActionType.GET_FOLLOWING_SUCCESS:
    {
      const data = action.response.data
      return state.set('following', fromJS(action.response.data))
        .set('followingInit', true)
    }

    case ActionType.GET_FOLLOWERS_SUCCESS:
    {
      return state.set('followers', fromJS(action.response.data))
        .set('followersInit', true)
    }
    case ActionType.RESET_FOLLOWERS:
      return state.set('followers', fromJS({}))
        .set('followersInit', false)

    case ActionType.GET_COLLECTED_ARTS_SUCCESS:
    {
      return state.set('oasis', fromJS(action.response.data))
        .set('oasisInit', true)
    }

    case ActionType.LOAD_ORG_HOMEPAGE_INFO:
    {
      const data = action.response.data
      const newState = state.set('homepageInit', true)
      return data? newState.set('homepageInfo', fromJS(data)): newState
    }

    case ActionType.MODIFY_ORG_HOMEPAGE_SUCCESS:
    {
      return state.set('homepageInfo', fromJS(action.body))
    }

    case ActionType.MODIFY_ORG_HOMEPAGE_PLAIN:
    {
      return state.set('homepageInfo', fromJS(action.formInfo))
    }

    case ActionType.RESET_COLLECTED_CARDS:
    {
      return state.set('oasisInit', false)
        .set('oasis', fromJS({}))
    }

    default :
      return state
  }
}

export default userReducer
