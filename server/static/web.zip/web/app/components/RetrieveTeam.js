import React, { Component, PropTypes } from 'react'
import AuthSingleCard from 'components/AuthSingleCard'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import {
  LOGIN_TEAM_START,
  REGISTER_TEAM_START,
  RETRIEVE_TEAM_SUCCESS
} from 'config/authPage'
import * as registerActions from 'actions/register'
import {
  Form,
  Input,
  Button
} from 'react-validation/lib/build/validation.rc'
import {SubmitDecorator} from 'decorators'

class RetrieveTeam extends Component {
  constructor(props, context) {
    super(props, context)
    this.state = {
      pwd: '',
      repeatPwd: '',
    }
    this.onSubmit = this.onSubmit.bind(this)
    this.handlePwd = this.handlePwd.bind(this)
    this.handleRepeatPwd = this.handleRepeatPwd.bind(this)
    this.handleRegister = this.handleRegister.bind(this)
    this.handlePrev = this.handlePrev.bind(this)
  }
  handlePwd(e) {
    this.setState({
      pwd: e.target.value
    })
  }
  handleRepeatPwd(e) {
    const repeatPwd = e.target.value
    this.setState({
      repeatPwd,
    })
  }
  handleRegister() {
    this.props.switchPage(REGISTER_TEAM_START)
  }
  handlePrev() {
    this.props.switchPage(LOGIN_TEAM_START)
  }
  onSubmit(event) {
    event.preventDefault()
    const {pwd, repeatPwd} = this.state
    if (pwd !== repeatPwd) {
      this.props.showError('密码与重复密码不一致')
      return
    }

    const {code} = this.props.global.get('authWindowPrams').toJS()

    if (!code) {
      this.props.showError('验证码已失效')
      return
    }

    this.props.actions.resetPwdByEmail({
      confirmationToken: code,
      pwd
    }, (state) => {
      this.props.actions.updateTeamForgetEmail(state.response.data.email)
      this.props.switchPage(RETRIEVE_TEAM_SUCCESS)
    }, (err) => {
      this.props.showError(err.message)
    })
  }
  render() {
    return (
      <AuthSingleCard closeAuthModal={this.props.closeAuthModal}>
        <Form className="card-main password-retrieve modal-form"
          ref={c => {this.form = c}}
          onSubmit={this.onSubmit}
          >
          <div className="header">密码找回</div>
          <div className="main">
            <div className="input m-input-with-msg">
              <Input type="password"
                name="pwd"
                className="m-text"
                containerClassName="field-wrapper"
                errorClassName="error"
                onChange={this.handlePwd}
                value={this.state.pwd}
                validations={['required', 'password', 'passwordConfirm']}
                placeholder="密码（字母、数字至少8位）"
              />
            </div>
            <Input type="password"
              name="repeatPwd"
              className="m-text"
              containerClassName="input field-wrapper"
              errorClassName="error"
              onChange={this.handleRepeatPwd}
              value={this.state.repeatPwd}
              validations={['required', 'password', 'passwordConfirm']}
              placeholder="再次输入密码"
            />
            <div className="bottom flexbox">
              <span className="register" onClick={this.handleRegister}>注册帐号</span>
              <div className="has-account">
                已有帳號？<span className="login clickable" onClick={this.handlePrev}>登录</span>
              </div>
            </div>
          </div>
          <div className="footer flexbox single-button field-wrapper btn-footer">
            <Button type="submit" className="btn btn-primary">提交</Button>
            {this.props.error && <div className="form-error active" style={{right: '-234px'}}>{this.props.error}</div>}
          </div>
        </Form>
      </AuthSingleCard>
    )
  }
}

RetrieveTeam.propTypes = {
  switchPage: PropTypes.func
}

function mapStateToProps(state) {
  return {
    register: state.register,
    global: state.global,
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      resetPwdByEmail: registerActions.resetPwdByEmail,
      updateTeamForgetEmail: registerActions.updateTeamForgetEmail,
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(SubmitDecorator(RetrieveTeam))
