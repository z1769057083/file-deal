import React, { Component, PropTypes } from 'react'
import AuthDoubleCard from 'components/AuthDoubleCard'
import Spinner from 'components/global/Spinner'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import {
  REGISTER_TEAM_START,
  LOGIN_USER_START,
  RETRIEVE_TEAM_START,
} from 'config/authPage'
import * as authActions from 'actions/auth'
import * as globalActions from 'actions/global'
import {
  Form,
  Input,
  Button
} from 'react-validation/lib/build/validation.rc'
import {SubmitDecorator} from 'decorators'
import Storage from 'util/storage'

class LoginTeamStart extends Component {
  constructor(props, context) {
    super(props, context)
    this.state = {
      pwd: '',
      email: '',
      loading: false,
    }
    this.pwdChanged = this.pwdChanged.bind(this)
    this.onSubmit = this.onSubmit.bind(this)
    this.afterSuccess = this.afterSuccess.bind(this)
    this.afterError = this.afterError.bind(this)
    this.emailChanged = this.emailChanged.bind(this)
    this.afterLogin = this.afterLogin.bind(this)
  }
  emailChanged(e) {
    this.setState({
      email: e.target.value
    })
  }
  pwdChanged(e) {
    this.setState({
      pwd: e.target.value
    })
  }
  afterSuccess() {
    window.setTimeout(() => {
      this.setState({loading: false})
      this.props.actions.addToast({
        type: 'black',
        message: '已成功登录',
        pic: this.props.avatar,
        timeout: 3000,
      })
      this.props.closeAuthModal()
    }, 1000)
  }
  afterError() {
    this.setState({
      loading: false
    })
    this.props.showError('用户名或密码错误')
  }
  afterLogin(state) {
    Storage.set('token', state.response.data.token)
  }
  onSubmit(event) {
    event.preventDefault()

    const {email, pwd} = this.state
    this.setState({loading: true})
    this.props.actions.loginTeam({
      email,
      pwd,
      afterLogin: this.afterLogin,
      afterSuccess: this.afterSuccess,
      afterError: this.afterError
    })
  }
  render() {
    return (
      <AuthDoubleCard closeAuthModal={this.props.closeAuthModal}>
        <div className="nav">
          <div className="item" onClick={() => {this.props.switchPage(LOGIN_USER_START)}}>个人</div>
          <div className="item active">indie</div>
        </div>
        <Form className="user modal-form"
              ref={c => {this.form = c}}
              onSubmit={this.onSubmit}
          >
          <div className="input">
            <Input type="text"
                   name="email"
                   className="m-text"
                   containerClassName="field-wrapper"
                   errorClassName="error"
                   onChange={this.emailChanged}
                   value={this.state.email}
                   autoFocus={true}
                   validations={['required', 'email']}
                   placeholder="邮箱"
              />
          </div>
          <div className="input">
            <Input type="password"
                   name="password"
                   className="m-text"
                   containerClassName="field-wrapper"
                   errorClassName="error"
                   onChange={this.pwdChanged}
                   value={this.state.pwd}
                   validations={['required', 'password']}
                   placeholder="密码"
              />
          </div>
          <div className="forget-register flexbox">
            <div className="forget clickable" onClick={() => {this.props.switchPage(RETRIEVE_TEAM_START)}}>忘记密码</div>
            <div className="register clickable" onClick={() => {this.props.switchPage(REGISTER_TEAM_START)}}>用户注册</div>
          </div>
          <div className="field-wrapper btn-footer">
            <Button
              type="submit"
              className="btn btn-primary btn-block">
              {this.state.loading ? <Spinner /> : '登录'}
            </Button>
            {this.props.error && <div className="form-error active">{this.props.error}</div>}
          </div>
          <div className="p1">
          </div>
        </Form>
      </AuthDoubleCard>
    )
  }
}

LoginTeamStart.propTypes = {
  switchPage: PropTypes.func
}

function mapStateToProps(state) {
  return {
    avatar: state.auth.get('pic')
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      loginTeam: authActions.loginTeam,
      addToast: globalActions.addToast
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(
  SubmitDecorator(LoginTeamStart)
)
