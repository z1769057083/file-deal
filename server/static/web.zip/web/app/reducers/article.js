import * as ActionType from 'actions/article'
import _ from 'lodash'
import {fromJS} from 'immutable'

const singleArticle = {
  title: '',
  summary: '',
  themeId: 42,
  original: true,
  picHeight: 0,
  picWidth: 0,
  pic: ''
}
const defaultArticles = _.range(0, 5).map(() => singleArticle)
const defaultState = fromJS({
  modalIsOpen: false,
  error: '',
  isSaving: false,
  theme: '',
  themeId: 0,
  articles: defaultArticles,

  // edit single article
  articleModal: false,
  article: {}
})

function articleReducer(state = defaultState, action) {
  switch (action.type) {
    case ActionType.PUBLISH_ARTICLE_SUCCESS:
      return state
        .set('isSaving', false)
        .set('articles', fromJS(defaultArticles))
        .set('modalIsOpen', false)
    case ActionType.UPDATE_ARTICLE_FIELD:
      return state.setIn(['articles', action.index, action.key], action.value)

    case ActionType.UPDATE_FIELD:
      return state.set(action.key, action.value)

    case ActionType.UPDATE_ARTICLE_THEME:
      return state.set('theme', action.theme).set('themeId', action.themeId)

    case ActionType.OPEN_ARTICLE_WINDOW:
      return state.set('modalIsOpen', true)

    case ActionType.REMOVE_IMAGE:
      return state.updateIn(['articles', action.index], article => {
        return article.set('pic', '').set('picHeight', 0).set('picWidth', 0)
      })

    case ActionType.CLOSE_ARTICLE_WINDOW:
      return state.set('modalIsOpen', false)

    case ActionType.EDIT_ARTICLE:
      return state.set('articles', fromJS([action.article]))

    case ActionType.RESET_ARTICLE:
      return state.set('articles', fromJS(defaultArticles))

    default:
      return state
  }
}

export default articleReducer
