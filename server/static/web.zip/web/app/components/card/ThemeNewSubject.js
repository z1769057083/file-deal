/**
 * 签入手贴时无满意的主题，需新建主题
 */
import React, {PropTypes} from 'react'
import {connect} from 'react-redux'
import {bindActionCreators} from 'redux'
import {Form} from 'react-validation/lib/build/validation.rc'
import SubjectCreation from 'components/corner-bar/SubjectCreation'
import * as globalActions from 'actions/global'

class ThemeNewSubject extends React.Component {
  message(message) {
    const {globalActions} = this.props
    globalActions.addToast({
      type: 'singleMsg',
      message,
      timeout: 1500
    })
  }
  
  handlePrev = () => {
    this.props.handleNext('subject')
  }
  
  render() {
    const {img} = this.props
    const leftImg = img || '/assets/images/default_pic.svg'
    const size = img ? '/cover' : ''
    const styles = {
      background: `url(${leftImg}) center center ${size} no-repeat #F1F1F1`
    }
    return (
      <div className="m-form-base no-margin-bottom">
        <div className="m-article-creation">
          <div className="article__main">
            <div className="article__col article__col--left">
              <div className="article__img" style={styles} />
            </div>
            <div className="article__col">
              <div className="m-subject-in-article">
                <SubjectCreation afterCreated={this.handlePrev} />
              </div>
            </div>
          </div>
          <div className="article__footer">
            <button
              type="button"
              className="btn btn-primary"
              onClick={this.handlePrev}>
              取消创建
            </button>
          </div>
        </div>
      </div>
    )
  }
}

ThemeNewSubject.propTypes = {
  handleNext: PropTypes.func.isRequired,
  img: PropTypes.string.isRequired,
  articleId: PropTypes.number.isRequired,
}

const mapDispatchToProps = dispatch => ({
  globalActions: bindActionCreators(globalActions, dispatch)
})

export default connect(null, mapDispatchToProps)(ThemeNewSubject)
