import React, { Component, PropTypes } from 'react'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import Header from 'components/Header'
import Waterfall from 'components/Waterfall'
import CornerBar from 'components/CornerBar'
import PageStatus from 'components/PageStatus'
import UpgradeTips from 'components/UpgradeTips'
import ICPFooter from 'components/global/ICPFooter'
import * as cardActions from 'actions/card'
import * as globalActions from 'actions/global'
import * as registerActions from 'actions/register'
import {
  RETRIEVE_TEAM,
  REGISTER_SUCCESS_EMAIL,
} from 'config/authPage';

class Home extends Component {
  constructor(props, context) {
    super(props, context)
    this.state = {
      loading: false
    }
    this.onScroll = this.onScroll.bind(this)
  }

  componentDidMount() {
    window.addEventListener('scroll', this.onScroll)
    this._loadCards()
    this._parseParams()
  }

  shouldComponentUpdate(props, state) {
    if (props.cards.equals(this.props.cards) === false) {
      return true
    }
    if (this.state.loading !== state.loading) {
      return true
    }
    return false
  }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.onScroll)
  }

  onScroll() {
    const inModal = this.props.cards.get('inModal')
    if (inModal) {
      return
    }
    const isBottom = (window.innerHeight + window.scrollY) >= document.body.offsetHeight
    if (isBottom) {
      this._loadCards()
    }
  }

  _parseParams() {
    const query = this.props.location.query
    const {actions} = this.props
    const {act} = query
    if (act === 'team_activate') {
      actions.activateTeam(query.code, ({response}) => {
        actions.showAuthWindow(REGISTER_SUCCESS_EMAIL,
          {...query, pic: response.data.pic})
      }, () => {
        this.props.actions.addToast({
          type: 'singleMsg',
          message: '激活失败',
          timeout: 2000
        })
      })
    } else if (act === 'team_find_password') {
      this.props.actions.showAuthWindow(RETRIEVE_TEAM, query)
    }
  }

  _loadCards() {
    const {cards, actions} = this.props
    const isEnd = cards.get('isEnd')
    const sortId = cards.get('sortId')
    const hasModal = this.props.hasModal
    if (!isEnd && !hasModal && !this.state.loading) {
      this.setState({
        loading: true
      })
      const articles = cards.get('articles')
      const page = cards.get('page')
      const finished = () => this.setState({loading: false})
      if (articles.size > page + 1) {
        const last = cards.get('list').last()
        if (last && last.get('nextPage')) {
          const nextPage = last.get('nextPage')
          const path = nextPage.get('path')
          const query = nextPage.get('query')
          actions.loadNextPageCards(path, query, finished, finished)
        }
      } else {
        actions.loadCards(finished, finished)
      }
    }
  }

  render() {
    let pageStatus = 'default'
    let statusHeight = 0
    const {cards} = this.props
    const isEnd = cards.get('isEnd')
    const sortId = cards.get('sortId')

    if (isEnd) {
      pageStatus = 'isEnd'
    } else if (this.state.loading) {
      pageStatus = 'loading'
    }

    const items = this.props.cards.get('list')

    if (items.size < 1) {
      statusHeight = 600
    }

    return (
      <div className="m-home m-header--wrap">
        <Header />
        <UpgradeTips width={1030}/>
        <Waterfall
          cards={items}
          type={0}
          location={this.props.location}
          />
        <PageStatus status={pageStatus} height={statusHeight}/>
        <CornerBar />
        <ICPFooter />
      </div>
    )
  }
}

function mapStateToProps(state) {
  return {
    cards: state.cards,
    hasModal: state.global.get('hasModal')
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      loadCards: cardActions.loadFirstPageCards,
      loadNextPageCards: cardActions.loadNextPageCards,
      showAuthWindow: globalActions.showAuthWindow,
      addToast: globalActions.addToast,
      activateTeam: registerActions.activateTeam,
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Home)
