/**
 * 手贴/有料/云库 tabs
 */
import React, { Component, PropTypes } from 'react'
import classNames from 'classnames'

const Types = [
  {type: 0, text: '手贴'},
  {type: 1, text: '有料'},
  {type: 2, text: '云库'},
]
const TypesFollowers = [
  {type: 0, text: '个人'},
  {type: 1, text: 'PRO'},
]
const TypesFollowing = [
  {type: 0, text: '个人'},
  {type: 1, text: 'PRO'},
  {type: 2, text: '团体'},
]
const typesMapping = {
  followers: TypesFollowers,
  following: TypesFollowing,
  works: Types
}
class TypeNav extends Component {
  render() {
    const items = typesMapping[this.props.mode]
    return (
      <div className={classNames("m-type-nav", {'two-columns': items.length === 2})}>
        {
          items.map((item, key) => {
            return (
              <div className={classNames("item", {
              active: this.props.type === item.type})}
                   key={key}
                onClick={() => this.props.onChange(item.type)}>{item.text}</div>
            )
          })
        }
      </div>
    )
  }
}

TypeNav.propTypes = {
  mode: PropTypes.oneOf(['followers', 'following', 'works']).isRequired,
  type: PropTypes.number.isRequired,
  onChange: PropTypes.func.isRequired
}

export default TypeNav