import React, {Component, PropTypes} from 'react'
import {Link} from 'react-router'
import {connect} from 'react-redux'

class OthersHeader extends Component {
  render() {
    const {auth} = this.props
    return (
      <div className="m-sub-header">
        <div className="nav flexbox">
          {auth.get('homePage') &&
          <Link to={`/user/${auth.get('homePage')}/profile`} className="flex">
            帐户
          </Link>}
          <Link
            to="/others"
            className="flex"
            onlyActiveOnIndex
            activeClassName="active">
            下载
          </Link>
          <Link to="/others/about" className="flex" activeClassName="active">
            关于
          </Link>
          <Link to="/others/legal" className="flex" activeClassName="active">
            法务
          </Link>
          <Link to="/others/feedback" className="flex" activeClassName="active">
            反馈
          </Link>
        </div>
      </div>
    )
  }
}

const mapStateToProps = state => ({
  auth: state.auth
})

export default connect(mapStateToProps)(OthersHeader)
