import React, { Component, PropTypes } from 'react'
import AuthSingleCard from 'components/AuthSingleCard'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import * as authActions from 'actions/auth'
import * as userActions from 'actions/user'
import * as globalActions from 'actions/global'
import {
  REGISTER_TEAM_SUCCESS
} from 'config/authPage'
import {
  Form,
  Input,
  Button
} from 'react-validation/lib/build/validation.rc'
import {SubmitDecorator} from 'decorators'

class IdEditorModal extends Component {
  constructor(props) {
    super(props)
    this.state = {
      homePagePlaceHolder: this.props.homePage,
      homePage: '',
      repeatHomePage: '',

      // asynchronous check homePage
      checking: false,
      isValid: false,
    }
    this.handleHomePage = this.handleHomePage.bind(this)
    this.handleRepeatHomePage = this.handleRepeatHomePage.bind(this)
    this.onBlur = this.onBlur.bind(this)
    this.onSubmit = this.onSubmit.bind(this)
  }
  handleHomePage(e) {
    this.setState({
      homePage: e.target.value,
    })
  }
  handleRepeatHomePage(e) {
    this.setState({
      repeatHomePage: e.target.value,
    })
  }
  onBlur() {
    const {homePage} = this.state
    if (!homePage) {
      return
    }

    this.setState({checking: true})
    this.props.actions.checkOasesCode(homePage, (state) => {
      this.setState({isValid: true, checking: false})
      this.props.hideError()
    }, () => {
      this.props.showError(`此绿洲ID已被占用`)
      this.setState({checking: false, isValid: false})
    })
  }
  onSubmit(event) {
    event.preventDefault()

    const {homePage} = this.state
    const success = (state) => {
      this.props.actions.addToast({
        type: 'black',
        message: '绿洲ID修改成功',
        pic: this.props.avatar,
        timeout: 2000,
        callback: this.props.closeAuthModal
      })
      this.props.actions.getAuthInfo()
    }
    const fail = (state) => {
      this.props.showError(state.message || '修改失败')
    }
    this.props.actions.modifyOasesCode(homePage, success, fail)
  }
  render() {
    const {homePagePlaceHolder, homePage, repeatHomePage, isValid} = this.state
    return (
      <AuthSingleCard closeAuthModal={this.props.closeAuthModal}>
        <Form className="card-main id-editor modal-form"
              ref={c => {this.form = c}}
              onSubmit={this.onSubmit}
          >
          <div className="header">个性 ID</div>
          <div className="main">
            <Input type="text"
                   name="homePage"
                   className="m-text"
                   containerClassName="input field-wrapper"
                   errorClassName="error"
                   onChange={this.handleHomePage}
                   onBlur={this.onBlur}
                   value={homePage}
                   validations={['required','oasesCode', 'oasesCodeConfirm']}
                   placeholder={homePagePlaceHolder}
              />
            <Input type="text"
                   name="repeatHomePage"
                   className="m-text"
                   containerClassName="input field-wrapper"
                   errorClassName="error"
                   onChange={this.handleRepeatHomePage}
                   value={repeatHomePage}
                   validations={['required', 'oasesCode', 'oasesCodeConfirm']}
                   placeholder="再次输入"
              />
            <div className="input">
              <div className="tips">ID仅可修改一次，确认后无法修改</div>
            </div>
          </div>
          <div className="footer flexbox single-button field-wrapper btn-footer">
            {
              isValid ?
                <Button type="submit" className="btn btn-primary">确认</Button>:
                <Button type="submit" className="btn btn-primary" disabled>确认</Button>
            }
            {this.props.error && <div className="form-error active">{this.props.error}</div>}
          </div>
        </Form>
      </AuthSingleCard>
    )
  }
}

IdEditorModal.propTypes = {
  switchPage: PropTypes.func,
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      getAuthInfo: authActions.getAuthInfo,
      checkOasesCode: userActions.checkOasesCode,
      modifyOasesCode: userActions.modifyOasesCode,
      addToast: globalActions.addToast,
    }, dispatch)
  }
}

function mapStateToProps(state) {
  return {
    avatar: state.auth.get('pic'),
    homePage: state.auth.get('homePage'),
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(
  SubmitDecorator(IdEditorModal)
)

