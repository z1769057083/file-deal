/**
 * 修改绿洲ID
 */
import React, {Component, PropTypes} from 'react'
import {connect} from 'react-redux'
import {bindActionCreators} from 'redux'
import * as userActions from 'actions/user'
import * as globalActions from 'actions/global'
import * as authActions from 'actions/auth'
import {ID_EDITOR_MODAL} from 'config/authPage'

const propTypes = {
  canEdit: PropTypes.bool.isRequired
}
class IdEditor extends Component {
  edit() {
    this.props.actions.showAuthWindow(ID_EDITOR_MODAL)
  }

  render() {
    const {homePage, canEdit} = this.props
    return (
      <div className="id-editor">
        <span className="oasis-id">www.airoases.com/</span>
        {
          canEdit ?
            <span
              className="homepage"
              onClick={this.edit.bind(this)}>{homePage}</span>:
            <span>{homePage}</span>
        }
      </div>
    )
  }
}

IdEditor.propTypes = propTypes

function mapStateToProps(state) {
  return {}
}
function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      showAuthWindow: globalActions.showAuthWindow,
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(IdEditor)
