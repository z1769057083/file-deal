import React, { Component, PropTypes } from 'react'
import {Link, withRouter} from 'react-router'
import LazyImage from './LazyImage'
import * as util from 'util/index'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import CardActionBar from 'components/card/CardActionBar'

class Card extends Component {
  render() {
    const data = this.props.data
    const imgUrl = data.pic
    return (
      <Link to={`/works/${data.id}?type=${this.props.type}&alt=${this.props.alt}`} className="m-card" style={data.position}
           onClick={(event) => this.props.onClickCard(event, `/works/${data.id}?type=${this.props.type}&alt=${this.props.alt}`)}>
        <div className="top" style={{height: data.scaledHeight, backgroundColor: data.topColor}}>
          <LazyImage src={imgUrl} style={{width: '100%', height: data.scaledHeight}} alt=""/>
          <CardActionBar id={parseInt(data.id)}
                         isFavorite={data.isFavorite}
                         wechatUrl={data.wechatUrl || ''}
                         title={data.title}
                         firstPic={imgUrl}
                         themeId={data.themeId || 0}
                         canEdit={this.props.canEdit}
                         showUnCollect={this.props.showUnCollect}
                         type={parseInt(this.props.type)} />
        </div>
        <div className="desc" style={{height: data.descHeight, overflow: 'hidden'}}>{data.title}</div>
        <div className="bottom flexbox" style={{height: data.bottomHeight}}>
          <div className="flex flexbox">
            <div className="info flex">
              <div className="view__wrap">
                <div className="icon icon-label"></div>
                <div className="view__count">{data.favoriteCnt} / <span className="p2">{data.readCnt}</span></div>
              </div>
            </div>
          </div>
        </div>
      </Link>
    )
  }
}

Card.propTypes = {
  onClickCard: PropTypes.func,
  canEdit: PropTypes.bool,
  showUnCollect: PropTypes.bool.isRequired
}

function mapStateToProps(state, ownProps) {
  return {
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Card)
