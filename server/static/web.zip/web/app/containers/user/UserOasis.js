import React, { Component, PropTypes } from 'react'
import { connect } from 'react-redux'
import {bindActionCreators } from 'redux'
import Waterfall from 'components/Waterfall'
import UpgradeTips from 'components/UpgradeTips'
import * as userActions from 'actions/user'

class UserOasis extends Component {
  constructor(props) {
    super(props)
    this.state = {
      type: 0
    }
  }
  componentDidMount() {
    const {user} = this.props
    if (!user.get('oasisInit')) {
      this._loadData(this.state.type)
    }
  }
  componentWillUnmount() {
    this.props.actions.resetCollectedCards()
  }
  _loadData(type) {
    const {user} = this.props
    const owernId = user.getIn(['userInfo', 'ownerId'])
    this.props.actions.getCollectedArts({
      lastSortId: -1,
      userId: owernId
    })
  }
  openSubjectModal() {

  }
  renderCreate() {
    return (
      <div className="card__wrap" onClick={this.openSubjectModal}>
        <div className="photo__wrap">
          <div className="photo__main photo__main--add">
            <div className="photo__add">
              <div className="icon icon-add-white" />
            </div>
            <div className="photo__text">创建主题</div>
          </div>
        </div>
      </div>
    )
  }
 
  render() {
    const {user, userId} = this.props
    if (!user.get('oasisInit')) {
      return null
    }
    const items = user.getIn(['oasis', 'artList'])
    const types = {0: '手贴', 1: '有料', 2: '云库'}
    const tips = (<div className="no-cards">{`暂未签入任何文章到${types[this.state.type]}`}</div>)
    const isSelf = user.getIn(['userInfo', 'ownerId']) === userId;
    return (
      <div className="user-oasis m-topic-wall">
        <Waterfall cards={items}
                   type={this.state.type}
                   showUnCollect={isSelf}
                   location={this.props.location}
                   column={4} />
        {items.size < 1 ? tips : null}
      </div>
    )
  }
}

function mapStateToProps (state) {
  return {
    user: state.user,
    userId: state.auth.get('id')
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      getCollectedArts: userActions.getCollectedArts,
      resetCollectedCards: userActions.resetCollectedCards,
      getUserArticles: userActions.getUserArticles,
      getUserThemes: userActions.getUserThemes,
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(UserOasis)
