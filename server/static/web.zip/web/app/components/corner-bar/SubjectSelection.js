import React, {PropTypes} from 'react'
import BlockImages from './BlockImages'
import {connect} from 'react-redux'
import {bindActionCreators} from 'redux'
import {Form} from 'react-validation/lib/build/validation.rc'
import Spinner from 'components/global/Spinner'
import * as articleActions from 'actions/article'
import * as globalActions from 'actions/global'
import * as userActions from 'actions/user'

class SubjectSelection extends React.Component {
  state = {
    themes: [],
    themeId: 0
  }

  componentDidMount() {
    this.getList()
  }

  getList = () => {
    const {userActions, userId} = this.props
    const payload = {imageCount: 1, userId}
    const success = ({response}) => this.setState({themes: response.data})
    userActions.getUserThemes(payload, success)
  }

  message(message) {
    const {globalActions} = this.props
    globalActions.addToast({
      type: 'singleMsg',
      message,
      timeout: 1500
    })
  }

  selectTheme = theme => () => {
    const {themeId} = this.state
    const {actions, article, showModal} = this.props
    if (themeId === 0) {
      const filter = item => item.get('picHeight') > 0 && item.get('pic') !== ''
      const mapper = item => item.set('themeId', theme.id)
      const articles = article.get('articles').filter(filter).map(mapper).toJS()
      const success = () => {
        this.setState({themeId: 0})
        actions.updateTheme(theme.name, theme.id)
        showModal('success')
      }
      const fail = () => {
        this.message('系统错误，发贴失败')
        this.setState({themeId: 0})
      }
      if (articles.length > 0) {
        this.setState({themeId: theme.id})
        actions.batchAddArticle(articles, success, fail)
      } else {
        this.message('至少需要上传一张手贴图片')
      }
    }
  }

  handlePrev = () => {
    this.props.handleNext('article')
  }

  createNewSubject = () => {
    this.props.handleNext('subject_creation')
  }

  render() {
    const {article} = this.props
    const articles = article.get('articles').toJS()
    const {themes, themeId} = this.state
    return (
      <Form
        className="m-form-base no-margin-bottom"
        ref={c => {
          this.form = c
        }}
        onSubmit={this.handlePrev}>
        <div className="m-article-creation">
          <div className="article__main">
            <div className="article__col article__col--left">
              <BlockImages preview={true} data={articles} />
            </div>
            <div className="article__col">
              <div className="article__subject">
                <div className="subject__title">主题</div>
                {themes.map((theme, key) => {
                  const image = theme.images.find(item => item.url !== '')
                  const url = image
                    ? image.url
                    : '/assets/images/default_pic.svg'
                  const size = image ? '/cover' : ''
                  const styles = {
                    background: `url(${url}) center center ${size} no-repeat #F1F1F1`
                  }
                  const pending = themeId === theme.id
                  return (
                    <div className="subject__row" key={key}>
                      <div className="subject__img" style={styles} />
                      <div className="subject__text">
                        {theme.name}
                      </div>
                      <div
                        className="subject__button"
                        onClick={this.selectTheme(theme)}>
                        <div className="icon icon-tag">
                          {pending
                            ? <Spinner />
                            : <div className="icon icon-tag-text" />}
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          </div>
          <div className="article__footer">
            <div className="footer__create" onClick={this.createNewSubject}>
              <span className="icon icon-create" />
              <span className="create__text">创建主题</span>
            </div>
            <button type="submit" className="btn btn-primary">
              上一步
            </button>
          </div>
        </div>
      </Form>
    )
  }
}

SubjectSelection.propTypes = {
  handleNext: PropTypes.func.isRequired,
  showModal: PropTypes.func.isRequired
}

const mapStateToProps = state => ({
  article: state.article,
  userId: state.auth.get('id')
})

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators(articleActions, dispatch),
  userActions: bindActionCreators(userActions, dispatch),
  globalActions: bindActionCreators(globalActions, dispatch)
})

export default connect(mapStateToProps, mapDispatchToProps)(SubjectSelection)
