import * as ActionType from 'actions/auth'
import {fromJS} from 'immutable'
import * as util from 'util/index'

let defaultState = fromJS({})
function authReducer (state = defaultState, action = {}) {
  switch(action.type) {
    case ActionType.GET_AUTH_INFO:
      const result = action.response ?  (action.response.data || {}) : {}
      return fromJS(util.nullToEmpty(result))
    case ActionType.LOG_OUT:
      return fromJS({})
    case ActionType.LOGIN_SUCCESS:
      return fromJS(util.nullToEmpty(action.response.data.userInfo))
    case ActionType.UPDATE_AVATAR_SUCCESS: {
      const {fileName} = action.response.data
      return state.set('pic', fileName)
    }

    case ActionType.GET_PRO_AUTH_INFO:
    {
      const result = action.response ?  (action.response.data || {}) : {}
      return fromJS(util.nullToEmpty(result))
    }

    case ActionType.APPLY_PRO_SUCCESS:
      return state.set('applyStatus', 1)

    default:
      return state
  }
}

export default authReducer