/**
 * Created by xijinling on 2017/7/19.
 */
import { CALL_API } from 'middleware/api'

/*
 * 关键字自动补全
 */
export const GET_ARTICLE_COMPLETE = Symbol('GET_ARTICLE_COMPLETE')
export function getArticleComplete(word, afterSuccess) {
  return {
    [CALL_API]: {
      method: 'get',
      path: '/api/v1/open/article/complete',
      query: {
        word
      },
      successType: GET_ARTICLE_COMPLETE,
      afterSuccess
    }
  }
}

/*
 * 获取热词
 */
export const GET_HOT_WORDS = Symbol('GET_HOT_WORDS')
export function getHotWords(afterSuccess) {
  return {
    [CALL_API]: {
      method: 'get',
      path: '/api/v1/open/article/hotword',
      successType: GET_HOT_WORDS,
      afterSuccess
    }
  }
}

/*
 * 搜索结果
 */
export const GET_ARTICLE_SEARCH = Symbol('GET_ARTICLE_SEARCH')
export function getArticleSearch(query, afterSuccess) {
  if(!query.sortId) query.sortId = -1
  return {
    [CALL_API]: {
      method: 'get',
      query,
      path: '/api/v1/open/article/search',
      successType: GET_ARTICLE_SEARCH,
      afterSuccess
    }
  }
}

export const UPDATE_SEARCH = Symbol('UPDATE_SEARCH')
export function updateSearch(key, value) {
  return {type: UPDATE_SEARCH, key, value}
}

export const RESET = Symbol('RESET')
export function reset() {
  return {type: RESET}
}