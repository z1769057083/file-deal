import React, {PropTypes} from 'react'
import CountedTextarea from 'components/forms/CountedTextarea'
import {
  Form,
  Input,
  Button,
  Textarea
} from 'react-validation/lib/build/validation.rc'
import _ from 'lodash'
import {bindActionCreators} from 'redux'
import {connect} from 'react-redux'
import {browserHistory} from 'react-router'
import * as subjectActions from 'actions/subject'
import * as globalActions from 'actions/global'
import Select from 'react-select';

class SubjectCreation extends React.Component {
  state = {
    canBeSubmit: false
  }

  componentDidMount() {
    const {actions} = this.props
    actions.getFirstClass()
  }

  componentDidUpdate(prev) {
    const {subject, actions} = this.props
    const classId = subject.getIn(['subject', 'classId'])
    if (prev.subject.getIn(['subject', 'classId']) !== classId) {
      actions.getSecondClass(classId)
    }
  }

  componentWillUnmount() {
    const {actions} = this.props
    actions.resetSubject()
  }

  message(msg, timeout = 1500) {
    const {globalActions} = this.props
    globalActions.addToast({
      type: 'singleMsg',
      message: msg,
      timeout
    })
  }

  handleSubmit = e => {
    e.preventDefault()
    const {subject, actions, globalActions, afterCreated} = this.props
    const payload = subject.get('subject').toJS()
    payload.label = (payload.label || '').replace(/\//g, '_')

    const params = {
      payload,
      afterSuccess: state => {
        const id = state.response.data.id
        this.message(payload.id ? '保存主题成功' : '创建主题成功')
        if (afterCreated) {
          afterCreated()
        } else {
          setTimeout(() => {
            sessionStorage.setItem('newtopic', true);
            if (payload.id > 0) {
              location.href = `/topic/${payload.id}`
            } else {
              browserHistory.push(`/topic/${id}`)
            }
          }, 1500)
        }
      },
      afterError: ({message}) => {
        this.message(message, 2000)
      }
    }
    const method = payload.id ? 'updateSubject' : 'addSubject'
    actions[method](params)
  }

  handleDeletion = () => {
    const {subject, actions, auth} = this.props
    const id = subject.getIn(['subject', 'id'])
    const success = () => {
      this.message('删除成功')
      setTimeout(() => {
        location.href = `/${auth.get('homePage')}`
      }, 1500)
    }
    actions.deleteSubject(id, success)
  }

  canBeSave() {
    const {subject} = this.props
    const payload = subject.get('subject').toJS()
    let isValid = true
    _.each(['name', 'description', 'wishes', 'location'], key => {
      if (payload[key] === '') {
        isValid = false
      }
    })
    return isValid
  }

  updateField = key => evt => {
    const {actions} = this.props
    const value =
      ['classId', 'childrenClassId'].indexOf(key) > -1
        ? parseInt(evt.value)
        : evt.target.value
    actions.updateSubjectField(key, value)
  }

  render() {
    const {subject} = this.props
    const data = subject.get('subject').toJS()
    return (
      <Form
        className="m-form-base no-margin-bottom"
        ref={c => {
          this.form = c
        }}
        onSubmit={this.handleSubmit}>
        <div className="row">
          <div className="col-1">主题</div>
          <div className="col-2">
            <CountedTextarea
              className="m-text"
              placeholder="这个项目的名称"
              maxLength={32}
              value={data.name}
              onChange={this.updateField('name')}
            />
            <div className="field-tips">*必须填写</div>
          </div>
        </div>
        <div className="row">
          <div className="col-1">描述</div>
          <div className="col-2">
            <CountedTextarea
              className="m-text"
              placeholder="这个项目的一些特殊描述..."
              maxLength={120}
              value={data.description}
              onChange={this.updateField('description')}
            />
            <div className="field-tips">*必须填写</div>
          </div>
        </div>
        <div className="section">
          <div className="row">
            <div className="col-1">设计师语</div>
            <div className="col-2">
              <CountedTextarea
                className="m-text"
                placeholder="项目设计师关于项目的思考..."
                maxLength={120}
                value={data.wishes}
                onChange={this.updateField('wishes')}
              />
              <div className="field-tips">
                *必须填写，此处为设计师语和主题封皮，默认开头1-8个字为封皮上的关键字
              </div>
            </div>
          </div>
        </div>
        <div className="section">
          <div className="row">
            <div className="col-1">地理位置</div>
            <div className="col-2">
              <CountedTextarea
                className="m-text"
                placeholder="这个项目的地址"
                maxLength={80}
                value={data.location}
                onChange={this.updateField('location')}
              />
              <div className="field-tips">*必须填写</div>
            </div>
          </div>
        </div>
        <div className="section">
          <div className="row">
            <div className="col-1">大类</div>
            <div className="col-2">
              <Select
                className="m-text"
                value={String(data.classId)}
                onChange={this.updateField('classId')}
                searchable={false}
                options={
                  subject.get('firstClass').map((item, key) => {
                    return {
                      value: item.get('id'),
                      label: item.get('name')
                    }
                  }).toArray()
                }
                style={{
                  padding: 0
                }}>
              </Select>
            </div>
          </div>
          <div className="row">
            <div className="col-1">中类</div>
            <div className="col-2">
              <Select
                className="m-text"
                value={String(data.childrenClassId)}
                onChange={this.updateField('childrenClassId')}
                searchable={false}
                options={
                  subject.get('secondClass').map((item, key) => {
                    return {
                      value: item.get('id'),
                      label: item.get('name')
                    }
                  }).toArray()
                }>
              </Select>
            </div>
          </div>
          <div className="row">
            <div className="col-1">标签</div>
            <div className="col-2">
              <CountedTextarea
                className="m-text"
                placeholder="例如：咖啡厅/工业风/性冷淡；请用“/”顿开，至多4个标签"
                maxLength={80}
                value={data.label}
                onChange={this.updateField('label')}
              />
              <div className="field-tips">*以上3项非必填，勾选和填写，帮助用户找到并了解这个项目和去处</div>
            </div>
          </div>
        </div>
        <div className="row row-last">
          <div className="col-1" />
          <div className="col-2 from-right">
            {data.id > 0
              ? <Button
                  type="button"
                  className="btn btn-delete"
                  onClick={this.handleDeletion}>
                  删除
                </Button>
              : <div />}
            {!this.canBeSave()
              ? <Button type="submit" className="btn btn-primary" disabled>
                  {data.id ? '保存' : '确认'}
                </Button>
              : <Button type="submit" className="btn btn-primary">
                  {data.id ? '保存' : '确认'}
                </Button>}
          </div>
        </div>
      </Form>
    )
  }
}

SubjectCreation.propTypes = {
  afterCreated: PropTypes.func
}

const mapStateToProps = state => ({
  subject: state.subject,
  auth: state.auth,
})

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators(subjectActions, dispatch),
  globalActions: bindActionCreators(globalActions, dispatch)
})

export default connect(mapStateToProps, mapDispatchToProps)(SubjectCreation)
