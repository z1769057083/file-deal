import React from 'react'
import {Router, Route, IndexRoute} from 'react-router'

import App from 'containers/App'
import Home from 'containers/Home'
import DesignerHome from 'containers/artisan/DesignerHome'
import HotRecommend from 'containers/artisan/HotRecommend'
import Profile from 'containers/user/Profile'
import ProfileAccount from 'containers/user/ProfileAccount'
import Works from 'containers/works/Works'
import User from 'containers/user/User'
import UserFollowing from 'containers/user/UserFollowing'
import UserFollowers from 'containers/user/UserFollowers'
import UserOasis from 'containers/user/UserOasis'
import UserTopic from 'containers/user/UserTopic'
import UserWorks from 'containers/user/UserWorks'
import Others from 'containers/others/Others'
import OthersDownload from 'containers/others/OthersDownload'
import OthersAbout from 'containers/others/OthersAbout'
import OthersLegal from 'containers/others/OthersLegal'
import Feedback from 'containers/others/Feedback'
import Search from 'containers/Search'

// mobile
import Legal from 'containers/mobile/Legal'
import Service from 'containers/mobile/Service'
import Privacy from 'containers/mobile/Privacy'
import Download from 'containers/mobile/Download'

export default function(history) {
  return (
    <Router history={history}>
      <Route path="/" component={App} >
        <IndexRoute component={Home} />
        <Route path="designer">
          <IndexRoute component={DesignerHome} />
          <Route path="hot" component={HotRecommend}/>
        </Route>
        <Route path="works/:id" component={Works} />
        <Route path="user/:id" component={User} >
          <IndexRoute component={UserWorks} />
          <Route path="oasis" component={UserOasis} />
        </Route>
        <Route path="topic/:themeId" component={UserTopic} />
        <Route path="user/:id/profile" component={Profile}>
          <IndexRoute component={ProfileAccount} />
        </Route>
        <Route path="others" component={Others} >
          <IndexRoute component={OthersDownload} />
          <Route path="about" component={OthersAbout} />
          <Route path="legal" component={OthersLegal} />
          <Route path="feedback" component={Feedback} />
        </Route>
        <Route path="search" component={Search} />
        <Route path="mobile">
          <Route path="legal" component={Legal} />
          <Route path="service" component={Service} />
          <Route path="privacy" component={Privacy} />
          <Route path="download" component={Download} />
        </Route>
        <Route path="/:oasisId" component={User}>
          <IndexRoute component={UserWorks} />
        </Route>
      </Route>
    </Router>
  )
}
