import React, { Component, PropTypes } from 'react'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import AuthDoubleCard from 'components/AuthDoubleCard'
import PhoneInput from 'components/forms/PhoneInput'
import classNames from 'classnames'
import {
  LOGIN_USER_START,
  REGISTER_TEAM_START,
  RETRIEVE_USER_START,
  REGISTER_USER
} from 'config/authPage'
import {
  sendCode,
  registerUser,
  updateCode,
  updatePhone,
  verifyCode
} from 'actions/register'
import {
  Form,
  Input,
  Button
} from 'react-validation/lib/build/validation.rc'
import {SubmitDecorator} from 'decorators'
import validator from 'validator'

const COUNT_DOWN_SECONDS = 60
class RegisterUserStart extends Component {
  constructor(props, context) {
    super(props, context)
    this.state = {
      registerPhone: '',
      registerCode: '',
      codeSent: false,
      countDown: false,
      seconds: 0,
      interval: null,
    }
    this.sendQRCode = this.sendQRCode.bind(this)
    this.registerPhoneChanged = this.registerPhoneChanged.bind(this)
    this.registerCodeChanged = this.registerCodeChanged.bind(this)
    this.onSubmit = this.onSubmit.bind(this)
  }

  componentWillUnmount() {
    window.clearInterval(this.state.interval)
  }

  registerPhoneChanged(value) {
    this.setState({
      registerPhone: value
    })
  }

  registerCodeChanged(e) {
    this.setState({
      registerCode: e.target.value,
    })
  }

  sendQRCode() {
    const {registerPhone, seconds} = this.state
    if (!validator.isMobilePhone(registerPhone.replace(/ /g, ''), 'zh-CN')) {
      return
    }
    if (seconds > 0) {
      return
    }
    this.countDown()
    this.props.dispatch(sendCode({
      phone: registerPhone,
      channel: 0,
      afterSuccess: () => {
        this.props.dispatch(updatePhone(registerPhone))
      }
    }))
  }

  countDown() {
    this.setState({
      codeSent: true,
      seconds: COUNT_DOWN_SECONDS
    })
    this.state.seconds = COUNT_DOWN_SECONDS
    this.state.interval = setInterval(() => {
      const seconds = this.state.seconds - 1
      if (seconds >= 0) {
        this.setState({
          seconds: this.state.seconds - 1
        })
      } else {
        clearInterval(this.state.interval)
      }
    }, 1000)
  }

  onSubmit(event) {
    event.preventDefault()
    const {registerPhone, registerCode} = this.state
    if (!registerPhone || !registerCode) {
      return
    }
    this.props.dispatch(verifyCode({
      phone: registerPhone,
      verifyCode: registerCode,
      channel: 0,
      afterSuccess: () => {
        this.props.dispatch(updateCode(registerCode))
        this.props.switchPage(REGISTER_USER)
      },
      afterError: () => this.props.showError('验证码不正确')
    }))
  }

  render() {
    const {seconds} = this.state
    return (
      <AuthDoubleCard closeAuthModal={this.props.closeAuthModal}>
        <div className="nav">
          <div className="item active">个人</div>
          <div className="item"
               onClick={() => {this.props.switchPage(REGISTER_TEAM_START)}}>indie
          </div>
        </div>
        <Form className="user modal-form"
              ref={c => {this.form = c}}
              onSubmit={this.onSubmit}
          >
          <div className="input">
            <div className="m-input-with-qrcode">
              <PhoneInput
                className="m-text"
                containerClassName="field-wrapper"
                errorClassName="error"
                value={this.state.registerPhone}
                placeholder="手机"
                name="phone"
                onChange={this.registerPhoneChanged}
                validations={['required', 'phone']}
                />
              <div className="qr-code"
                   onClick={this.sendQRCode}>
                {seconds > 0 ? `${seconds}s` : '验证码'}
              </div>
            </div>
          </div>
          <div className="input">
            <Input type="text"
                   className="m-text"
                   containerClassName="field-wrapper"
                   errorClassName="error"
                   onChange={this.registerCodeChanged}
                   value={this.state.registerCode}
                   validations={['required']}
                   placeholder="验证码"
              />
          </div>
          <div className="forget-register flexbox">
            <div className="forget clickable" onClick={() => {this.props.switchPage(RETRIEVE_USER_START)}}>忘记密码</div>
            <div className="register clickable" onClick={() => {this.props.switchPage(LOGIN_USER_START)}}>用户登录</div>
          </div>
          <div className="field-wrapper btn-footer">
            <Button
              type="submit"
              className="btn btn-primary">
              {this.state.loading ? <Spinner /> : '确认'}
            </Button>
            {this.props.error && <div className="form-error active">{this.props.error}</div>}
          </div>
          <div className="p1">第三方登录</div>
          <div className="third-party flexbox">
            <div className="item flex">
              <div className="icon icon-wechat"></div>
            </div>
            <div className="item flex">
              <div className="icon icon-weibo"></div>
            </div>
            <div className="item flex">
              <div className="icon icon-facebook"></div>
            </div>
          </div>
        </Form>
      </AuthDoubleCard>
    )
  }
}

RegisterUserStart.propTypes = {
  switchPage: PropTypes.func
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      sendCode,
      registerUser,
      updateCode,
      updatePhone,
      verifyCode
    }, dispatch)
  }
}

function mapStateToProps(state) {
  return {register: state.register}
}

export default connect(mapDispatchToProps)(SubmitDecorator(RegisterUserStart))