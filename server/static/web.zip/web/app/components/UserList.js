import React, { Component, PropTypes } from 'react'
import { connect } from 'react-redux'
import {bindActionCreators } from 'redux'
import {Link} from 'react-router'
import {List} from 'immutable'
import Follow from 'components/profile/Follow'
import * as userActions from 'actions/user'

class UserList extends Component {
  constructor(props) {
    super(props)
    this.state = {
      items: this.props.items
    }
  }
  componentWillReceiveProps(nexProps) {
    this.setState({
      items: nexProps.items
    })
  }
  _unFollow(item) {
    this.props.actions.follow({
      ownerId: item.id,
      optValue: 0
    }, () => {
      this.state.items = _.filter(this.state.items, (current) => {
        return item.id != current.id
      })
      this.forceUpdate()
    })
  }
  render() {
    const items = this.state.items
    const blank = (
      <div className="no-users">{this.props.tips}</div>
    )
    return (
      <div className="m-user-follow clearfix">
        {items.map((item, key) => {
          const followProps = this.props.showCancelButton ?
          {
            isSelf: true,
            isAttention: '1',
            toId: item.id,
            userPic: item.pic || ''
          }: {}
          return <div className="item" key={key}>
            <Link to={`/user/${item.id}`} className="avatar">
              <img src={item.pic || "/assets/images/default_avatar.svg"} alt=""/>
            </Link>
            <Link to={`/user/${item.id}`} className="name">{item.name}</Link>
            {this.props.showCancelButton && <Follow {...followProps} />}
          </div>
        })}
        {items.length < 1 ? blank: null}
      </div>
    )
  }
}

UserList.propTypes = {
  items: PropTypes.array.isRequired,
  showCancelButton: PropTypes.bool,
  tips: PropTypes.string
}

function mapStateToProps (state) {
  return {
  }
}

function mapDispatchToProps (dispatch) {
  return {
    actions: bindActionCreators({
      follow: userActions.follow
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(UserList)