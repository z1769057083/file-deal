import React, { Component, PropTypes } from 'react'
import { connect } from 'react-redux'
import ToastItem from 'components/ToastItem'

class Toast extends Component {
  render() {
    const toasts = this.props.global.get('toasts').toJS()
    return (
      <ul className="m-toast-container" style={{opacity: 1}}>
        {
          toasts.map((toast, key) => {
            return <ToastItem toast={toast} key={key} />
          })
        }
      </ul>
    )
  }
}

function mapStateToProps (state, ownProps) {
  return {
    global: state.global
  }
}

export default connect(mapStateToProps)(Toast)
