let config = {
  API_BASE_URL: process.env.API_BASE_URL || '//www.airoases.com'
}
export default config;
