import React, { Component, PropTypes } from 'react'
import {Link} from 'react-router'

class AuthDoubleCard extends Component {
  render() {
    return (
      <div className="auth-card auth-login-register">
        {/*<div className="logo">*/}
          {/*<a href="/" className="icon icon-logo"></a>*/}
        {/*</div>*/}
        <div className="card flexbox">
          <div className="left-card flex">
            <div className="logo"></div>
            <div className="p1">空 中 绿 洲</div>
            {/*<div className="p2">「 解构 ／再生 」</div>*/}
            <div className="close icon  xzzxxxxxx icon-close-white"
              onClick={this.props.closeAuthModal}></div>
          </div>
          <div className="right-card flex">
            {this.props.children}
          </div>
          <div className="agreement">
            如果继续则表示您已同意接受 <br/>
            {/*<a href="/others/legal#legal" target="_blank">法律声明</a>、*/}
            <a href="/others/legal#service" target="_blank">服务条款</a>、
            <a href="/others/legal#policy" target="_blank">隐私政策</a>。
          </div>
        </div>
      </div>
    )
  }
}

AuthDoubleCard.propTypes = {
  closeAuthModal: PropTypes.func
}
AuthDoubleCard.defaultProps = {
  closeAuthModal: () => {}
}

export default AuthDoubleCard
