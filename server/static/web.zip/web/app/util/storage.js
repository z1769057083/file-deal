import store from 'store'

function set(name, value) {
  store.set(name, value)
}

function get(name) {
  return store.get(name)
}

function remove(name) {
  return store.remove(name)
}

function clearAll() {
  store.clearAll()
}

const Storage = {set, get, remove, clearAll}
export default Storage
