import { CALL_API, CHAIN_API } from 'middleware/api'

export const LOADED_USER_LIST = Symbol('LOADED_USER_LIST')
export function loadUserList() {
  return {
    [CALL_API]: {
      method: 'get',
      path: '/api/artisan/userList',
      successType: LOADED_USER_LIST
    }
  }
}