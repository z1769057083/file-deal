import React, { Component, PropTypes } from 'react'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import Modal from 'react-modal'

import LoginUserStart from 'components/LoginUserStart'
import RegisterUserStart from 'components/RegisterUserStart'
import RegisterUser from 'components/RegisterUser'
import RegisterUserSuccess from 'components/RegisterUserSuccess'
import PasswordRetrieve from 'components/PasswordRetrieve'
import PasswordRetrieved from 'components/PasswordRetrieved'
import PasswordRetrieveStart from 'components/PasswordRetrieveStart'
import ProApply from 'components/ProApply'

import LoginTeamStart from 'components/LoginTeamStart'
import RegisterTeamStart from 'components/RegisterTeamStart'
import RegisterTeam from 'components/RegisterTeam'
import RegisterTeamSuccess from 'components/RegisterTeamSuccess'
import RegisterSuccessEmail from 'components/RegisterSuccessEmail' //激活成功
import RetrieveTeamStart from 'components/RetrieveTeamStart'
import RetrieveTeamSent from 'components/RetrieveTeamSent'
import RetrieveTeam from 'components/RetrieveTeam'
import RetrieveTeamSuccess from 'components/RetrieveSuccess'
import TeamApplyVerify from 'components/TeamApplyVerify'
import TeamVerified from 'components/TeamVerified'
import IdEditorModal from 'components/profile/IdEditorModal'
import LoginCoverStart from 'components/LoginCoverStart'
import cx from 'classnames'
import * as globalActions from 'actions/global'

const modules = {
  //User
  LOGIN_USER_START: LoginUserStart,

  REGISTER_USER_START: RegisterUserStart,
  REGISTER_USER: RegisterUser,
  REGISTER_USER_SUCCESS: RegisterUserSuccess,

  RETRIEVE_USER_START: PasswordRetrieveStart,
  RETRIEVE_USER: PasswordRetrieve,
  RETRIEVE_USER_SUCCESS: PasswordRetrieved,

  PRO_APPLY: ProApply,

  //Team
  LOGIN_TEAM_START: LoginTeamStart,

  REGISTER_TEAM_START: RegisterTeamStart,
  RETRIEVE_TEAM_SENT: RetrieveTeamSent,
  REGISTER_TEAM: RegisterTeam,
  REGISTER_TEAM_SUCCESS: RegisterTeamSuccess,
  REGISTER_SUCCESS_EMAIL: RegisterSuccessEmail,

  RETRIEVE_TEAM_START: RetrieveTeamStart,
  RETRIEVE_TEAM: RetrieveTeam,
  RETRIEVE_TEAM_SUCCESS: RetrieveTeamSuccess,

  VERIFY_TEAM_START: TeamApplyVerify,
  VERIFY_TEAM_SUCCESS: TeamVerified,

  ID_EDITOR_MODAL: IdEditorModal,

  LOGIN_COVER_START: LoginCoverStart,
}

class Auth extends Component {
  afterOpenModal() {
    document.querySelector('.ReactModal__Overlay').scrollTop = 0
  }
  switchPage(type) {
    this.props.actions.showAuthWindow(type)
  }
  closeAuthModal() {
    this.props.onRequestClose()
  }
  render() {
    const type = this.props.global.get('authWindowType')
    const customStyles = {
      overlay: {
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'transparent',
        zIndex: 500
      },
      content: {
        top: '0',
        left: '0',
        right: '0',
        height: '100%',
        border: 'none',
        position: 'relative',
        background: 'transparent',
        padding: '0'
      }
    }
    const isWhite = type === 'LOGIN_COVER_START'
    const Module = modules[type]
    const props = {
      switchPage: this.switchPage.bind(this),
      closeAuthModal: this.closeAuthModal.bind(this)
    }
    return (
      type ?
      <Modal
        isOpen={this.props.isOpen}
        onRequestClose={this.props.onRequestClose}
        onAfterOpen={this.afterOpenModal.bind(this)}
        style={customStyles}
        contentLabel="Modal"
        >
        <div className={cx("modal-filter-bg", {white: isWhite})} />
        <Module {...props}/>
      </Modal>: null
    )
  }
}

function mapStateToProps(state) {
  return {
    global: state.global
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      showAuthWindow: globalActions.showAuthWindow
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Auth)
