import React, { Component, PropTypes } from 'react'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import AuthSingleCard from 'components/AuthSingleCard'
import * as registerActions from 'actions/register'
import {
  RETRIEVE_USER_START,
  LOGIN_TEAM_START,
  RETRIEVE_TEAM_SENT,
} from 'config/authPage'
const COUNT_DOWN_SECONDS = 60
import {
  Form,
  Input,
  Button
} from 'react-validation/lib/build/validation.rc'
import {SubmitDecorator} from 'decorators'

class RetrieveTeamStart extends Component {
  constructor(props, context) {
    super(props, context)
    this.state = {
      email: this.props.register.get('forgetEmail'),
    }
    this.onSubmit = this.onSubmit.bind(this)
    this.handleEmail = this.handleEmail.bind(this)
    this.handlePrev = this.handlePrev.bind(this)
  }

  handleEmail(e) {
    this.setState({
      email: e.target.value
    })
  }

  handlePrev() {
    this.props.switchPage(LOGIN_TEAM_START)
  }

  onSubmit(event) {
    event.preventDefault()
    const {email} = this.state
    if (!email) {
      return
    }
    this.props.actions.sendTokenEmail({
      email,
      channel: 1
    }, () => {
      this.props.actions.updateTeamForgetEmail(email)
      this.props.switchPage(RETRIEVE_TEAM_SENT)
    }, (error) => {
      if(error.message) {
        this.props.showError(error.message)
      } else {
        this.props.showError('发送邮件失败')
      }
    })
  }

  render() {
    return (
      <AuthSingleCard closeAuthModal={this.props.closeAuthModal}>
        <Form className="card-main password-retrieve-start modal-form"
          ref={c => {this.form = c}}
          onSubmit={this.onSubmit}
          >
          <div className="header">密码找回</div>
          <div className="main">
            <div className="team">
                <Input type="text"
                name="email"
                className="m-text"
                containerClassName="input field-wrapper"
                errorClassName="error"
                onChange={this.handleEmail}
                value={this.state.email}
                validations={['required', 'email']}
                placeholder="邮箱"
              />
              <p className="p1">使用其他账号 <span className="login clickable" onClick={this.handlePrev}>登陆</span></p>
            </div>
          </div>
          <div className="footer flexbox single-button field-wrapper btn-footer">
            <Button type="submit" className="btn btn-primary">发送</Button>
            {this.props.error && <div className="form-error active">{this.props.error}</div>}
          </div>
        </Form>
      </AuthSingleCard>
    )
  }
}

RetrieveTeamStart.propTypes = {
  switchPage: PropTypes.func
}

function mapStateToProps(state) {
  return {register: state.register}
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      updateTeamForgetEmail: registerActions.updateTeamForgetEmail,
      sendTokenEmail: registerActions.sendTokenEmail,
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(SubmitDecorator(RetrieveTeamStart))
