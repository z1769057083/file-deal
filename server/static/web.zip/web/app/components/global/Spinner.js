/**
 * Spinner.
 */
import React, { Component, PropTypes } from 'react'

class Spinner extends Component {
  render() {
    return (
      <svg className="m-spinner" width="30px" height="30px" viewBox="0 0 30 30" xmlns="http://www.w3.org/2000/svg">
        <circle className="path" fill="none" strokeWidth="3" strokeLinecap="round" cx="15" cy="15" r="10"></circle>
      </svg>
    )
  }
}

export default Spinner