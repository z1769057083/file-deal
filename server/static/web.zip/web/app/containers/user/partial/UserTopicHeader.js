import React, {PropTypes} from 'react'
import {connect} from 'react-redux'
import {bindActionCreators} from 'redux'
import * as actions from 'actions/subject'
import {fromJS} from 'immutable'
import * as userActions from 'actions/user'
function getURLData() {
  let param = {};
  try{
    let loc=window.location;
    let search=loc.search.substr(1);
    let k=search.indexOf('&')!=-1?search.split('&'):[search];
    for (let i = 0; i < k.length; i++) {
      if(k[i]!=""){
        let v = k[i].split('=');
          for (let j = 0; j < v.length; j++) {
              let key = decodeURIComponent(v[0]);
              let value = decodeURIComponent(v[1]||'');
              param[key] = value;
          }
      }
    }
  }catch(e) {}
  return param;
}

const {curr_id} = getURLData();

class UserTopicHeader extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      ownerPic: ''
    }
  }
  editSubject = () => {
    const {theme, actions} = this.props
    const data = {
      name: theme.name,
      description: theme.description,
      classId: theme.classId || -1,
      childrenClassId: theme.childrenClassId || -1,
      label: (theme.label || '').replace(/_/g, '/'),
      wishes: theme.wishes || '',
      location: theme.location || '',
      id: theme.id
    }
    actions.editSubject(fromJS(data))
    actions.openSubjectWindow()
  }
  componentDidMount() {
    console.log('curr_id',curr_id);
    this.props.actions.loadUserInfo(curr_id, ({response}) => {
      this.setState({
        ownerPic: response.data.pic
      });
    })
  }
  render() {
    const {theme, total, auth} = this.props
    const isSelf = theme.userName === auth.get('name')
    const {ownerPic} = this.state;
    return (
      <div className="m-user-header m-user-header-new">
        <div className="user-info flexbox">
          <div className="main__wrap">
            <div className="main__title">
              {theme.name}
            </div>
            <div className="main__count">
              {total >= 0 ? `${total}个贴` : ''}
            </div>
            {isSelf &&
              <div className="icon icon-edit2" onClick={this.editSubject} />}
          </div>

          <div className="flex">
            <div className="desc desc-shim">
              {theme.description}
            </div>
          </div>
        </div>

        <div className="bottom__wrap bottom__wrap--flex">
          <div className="bottom__title">手帖</div>
          <div className="bottom__avatar">
            {auth.get('pic') &&
              <a href={`/user/${curr_id}`}>
                <img src={ownerPic} alt="" />
              </a>}
          </div>
        </div>
      </div>
    )
  }
}

UserTopicHeader.propTypes = {
  theme: PropTypes.object.isRequired,
  total: PropTypes.number.isRequired
}

const mapStateToProps = state => ({
  user: state.user,
  auth: state.auth
})

actions.loadUserInfo = userActions.loadUserInfo;
const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators(actions, dispatch),
})

export default connect(mapStateToProps, mapDispatchToProps)(UserTopicHeader)
