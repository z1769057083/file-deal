import React from 'react'
import Avatar from 'components/Avatar'

const WorksReference = ({data}) => {
  if (!data.alt) {
    return <a href={`/user/${data.authorId}`} target="_blank">
      <div className="works-reference">
        <Avatar pic={data.authorPic} width={35}/>
        <span>{data.authorName}</span>
      </div>
    </a>
  }
  return (
    <div className="works-reference">
      <Avatar pic={data.authorPic} width={35}/>
      <span>{data.authorName}</span>
    </div>
  )
}

export default WorksReference