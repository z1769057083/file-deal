import React, { Component, PropTypes } from 'react'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import AuthDoubleCard from 'components/AuthDoubleCard'
import classNames from 'classnames'
import {
  LOGIN_TEAM_START,
  REGISTER_USER_START,
  RETRIEVE_TEAM_START,
  REGISTER_TEAM
} from 'config/authPage'
import {
  updateTeamEmail,
} from 'actions/register'
import {
  Form,
  Input,
  Button
} from 'react-validation/lib/build/validation.rc'

class RegisterTeamStart extends Component {
  constructor(props, context) {
    super(props, context)
    this.state = {
      email: '',
    }
    this.emailChanged = this.emailChanged.bind(this)
    this.onSubmit = this.onSubmit.bind(this)
  }
  emailChanged(e) {
    this.setState({
      email: e.target.value
    })
  }
  onSubmit(event) {
    event.preventDefault()

    const {email} = this.state
    this.props.dispatch(updateTeamEmail(email))
    this.props.switchPage(REGISTER_TEAM)
  }
  render() {
    return (
      <AuthDoubleCard closeAuthModal={this.props.closeAuthModal}>
        <div className="nav">
          <div className="item"
               onClick={() => {this.props.switchPage(REGISTER_USER_START)}}>个人</div>
          <div className="item active">indie</div>
        </div>
        <Form className="user modal-form"
              ref={c => {this.form = c}}
              onSubmit={this.onSubmit}
          >
          <div className="input">
            <Input type="text"
                   name="email"
                   className="m-text"
                   containerClassName="field-wrapper"
                   errorClassName="error"
                   onChange={this.emailChanged}
                   value={this.state.email}
                   validations={['required', 'email']}
                   placeholder="邮箱"
              />
          </div>
          <div className="forget-register flexbox">
            <div className="forget clickable" onClick={() => {this.props.switchPage(RETRIEVE_TEAM_START)}}>忘记密码</div>
            <div className="register clickable" onClick={() => {this.props.switchPage(LOGIN_TEAM_START)}}>用户登录</div>
          </div>
          <div className="field-wrapper btn-footer">
            <Button
              type="submit"
              className="btn btn-primary btn-block">
              确认
            </Button>
          </div>
        </Form>
      </AuthDoubleCard>
    )
  }
}

RegisterTeamStart.propTypes = {
  switchPage: PropTypes.func
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      updateTeamEmail,
    }, dispatch)
  }
}

export default connect(mapDispatchToProps)(RegisterTeamStart)