import React, { Component, PropTypes } from 'react'

class Avatar extends Component {
  render() {
    const styles = {
      width: this.props.width,
      height: this.props.width,
    }
    const pic = this.props.pic || this.props.defaultPic
    return (
      <div className="m-avatar avatar" style={styles}>
        {pic ? <img src={pic} alt=""/>: null}
      </div>
    )
  }
}

Avatar.propTypes = {
  width: PropTypes.number.isRequired,
  pic: PropTypes.string,
  defaultPic: PropTypes.string
}

export default Avatar
