import React, {Component} from 'react'

class PhotoWallCover extends Component {
  render() {
    const {images} = this.props
    const count = images.length
    switch (count) {
      case 0:
        return (
          <div className="photo__main">
            <div className="photo__col">
              <div className="photo__img photo__img--tl" />
              <div className="photo__line" />
              <div className="photo__img photo__img--bl" />
            </div>
            <div className="photo__col photo__col--line">
              <div className="photo__img" />
              <div className="photo__line" />
              <div className="photo__img" />
            </div>
            <div className="photo__col">
              <div className="photo__img photo__img--two photo__img--tr" />
              <div className="photo__line" />
              <div className="photo__img photo__img--one photo__img--br" />
            </div>
          </div>
        )
        break;
      case 1:
        return (
          <div className="photo__main">
            <div className="photo__col">
              <div className="photo__img photo__img--tl" style={{backgroundImage: `url(${images[0].url})`}} />
              <div className="photo__line" />
              <div className="photo__img photo__img--bl" />
            </div>
            <div className="photo__col photo__col--line">
              <div className="photo__img" />
              <div className="photo__line" />
              <div className="photo__img" />
            </div>
            <div className="photo__col">
              <div className="photo__img photo__img--two photo__img--tr" />
              <div className="photo__line" />
              <div className="photo__img photo__img--one photo__img--br" />
            </div>
          </div>
        )
        break;
      case 2:
        return (
          <div className="photo__main">
            <div className="photo__col">
              <div className="photo__img photo__img--tl" style={{backgroundImage: `url(${images[0].url})`}} />
              <div className="photo__line" />
              <div className="photo__img photo__img--bl" style={{backgroundImage: `url(${images[1].url})`}} />
            </div>
            <div className="photo__col photo__col--line">
              <div className="photo__img" />
              <div className="photo__line" />
              <div className="photo__img" />
            </div>
            <div className="photo__col">
              <div className="photo__img photo__img--two photo__img--tr" />
              <div className="photo__line" />
              <div className="photo__img photo__img--one photo__img--br" />
            </div>
          </div>
        )
        break;
      case 3:
        return (
          <div className="photo__main">
            <div className="photo__col">
              <div className="photo__img photo__img--tl" style={{backgroundImage: `url(${images[0].url})`}} />
              <div className="photo__line" />
              <div className="photo__img photo__img--bl" style={{backgroundImage: `url(${images[1].url})`}} />
            </div>
            <div className="photo__col photo__col--line">
              <div className="photo__img" style={{backgroundImage: `url(${images[2].url})`}} />
              <div className="photo__line" />
              <div className="photo__img" />
            </div>
            <div className="photo__col">
              <div className="photo__img photo__img--two photo__img--tr" />
              <div className="photo__line" />
              <div className="photo__img photo__img--one photo__img--br" />
            </div>
          </div>
        )
        break;
      case 4:
        return (
          <div className="photo__main">
            <div className="photo__col">
              <div className="photo__img photo__img--tl" style={{backgroundImage: `url(${images[0].url})`}} />
              <div className="photo__line" />
              <div className="photo__img photo__img--bl" style={{backgroundImage: `url(${images[1].url})`}} />
            </div>
            <div className="photo__col photo__col--line">
              <div className="photo__img" style={{backgroundImage: `url(${images[2].url})`}} />
              <div className="photo__line" />
              <div className="photo__img" style={{backgroundImage: `url(${images[3].url})`}} />
            </div>
            <div className="photo__col">
              <div className="photo__img photo__img--two photo__img--tr" />
              <div className="photo__line" />
              <div className="photo__img photo__img--one photo__img--br" />
            </div>
          </div>
        )
        break;
      case 5:
        return (
          <div className="photo__main">
            <div className="photo__col">
              <div className="photo__img photo__img--tl" style={{backgroundImage: `url(${images[0].url})`}} />
              <div className="photo__line" />
              <div className="photo__img photo__img--bl" style={{backgroundImage: `url(${images[1].url})`}} />
            </div>
            <div className="photo__col photo__col--line">
              <div className="photo__img" style={{backgroundImage: `url(${images[2].url})`}} />
              <div className="photo__line" />
              <div className="photo__img" style={{backgroundImage: `url(${images[3].url})`}} />
            </div>
            <div className="photo__col">
              <div className="photo__img photo__img--two photo__img--tr" style={{backgroundImage: `url(${images[4].url})`}} />
              <div className="photo__line" />
              <div className="photo__img photo__img--one photo__img--br" />
            </div>
          </div>
        )
        break;
      default:
        return (
          <div className="photo__main">
            <div className="photo__col">
              <div className="photo__img photo__img--tl" style={{backgroundImage: `url(${images[0].url})`}} />
              <div className="photo__line" />
              <div className="photo__img photo__img--bl" style={{backgroundImage: `url(${images[1].url})`}} />
            </div>
            <div className="photo__col photo__col--line">
              <div className="photo__img" style={{backgroundImage: `url(${images[2].url})`}} />
              <div className="photo__line" />
              <div className="photo__img" style={{backgroundImage: `url(${images[3].url})`}} />
            </div>
            <div className="photo__col">
              <div className="photo__img photo__img--two photo__img--tr" style={{backgroundImage: `url(${images[4].url})`}} />
              <div className="photo__line" />
              <div className="photo__img photo__img--one photo__img--br" style={{backgroundImage: `url(${images[5].url})`}} />
            </div>
          </div>
        )
        break;
    }
  }
}

export default PhotoWallCover