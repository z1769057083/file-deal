import React, {PropTypes} from 'react'
import Avatar from 'components/Avatar'

class WorksFrom extends React.Component {
  render() {
    const {data} = this.props
    if (!data.alt) {
      return null
    }
    return (
      <div className="from flexbox">
        <div className="left-side flexbox">
          <div className="side__avatar">
            <Avatar pic={data.sourcePic} width={36} />
          </div>
          <div className="side__other">
            <div className="text1">转自</div>
            <div className="name">
              {data.sourceName}
            </div>
          </div>
        </div>
        <a className="more" href={data.sourceUrl} target="_blank">
          Visit it
        </a>
      </div>
    )
  }
}

WorksFrom.propTypes = {
  data: PropTypes.object.isRequired
}

export default WorksFrom