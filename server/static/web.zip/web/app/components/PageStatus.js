import React, { Component, PropTypes } from 'react'
import { connect } from 'react-redux'

class PageStatus extends Component {
  render() {
    const {status, height, globalInit} = this.props
    if (status === 'default') {
      return null
    }
    if (status === 'empty') {
      return <div className="m-page-status" style={{height: height || 'auto'}}>
        <div className="empty">
          空 <br/> 诶 <br/> <span className="icon icon-slash"></span>
        </div>
      </div>
    }
    return (
      <div className="m-page-status" style={{height: height || 'auto'}}>
        {
          status === 'isEnd' ?
          <div className="icon icon-end"></div>:
          (
            globalInit ? <div className="icon icon-loading"></div> : null
          )
        }
      </div>
    )
  }
}

PageStatus.propTypes = {
  status: PropTypes.oneOf(['loading', 'isEnd', 'default', 'empty']),
  height: PropTypes.number
}

function mapStateToProps(state) {
  return {
    globalInit: state.global.get('init')
  }
}

export default connect(mapStateToProps)(PageStatus)

