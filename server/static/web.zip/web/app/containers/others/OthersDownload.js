import React, { Component, PropTypes } from 'react'
import { connect } from 'react-redux'
import Download from 'components/Download'

class OthersDownload extends Component {
  render() {
    return (
      <div className="m-others-download">
        <Download />
      </div>
    )
  }
}

function mapStateToProps (state) {
  return {}
}

OthersDownload.propTypes = {

}

export default connect(mapStateToProps)(OthersDownload)
