import React, { Component, PropTypes } from 'react'
import {Link} from 'react-router'

class AuthCover extends Component {
  constructor(props, context) {
    super(props, context)
    this.handleLogin = this.handleLogin.bind(this)
  }
  handleLogin() {
    this.props.closeAuthModal()
  }
  render() {
    return (
      <div className="m-auth-cover">
        <div className="close__wrap">
          <div className="close icon icon-close-black"
               onClick={this.props.closeAuthModal}></div>
        </div>
        <div className="logo__wrap">
          <div className="logo__title">AirOases</div>
          <div className="logo__subtitle">
            <div className="title__inner">空中绿洲</div>
          </div>
        </div>
        {this.props.children}
        <div className="footer__wrap">
          <div className="footer__text">{`{发现 `}<b>/</b>{` 新坐标}`}</div>
        </div>
      </div>
    )
  }
}

AuthCover.propTypes = {
  closeAuthModal: PropTypes.func
}
AuthCover.defaultProps = {
  closeAuthModal: () => {}
}

export default AuthCover
