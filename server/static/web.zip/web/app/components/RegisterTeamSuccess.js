import React, { Component, PropTypes } from 'react'
import AuthSingleCard from 'components/AuthSingleCard'
import { connect } from 'react-redux'
import {
  REGISTER_TEAM
} from 'config/authPage'

const COUNT_DOWN_SECONDS = 60
class RegisterTeamSuccess extends Component {
  constructor(props) {
    super(props)
    this.state = {
      seconds: COUNT_DOWN_SECONDS,
      interval: null
    }
    this.prevPage = this.prevPage.bind(this)
  }
  componentDidMount() {
    this.countDown()
  }
  countDown() {
    this.state.interval = setInterval(() => {
      const seconds = this.state.seconds - 1
      if (seconds >= 0) {
        this.setState({
          seconds: this.state.seconds - 1
        })
      } else {
        clearInterval(this.state.interval)
      }
    }, 1000)
  }
  prevPage() {
    this.props.switchPage(REGISTER_TEAM)
  }
  componentDidUnMount() {
    clearInterval(this.state.interval)
  }
  render() {
    const {seconds} = this.state
    const email = this.props.register.get('teamEmail')
    return (
      <AuthSingleCard closeAuthModal={this.props.closeAuthModal}>
        <div className="card-main register-user">
          <div className="header">注册</div>
          <div className="main">
            <p className="input">
              <input type="text" className="m-text" defaultValue={email} />
            </p>
            {
              (() => {
                if (seconds > 0) {
                  return (
                    <p className="p1">
                      已发送验证链接至您邮箱， <br/>
                      请登录邮箱激活。
                    </p>
                  )
                } else {
                  return (
                    <div className="wrapper">
                      <p className="p1">
                        未收到邮件？<br/>点击下方按钮回上一步重新发送邮件
                      </p>
                    </div>
                  )
                }
              })()
            }
          </div>
          <div className="footer flexbox single-button">
            {
              seconds <= 0 && <div className="btn btn-primary" onClick={this.prevPage}>上一步</div>
            }
          </div>
        </div>
      </AuthSingleCard>
    )
  }
}

RegisterTeamSuccess.propTypes = {
  switchPage: PropTypes.func,
}

function mapStateToProps(state) {
  return {register: state.register}
}

export default connect(mapStateToProps)(RegisterTeamSuccess)