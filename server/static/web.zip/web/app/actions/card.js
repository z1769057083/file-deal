import { CALL_API, CHAIN_API } from 'middleware/api'

export const LOADED_CARDS = Symbol('LOADED_CARDS')
//获取手贴列表
/**
 * @param query {sortid: 123}
 */
export function loadCards(query, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'get',
      path: '/api/v1/open/article/listforwardart',
      query,
      successType: LOADED_CARDS,
      afterSuccess,
      afterError
    }
  }
}

export const LOAD_FIRST_PAGE_CARDS = Symbol('LOAD_FIRST_PAGE_CARDS')
export function loadFirstPageCards(afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'get',
      path: '/api/v1/open/popular/home',
      successType: LOAD_FIRST_PAGE_CARDS,
      afterSuccess,
      afterError
    }
  }
}

export const LOADED_RELATED_CARDS = Symbol('LOADED_RELATED_CARDS')
/**
 * 获取手贴相关列表
 * @param query.artid 文章id
 * @param query.arttype 文章类型： 0：手帖；1：有料；2：云库
 * @param query.sortid 最后记录的排序id，如果是第一次请求或请求当前最新数据使用-1，否做使用服务端返回的lastSortId。
 如果不传该参数，默认值为-1
 * @returns {{}}
 */
export function loadRelatedCards(query, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'get',
      path: '/api/v1/open/article/loadrelatedartlist',
      query,
      successType: LOADED_RELATED_CARDS,
      afterSuccess,
      afterError,
    }
  }
}

/**
 * @param query
 * {articleId, sortId}
 */
export function loadRelatedCards2(query, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'get',
      path: '/api/v1/open/article/recommend',
      query,
      successType: LOADED_RELATED_CARDS,
      afterSuccess,
      afterError,
    }
  }
}

// TODO
//获取单篇手贴的详情
export function loadCard(id, afterSuccess) {
  return {
    [CALL_API]: {
      method: 'get',
      path: '/api/v1/open/article/',
      query: {id},
      afterSuccess
    }
  }
}

//有料
export const LOAD_PRO_ARTS_SUCCESS = Symbol('LOAD_PRO_ARTS_SUCCESS')
export function loadProArts(query, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'get',
      path: '/api/v1/open/article/loadproartlistfromweb',
      query,
      successType: LOAD_PRO_ARTS_SUCCESS,
      afterSuccess,
      afterError
    }
  }
}

//云库
export const LOAD_ORG_ARTS_SUCCESS = Symbol('LOAD_ORG_ARTS_SUCCESS')
/**
 * @param query.sortid
 */
export function loadOrgArts(query) {
  return {
    [CALL_API]: {
      method: 'get',
      path: '/api/v1/open/article/loadorgartlistfromweb',
      query,
      successType: LOAD_ORG_ARTS_SUCCESS
    }
  }
}

export const LOAD_ARTICLE_DETAIL_SUCCESS = Symbol('LOAD_ARTICLE_DETAIL_SUCCESS')
export function loadArticleDetail(artid, arttype, afterSuccess) {
  return {
    [CALL_API]: {
      method: 'get',
      path: '/api/v1/open/article/artdetail',
      query: {
        artid,
        arttype
      },
      successType: LOAD_ARTICLE_DETAIL_SUCCESS,
      afterSuccess
    }
  }
}

/**
 * actions about whether a card shows in a modal or directly on the body
 */
export const UPDATE_CARD_MODE = Symbol('UPDATE_CARD_MODE')
/**
 * @param params {inModal: true, contextCards: [], returnTo: '/'}
 */
export function updateCardMode(params) {
  return {
    type: UPDATE_CARD_MODE,
    params
  }
}

export const LOAD_PRO_ART_BY_AUTHOR_ID = Symbol('LOAD_PRO_ART_BY_AUTHOR_ID')
export function loadProArtByAuthorId(query) {
  return {
    [CALL_API]: {
      method: 'get',
      path: '/api/v1/open/article/loadproartbyauthorid',
      query: {
        authorid: query.authorId,
        sortid: query.sortId,
        type: 'webpro'
      },
      successType: LOAD_PRO_ART_BY_AUTHOR_ID,
    }
  }
}


export const COMMUNITY_SLIDE_PREV = Symbol('COMMUNITY_SLIDE_PREV')
export function prevSlideOfCommunitySlide(index) {
  return {
    type: COMMUNITY_SLIDE_PREV,
    index
  }
}

export const COMMUNITY_SLIDE_NEXT = Symbol('COMMUNITY_SLIDE_NEXT')
export function nextSlideOfCommunitySlide(index) {
  return {
    type: COMMUNITY_SLIDE_NEXT,
    index
  }
}

export const ART_OPERATION_SUCCESS = Symbol('ART_OPERATION_SUCCESS')
/**
 * 文章操作，大爱、收藏
 * @param artId 文章id
 * @param artType 文章类型：0：手帖；1：有料；2：云库
 * @param optType 操作类型：0：大爱；1：收藏
 * @param optValue 操作内容：0：取消；1：有操作
 */
function artOperation(params) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/articles/love',
      body: {
        articleId: params.artId,
        // artType: params.artType,
        // optType: params.optType,
        // optValue: params.optValue
      },
      successType: ART_OPERATION_SUCCESS,
      afterSuccess: params.afterSuccess,
      afterError: params.afterError,
    }
  }
}

export function collectCard(id, type, afterSuccess, afterError) {
  return artOperation({
    artId: id,
    artType: type,
    optType: 1,
    optValue: 1,
    afterSuccess,
    afterError,
  })
}

export function unCollectCard(id, type, afterSuccess, afterError) {
  return artOperation({
    artId: id,
    artType: type,
    optType: 1,
    optValue: 0,
    afterSuccess,
    afterError,
  })
}

export function likeCard(id, type, afterSuccess, afterError) {
  return artOperation({
    artId: id,
    artType: type,
    optType: 0,
    optValue: 1,
    afterSuccess,
    afterError,
  })
}

export function unLikeCard(id, type, afterSuccess, afterError) {
  return artOperation({
    artId: id,
    artType: type,
    optType: 0,
    optValue: 0,
    afterSuccess,
    afterError,
  })
}

export const LOAD_NEXT_PAGE_CARDS = Symbol('LOAD_NEXT_PAGE_CARDS')
// 卡片详情页翻页
export function loadNextPageCards(path, query, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'get',
      path,
      query,
      successType: LOAD_NEXT_PAGE_CARDS,
      afterSuccess,
      afterError
    }
  }
}

export const UPDATE_CARD_LIKE = Symbol('UPDATE_CARD_LIKE')
/**
 * @param isLike
 */
export function updateCardLike(id, isLike) {
  return {
    type: UPDATE_CARD_LIKE,
    id,
    isLike
  }
}

export const UPDATE_CARD_TREAD = Symbol('UPDATE_CARD_TREAD')
/**
 * @param isTread
 */
export function updateCardTread(id, isTread) {
  return {
    type: UPDATE_CARD_TREAD,
    id,
    isTread
  }
}