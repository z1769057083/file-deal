/**
 * Created by xijinling on 2017/8/24.
 */
import React, { Component, PropTypes } from 'react'
import { connect } from 'react-redux'

class Feedback extends Component {
  render() {
    return <div className="m-others-feedback">
      <div className="feedback__img"></div>
      <div className="feedback__text">
        <span>如有意见、建议、投诉等，请发邮件至「空中绿洲」客服邮箱 </span>
        <a href="mailto:service@airoases.com">service@airoases.com</a>
      </div>
    </div>
  }
}

function mapStateToProps (state) {
  return {}
}

export default connect(mapStateToProps)(Feedback)