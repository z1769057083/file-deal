import React, {Component, PropTypes} from 'react'
import {connect} from 'react-redux'
import {bindActionCreators} from 'redux'
import Waterfall from 'components/Waterfall'
import TopicPhotoList from 'components/TopicPhotoList'

class UserWorks extends Component {
  render() {
    const {user, location, auth, params} = this.props
    const cards = user.get('articleList')
    const userType = user.getIn(['userInfo', 'userType'])
    // userType == '2'表示团体用户
    const type = userType == '2' ? 2 : 1
    const isSelf =
      params.oasisId == auth.get('code') || params.id == auth.get('id');
      console.log('cards.size',cards)
    return cards.size > 0
      ? <Waterfall
          cards={cards}
          type={type}
          canEdit={isSelf}
          column={3}
          location={location}
        />
      : <TopicPhotoList />
  }
}

function mapStateToProps(state) {
  return {
    cards: state.cards,
    user: state.user,
    auth: state.auth
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({}, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(UserWorks)
