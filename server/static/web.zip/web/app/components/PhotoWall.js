import React, {Component, PropTypes} from 'react'
import {Link} from 'react-router'
import {connect} from 'react-redux'
import {bindActionCreators} from 'redux'
import PhotoWallCover from 'components/PhotoWallCover'
import * as subjectActions from 'actions/subject'
import * as globalActions from 'actions/global'

class PhotoWall extends Component {
  showLoginToast = () => {
    const {globalActions} = this.props
    globalActions.addToast({
      type: 'singleMsg',
      message: '请先登录',
      timeout: 2000
    })
  }
  
  openSubjectModal = () => {
    const {actions, auth, subject, globalActions} = this.props
    if (!auth.get('id')) {
      return this.showLoginToast()
    }
    
    // check pro
    if (auth.get('userType') === '0') {
      return globalActions.showUpgradeTips()
    }
    
    const classInit = subject.get('classInit')
    if (!classInit) {
      actions.getFirstClass()
    }
    actions.resetSubject()
    actions.openSubjectWindow()
  }
  
  renderCreate() {
    return (
      <div className="card__wrap" onClick={this.openSubjectModal}>
        <div className="photo__wrap">
          <div className="photo__main photo__main--add">
            <div className="photo__add">
              <div className="icon icon-add-white" />
            </div>
            <div className="photo__text">创建主题</div>
          </div>
        </div>
      </div>
    )
  }

  renderPhotoWall() {
    const {data, userId} = this.props
    return (
      <div className="card__wrap">
        <a href={`/topic/${data.id}?curr_id=${userId}`} className="photo__wrap">
          <PhotoWallCover images={data.images}/>
        </a>

        <div className="desc__wrap">
          <div className="desc__title">
            {data.name}
          </div>
          <div className="desc__time">
            {data.time}
          </div>
        </div>
      </div>
    )
  }

  render() {
    const {isCreate} = this.props
    return isCreate ? this.renderCreate() : this.renderPhotoWall()
  }
}

PhotoWall.propTypes = {
  isCreate: PropTypes.bool
}

const mapStateToProps = state => ({
  subject: state.subject,
  auth: state.auth,
  userId: state.auth.get('id')
})

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators(subjectActions, dispatch),
  globalActions: bindActionCreators(globalActions, dispatch)
})

export default connect(mapStateToProps, mapDispatchToProps)(PhotoWall)
