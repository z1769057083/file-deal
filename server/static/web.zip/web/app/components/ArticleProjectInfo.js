import React, {Component, PropTypes} from 'react'
import {fromJS} from 'immutable'
import _ from 'lodash'

class ArticleProjectInfo extends Component {
  _onChangeKey(key, value) {
    const data = this.props.data
    data[key].pcode = value
    data[key].pname = _.find(this.props.options, item => item.key == value)['value']
    this.props.onChange('projectInfo', fromJS(data))
  }
  _onChangeValue(key, value) {
    const data = this.props.data
    data[key].pvalue = value
    this.props.onChange('projectInfo', fromJS(data))
  }
  _onDelete(index) {
    const data = this.props.data
    data.splice(index, 1)
    this.props.onChange('projectInfo', fromJS(data))
  }
  _onAdd() {
    const data = this.props.data
    data.push({pcode: this.props.options[0].key, pname: this.props.options[0].value, pvalue: ''})
    this.props.onChange('projectInfo', fromJS(data))
  }
  render() {
    return (
      <div className="article-project-info">
        {
          this.props.data.map((item, key) => {
            return (
              <div className="m-works-item" key={key}>
                <div className="name">
                  <select value={item.pcode} className="m-text"
                    onChange={(e) => this._onChangeKey(key, e.target.value)}>
                    {
                      this.props.options.map((item2, key2) => {
                        return (
                          <option value={item2.key} key={key2}>{item2.value}</option>
                        )
                      })
                    }
                  </select>
                </div>
                <div className="value">
                  <input type="text" className="m-text"
                         onChange={(e) => this._onChangeValue(key, e.target.value)} value={item.pvalue} />
                </div>
                {key > 0 ?
                  <div className="action">
                    <div className="icon icon-delete" onClick={this._onDelete.bind(this, key)}></div>
                  </div>: null
                }
              </div>
            )
          })
        }
        <div className="icon icon-plus" onClick={this._onAdd.bind(this)}></div>
      </div>
    )
  }
}

ArticleProjectInfo.propTypes = {
  data: PropTypes.array.isRequired,
  onChange: PropTypes.func.isRequired
}

export default ArticleProjectInfo