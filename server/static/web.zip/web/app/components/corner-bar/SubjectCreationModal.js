import React from 'react'
import Modal from 'react-modal'
import SubjectCreation from './SubjectCreation'
import {bindActionCreators} from 'redux'
import {connect} from 'react-redux'
import * as subjectActions from 'actions/subject'
import * as globalActions from 'actions/global'

const customStyles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    overflow: 'scroll',
    zIndex: 200
  },
  content: {
    border: 'none',
    padding: '0px 0 20px 0',
    position: 'relative',
    borderRadius: '6px'
  }
}
class SubjectCreationModal extends React.Component {
  componentWillReceiveProps(props) {
    const isOpen = props.subject.get('modalIsOpen')
    const prevIsOpen = this.props.subject.get('modalIsOpen')
    if (!isOpen && prevIsOpen) {
      document.body.classList.remove('modal-is-open')
    } else if (isOpen && !prevIsOpen) {
      document.body.classList.add('modal-is-open')
    }
  }

  afterOpenModal = () => {
    document.querySelector('.ReactModal__Overlay').scrollTop = 0
  }

  render() {
    const {subject, actions} = this.props
    const data = subject.get('subject').toJS()
    return (
      <Modal
        isOpen={subject.get('modalIsOpen')}
        onRequestClose={actions.closeSubjectWindow}
        onAfterOpen={this.afterOpenModal}
        style={customStyles}
        overlayClassName="modal-new-pin"
        contentLabel="Modal">
        <div className="header">
          <div className="title">
            {data.id ? '编辑' : '创建'}主题
          </div>
          <div
            className="icon icon-close-white"
            onClick={actions.closeSubjectWindow}
          />
        </div>
        <div className="main">
          <div className="m-subject-creation">
            <SubjectCreation/>
          </div>
        </div>
        <div className="footer" />
      </Modal>
    )
  }
}

const mapStateToProps = state => ({
  subject: state.subject,
  auth: state.auth
})

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators(subjectActions, dispatch),
  globalActions: bindActionCreators(globalActions, dispatch)
})

export default connect(mapStateToProps, mapDispatchToProps)(
  SubjectCreationModal
)
