import React, { Component, PropTypes } from 'react'
import AuthSingleCard from 'components/AuthSingleCard'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import {
  PRO_APPLY
} from 'config/authPage'
import classNames from 'classnames'
import * as authActions from 'actions/auth'
import * as globalActions from 'actions/global'
import * as articleActions from 'actions/article'
import Avatar from 'components/Avatar'
import BirthInput from 'components/forms/BirthInput'
import PhoneInput from 'components/forms/PhoneInput'
import _ from 'lodash'
import {
  Form,
  Input,
  Button,
  Select,
  Textarea
} from 'react-validation/lib/build/validation.rc'
import {SubmitDecorator} from 'decorators'

class ProApply extends Component {
  constructor(props, context) {
    super(props, context)
    this.state = {
      step: 1,
      payload: {
        name: '',
        birthday: '',
        gender: '0',
        location: '',

        focus: '',
        sign: '',
        occupation: '',
        workorg: '',
        pic: '',
      },
      applied: false
    }
    this.toStep2 = this.toStep2.bind(this)
    this.toStep3 = this.toStep3.bind(this)
    this.onSubmit = this.onSubmit.bind(this)
    this.handleBirthdayInput = this.handleBirthdayInput.bind(this)
    this.updateAvatar = this.updateAvatar.bind(this)
    this.prev = this.prev.bind(this)
  }

  handleInput(key, value) {
    this.state.payload[key] = value
    this.forceUpdate()
  }

  handleValidateInput(key, e) {
    this.state.payload[key] = e.target.value
    this.forceUpdate()
  }

  handleBirthdayInput(value) {
    this.state.payload['birthday'] = value
    this.forceUpdate()
  }

  prev() {
    this.setState({
      step: this.state.step - 1
    })
  }

  toStep2(event) {
    event.preventDefault()
    this.setState({
      step: 2
    })
  }

  toStep3(event) {
    event.preventDefault()
    this.setState({step: 3})
  }

  onSubmit(event) {
    event.preventDefault()
    const payload = this.state.payload
    this.props.actions.applyPro(payload, () => {
      this.setState({
        step: 4
      })
    }, (state) => {
      this.props.showError(state.message || '申请失败')
    })
  }

  updateAvatar(event) {
    const name = 'picFile'
    const formData = new FormData()
    formData.append(name, event.target.files[0])
    this.props.actions.uploadImg(formData, (state) => {
      const {fileName} = state.response.data
      this.handleInput('pic', fileName)
    })
  }

  renderStep1() {
    const {step} = this.state
    return (
      <Form className="card-main pro-apply modal-form"
        ref={c => {this.form = c}}
        onSubmit={this.toStep2}
        >
        <div className="header">PRO验证 ({step}/3步)</div>
        <div className="main">
          <div className="step-1">
            <div className="input">
              <input type="text" className="m-text"
                     readOnly
                     value="建筑设计"
                     placeholder="分类"/>
            </div>
            <Input type="text"
              name="name"
              className="m-text"
              containerClassName="input field-wrapper"
              errorClassName="error"
              onChange={this.handleValidateInput.bind(this, 'name')}
              value={this.state.payload.name}
              validations={['required']}
              placeholder="姓名"
            />
            <BirthInput
              name="birthday"
              className="m-text"
              containerClassName="input field-wrapper"
              errorClassName="error"
              onChange={this.handleBirthdayInput}
              value={this.state.payload.birthday}
              validations={['required', 'date']}
              placeholder="1990/01/01"
            />
            <Select
              name="gender"
              className="m-text"
              containerClassName="input field-wrapper"
              errorClassName="error"
              onChange={this.handleValidateInput.bind(this, 'gender')}
              value={this.state.payload.gender}
              validations={['gender']}
              >
              <option value="0">男</option>
              <option value="1">女</option>
            </Select>
          </div>
        </div>
        <div className={classNames("footer flexbox", {'single-button': true})}>
          <Button type="submit" className="btn">
            下一步
          </Button>
        </div>
      </Form>
    )
  }

  renderStep2() {
    const {step} = this.state
    return (
      <Form className="card-main pro-apply modal-form"
        ref={c => {this.form = c}}
        onSubmit={this.toStep3}
        >
        <div className="header">PRO验证 ({step}/3步)</div>
        <div className="main">
          <div className="step-2">
            <Input type="text"
                   name="location"
                   className="m-text"
                   containerClassName="input field-wrapper"
                   errorClassName="error"
                   onChange={this.handleValidateInput.bind(this, 'location')}
                   value={this.state.payload.location}
                   validations={['required']}
                   placeholder="地点"
              />
            <Input type="text"
              name="occupation"
              className="m-text"
              containerClassName="input field-wrapper"
              errorClassName="error"
              onChange={this.handleValidateInput.bind(this, 'occupation')}
              value={this.state.payload.occupation}
              validations={['required']}
              placeholder="职业"
            />
            <Input type="text"
              name="workorg"
              className="m-text"
              containerClassName="input field-wrapper"
              errorClassName="error"
              onChange={this.handleValidateInput.bind(this, 'workorg')}
              value={this.state.payload.workorg}
              validations={['required']}
              placeholder="供职团体全称"
            />
          </div>
        </div>
        <div className={classNames("footer flexbox field-wrapper btn-footer", {'single-button': false})}>
          <div className="btn" onClick={this.prev.bind(this)}>
            上一步
          </div>
          <Button type="submit" className="btn btn-primary">下一步</Button>
          {this.props.error && <div className="form-error active">{this.props.error}</div>}
        </div>
      </Form>
    )
  }

  renderStep3() {
    const {step} = this.state
    return (
      <Form className="card-main pro-apply modal-form"
            ref={c => {this.form = c}}
            onSubmit={this.onSubmit}
        >
        <div className="header">PRO验证 ({step}/3步)</div>
        <div className="main">
          <div className="step-2">
            <Textarea type="text"
                   name="focus"
                   className="m-text"
                   containerClassName="input field-wrapper"
                   errorClassName="error"
                   onChange={this.handleValidateInput.bind(this, 'focus')}
                   value={this.state.payload.focus}
                   validations={['required']}
                   placeholder="专注"
              />
            <Textarea type="text"
                   name="sign"
                   className="m-text"
                   containerClassName="input field-wrapper"
                   errorClassName="error"
                   onChange={this.handleValidateInput.bind(this, 'sign')}
                   value={this.state.payload.sign}
                   validations={['required']}
                   placeholder="签名"
              />
            <div className="m-change-avatar flexbox">
              <Avatar pic={this.state.payload.pic} defaultPic="/assets/images/default_avatar.svg" width={45} />
              <div className="action">
                <input type="file" name="userPic"
                       id="avatar-file"
                       style={{display: 'none'}}
                       onChange={this.updateAvatar} />

                <label htmlFor="avatar-file">上传真实头像</label>
              </div>
            </div>
          </div>
        </div>
        <div className={classNames("footer flexbox field-wrapper btn-footer", {'single-button': false})}>
          <div className="btn" onClick={this.prev.bind(this)}>
            上一步
          </div>
          <Button type="submit" className="btn btn-primary">提交</Button>
          {this.props.error && <div className="form-error active">{this.props.error}</div>}
        </div>
      </Form>
    )
  }

  renderStep4() {
    const phone = this.props.auth.get('regPhone')
    return (
      <div className="card-main pro-apply">
        <div className="header">PRO用户验证</div>
        <div className="main">
          <div className="pro-apply-success">
            <p className="account">
              <PhoneInput className="m-text read-only"
                          readOnly={true}
                          onChange={() => {}}
                          value={phone || ''}
                          placeholder=""
                />
            </p>
            <div className="p3">
              <span className="icon icon-success"></span>
            </div>
            <div className="p4">
              <div className="p5">个人实名验证审核启动！</div>
              <div className="p6">3-5个工作日通过短信和邮件回复。</div>
            </div>
          </div>
        </div>
        <div className={classNames("footer flexbox", {'single-button': true})}>
          <a href="/" className="btn btn-primary">首页</a>
        </div>
      </div>
    )
  }

  render() {
    return (
      <AuthSingleCard closeAuthModal={this.props.closeAuthModal}>
        {this.state.step == 1 ? this.renderStep1() : null}
        {this.state.step == 2 ? this.renderStep2() : null}
        {this.state.step == 3 ? this.renderStep3() : null}
        {this.state.step == 4 ? this.renderStep4() : null}
      </AuthSingleCard>
    )
  }
}

function mapStateToProps(state) {
  return {
    auth: state.auth
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      applyPro: authActions.applyPro,
      addToast: globalActions.addToast,
      uploadImg: articleActions.uploadImg,
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(
  SubmitDecorator(ProApply)
)
