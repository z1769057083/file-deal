/**
 * 个人中心 - 修改 - 帐户
 */

import React, {Component, PropTypes} from 'react'
import {connect} from 'react-redux'
import {bindActionCreators} from 'redux'
import Modal from 'react-modal'
import ChangePassword from 'components/ChangePassword'
import * as authActions from 'actions/auth'
import * as globalActions from 'actions/global'
import PhoneInput from 'components/forms/PhoneInput'
import IdEditor from 'components/profile/IdEditor'
import modalStyle from 'components/style/modal'
import BirthInput from 'components/forms/BirthInput'
import CountedTextarea from 'components/forms/CountedTextarea'
import {Form, Input, Button} from 'react-validation/lib/build/validation.rc'
import Select from 'react-select'

class ProfileAccount extends Component {
  constructor(props) {
    super(props)
    this.state = {
      isOpen: false,
      user: this.props.auth.toJS()
    }
    this.avatarSuccess = this.avatarSuccess.bind(this)
    this.handleSubmit = this.handleSubmit.bind(this)
  }
  openModal() {
    this.setState({isOpen: true})
  }
  closeModal() {
    this.setState({isOpen: false})
  }
  avatarSuccess() {
    this.props.actions.addToast({
      type: 'black',
      message: '头像修改成功',
      pic: this.props.avatar,
      timeout: 3000
    })
  }
  onChange(key, value) {
    let result = value
    if (key === 'gender') {
      result = value.value
    }
    this.state.user[key] = result
    this.forceUpdate()
  }
  updateAvatar(event) {
    const name = 'userPic'
    const formData = new FormData()
    formData.append(name, event.target.files[0])
    this.props.actions.updateAvatar(formData, this.avatarSuccess)
  }
  
  canBeSave() {
    const {user} = this.state
    const isTeam = user.userType === '2'
    if (isTeam) {
      return !!user.userDesc && !!user.focus && !!user.location
    }
    return true
  }

  saveSuccess() {
    this.props.actions.addToast({
      type: 'singleMsg',
      message: '保存成功',
      timeout: 2000
    })
  }
  saveFailure() {
    this.props.actions.addToast({
      type: 'singleMsg',
      message: '保存失败',
      timeout: 2000
    })
  }

  handleSubmit(e) {
    e.preventDefault()
    const {user} = this.state
    let payload = {
      nickname: user.nickName,
      gender: user.gender || '',
      location: user.location,
      birthday: user.birthday,
      userDesc: user.userDesc,
      email: user.email
    }
    if (user.userType === '2') {
      payload.phone = user.phone || ''
      payload.name = user.name || ''
      payload.focus = user.focus || ''
    }
    this.props.actions.updateBaseInfo(
      payload,
      this.saveSuccess.bind(this),
      this.saveFailure.bind(this)
    )
  }

  render() {
    const {user} = this.state
    const canEdit = user.modifiedOasisCode !== '1'
    const avatar = this.props.avatar || user.pic || '/assets/images/default_avatar.svg'
    const isTeam = user.userType === '2'
    const isCommonUser = !isTeam

    const avatarStyle = {
      backgroundImage: `url(${avatar})`
    }
    return (
      <Form
        className="m-form-base m-profile-account"
        ref={c => {
          this.form = c
        }}
        onSubmit={this.handleSubmit.bind(this)}>
        <div className="row">
          <div className="col-1">头像</div>
          <div className="col-2">
            <div className="change-avatar flexbox">
              <label className="avatar" htmlFor="avatar-file">
                <div className="inner" style={avatarStyle} />
                <span className="icon icon-camera" />
              </label>
              <input
                type="file"
                name="userPic"
                id="avatar-file"
                style={{display: 'none'}}
                onChange={this.updateAvatar.bind(this)}
              />
            </div>
          </div>
        </div>
        {isTeam &&
          <div className="row">
            <div className="col-1">邮箱</div>
            <div className="col-2">
              <div className="col-1">
                {user.email}
              </div>
            </div>
          </div>}
        {isTeam &&
          <div className="row">
            <div className="col-1">关于我</div>
            <div className="col-2">
              <CountedTextarea
                placeholder="简单介绍自己"
                className="m-text"
                maxLength={50}
                value={user.userDesc || ''}
                onChange={event => this.onChange('userDesc', event.target.value)}
              />
              <div className="field-tips">*必须填写</div>
            </div>
          </div>}
        {isTeam &&
          <div className="row">
            <div className="col-1">专注于</div>
            <div className="col-2">
              <CountedTextarea
                placeholder="填写专注的领域信息"
                className="m-text"
                maxLength={50}
                value={user.focus || ''}
                onChange={event => this.onChange('focus', event.target.value)}
              />
              <div className="field-tips">*必须填写</div>
            </div>
          </div>}
        {isTeam &&
          <div className="row">
            <div className="col-1">姓名</div>
            <div className="col-2">
              <Input
                type="text"
                name="nickName"
                className="m-text"
                value={user.name}
                validations={[]}
                placeholder="真实姓名"
                onChange={e => this.onChange('name', e.target.value)}
              />
              <div className="field-tips">INDI账号需要提供真是姓名</div>
            </div>
          </div>}
        <div className="row">
          <div className="col-1">地点</div>
          <div className="col-2">
            <input
              type="text"
              className="m-text"
              value={user.location || ''}
              maxLength="18"
              placeholder="所在城市"
              onChange={event => this.onChange('location', event.target.value)}
            />
            {isTeam && <div className="field-tips">*必须填写</div>}
          </div>
        </div>
        {isTeam && <div className="line" />}
        {isTeam &&
          <div className="row">
            <div className="col-1">手机</div>
            <div className="col-2 v-center">
              <PhoneInput
                className="m-text read-only"
                readOnly={true}
                onChange={() => {}}
                value={user.phone || ''}
                placeholder=""
              />
            </div>
          </div>}

        {isCommonUser &&
          <div className="row">
            <div className="col-1">手机</div>
            <div className="col-2 v-center">
              <PhoneInput
                className="m-text read-only"
                readOnly={true}
                onChange={() => {}}
                value={user.regPhone}
                placeholder=""
              />
            </div>
            <div className="col-3 flex" />
          </div>}
        {isCommonUser &&
          <div className="row">
            <div className="col-1">签名</div>
            <div className="col-2">
              <CountedTextarea
                placeholder="个性化名子"
                className="m-text sign-text"
                maxLength={50}
                value={user.sign || ''}
                onChange={event => this.onChange('sign', event.target.value)}
              />
            </div>
          </div>}
        {isCommonUser &&
          <div className="row">
            <div className="col-1">昵称</div>
            <div className="col-2">
              <Input
                type="text"
                name="nickName"
                className="m-text"
                value={user.nickName}
                validations={['nickName']}
                placeholder="1-18个字符"
                onChange={e => this.onChange('nickName', e.target.value)}
              />
            </div>
          </div>}
        <div className="row">
          <div className="col-1">性别</div>
          <div className="col-2">
            <Select
              name="gender"
              value={user.gender || ''}
              options={[
                {value: '', label: '选择性别'},
                {value: '0', label: '男'},
                {value: '1', label: '女'}
              ]}
              searchable={false}
              onChange={value => this.onChange('gender', value)}
            />
          </div>
        </div>
        <div className="row">
          <div className="col-1">生日</div>
          <div className="col-2">
            <BirthInput
              className="m-text"
              onChange={birthday => this.onChange('birthday', birthday)}
              value={user.birthday || ''}
              placeholder="1990/01/01"
            />
          </div>
        </div>
        <div className="row">
          <div className="col-1">绿洲ID</div>
          <div className="col-2 flexbox">
            <IdEditor homePage={user.homePage} canEdit={canEdit} />
          </div>
        </div>
        <div className="row">
          <div className="col-1">密码</div>
          <div className="col-2">
            <span className="change-password" onClick={() => this.openModal()}>
              修改密码...
            </span>
          </div>
        </div>
        <div className="m-profile-account">
          <Modal
            isOpen={this.state.isOpen}
            contentLabel="Modal"
            style={modalStyle}>
            <ChangePassword closeModal={() => this.setState({isOpen: false})} />
          </Modal>
        </div>
        <div className="row bottom-row">
          <div className="col-1" />
          <div className="col-2 flexbox save-wrap">
            <Button type="submit" className="btn btn-primary" disabled={!this.canBeSave()}>
              保存
            </Button>
          </div>
        </div>
      </Form>
    )
  }
}

function mapStateToProps(state) {
  return {
    auth: state.auth,
    avatar: state.auth.get('pic')
  }
}
function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(
      {
        updateAvatar: authActions.updateAvatar,
        addToast: globalActions.addToast,
        updateBaseInfo: authActions.updateBaseInfo
      },
      dispatch
    )
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(ProfileAccount)
