import React, { Component, PropTypes } from 'react'
import {bindActionCreators} from 'redux'
import {connect} from 'react-redux'
import {Link, browserHistory} from 'react-router'
import {updateArtisan} from 'actions/artisan'
import Select from 'react-select'

class ArtisanHeader extends Component {
  handleChange = evt => {
    const value = evt.value
    
    this.props.actions.updateArtisan(['activeType'], value)
    const path = value === 'recommend' ? '/designer/hot' : '/designer'
    browserHistory.push(path)
  }

  render() {
    const {activeType} = this.props
    return (
      <div className="m-community-header">
        <div className="header__wrap">
          <Select
              className="header__select"
              value={activeType}
              options={[
                {value: 'designer', label: '设计师'},
                {value: 'recommend', label: '热门'}
              ]}
              searchable={false}
              onChange={this.handleChange}
            />
        </div>
      </div>
    )
  }
}

ArtisanHeader.propTypes = {

}

function mapStateToProps(state) {
  return {
    activeType: state.artisan.get('activeType')
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      updateArtisan
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(ArtisanHeader)
