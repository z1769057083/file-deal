import React, { Component, PropTypes } from 'react'

class About extends Component {
  render() {
    return (
      <div>
        <div className="m-others-slogan">
          <div className="title">信息，聚合流动</div>
          <p className="subtitle">业内碎片化的的资讯和灵感来源川流不息，<br/> 我们呈现最优质那些。</p>
        </div>
        <div className="list" style={{width: '500px', margin: '0 auto', textAlign: 'left'}}>
          <div className="item">
            <h1 className="title">流动设计灵感</h1>
            <div className="msg-digest">
              <p>
                在「空中绿洲」，丰富的图片蕴含于瀑布流中，游走在指尖， <br/>
                无需点击，设计灵感，瞬间捕捉。
              </p>
            </div>
          </div>
          <div className="item">
            <h1 className="title">一站行业动态</h1>
            <div className="msg-digest">
              <p>
                在「空中绿洲」，跨界泛设计资讯川流不息，流动在指尖， <br/>
                无需跳转，行业动态，片刻加载。
              </p>
            </div>
          </div>
          <div className="item">
            <h1 className="title">互通无界资源</h1>
            <div className="msg-digest">
              <p>
                在「空中绿洲」，远程的信息融通取代长途奔走，交互在指尖， <br/>
                无需出户，无界资源，及时获取。
              </p>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

About.propTypes = {

}

export default About
