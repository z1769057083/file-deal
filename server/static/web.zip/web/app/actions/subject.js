/**
 * 创建主题
 */
/**
 * Publish a new card
 */
import { CALL_API, CHAIN_API } from 'middleware/api'

export const PUBLISH_SUBJECT_SUCCESS = Symbol('PUBLISH_SUBJECT_SUCCESS')
export function addSubject(params) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/theme/add',
      query: params.payload,
      successType: PUBLISH_SUBJECT_SUCCESS,
      afterError: params.afterError,
      afterSuccess: params.afterSuccess
    }
  }
}

export const GET_SUBJECT = Symbol('GET_SUBJECT')
export function getSubject(id, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/theme/detail',
      query: {id},
      successType: GET_SUBJECT,
      afterError,
      afterSuccess
    }
  }
}

export const DELETE_SUBJECT = Symbol('DELETE_SUBJECT')
export function deleteSubject(id, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/theme/delete',
      query: {id},
      successType: DELETE_SUBJECT,
      afterError,
      afterSuccess
    }
  }
}

export const UPDATE_SUBJECT_SUCCESS = Symbol('UPDATE_SUBJECT_SUCCESS')
export function updateSubject(params) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/theme/update',
      query: params.payload,
      successType: UPDATE_SUBJECT_SUCCESS,
      afterError: params.afterError,
      afterSuccess: params.afterSuccess
    }
  }
}

export const UPDATE_SUBJECT_FIELD = Symbol('UPDATE_SUBJECT_FIELD')
export function updateSubjectField(key, value) {
  return {
    type: UPDATE_SUBJECT_FIELD,
    key,
    value
  }
}

export const UPLOAD_IMG_SUCCESS = Symbol('UPLOAD_IMG_SUCCESS')
/**
 * upload an image
 * @param formData, must include picFile as the param name
 */
export function uploadImg(formData, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/uploadimage',
      body: formData,
      successType: UPLOAD_IMG_SUCCESS,
      afterSuccess,
      afterError,
    }
  }
}

export const UPLOAD_BASE64_SUCCESS = Symbol('UPLOAD_BASE64_SUCCESS')
/**
 * upload an image
 * @param formData, must include picFile as the param name
 */
export function uploadImgBase64(data, afterSuccess) {
  return {
    [CALL_API]: {
      method: 'post',
      path: '/api/v1/open/uploadimagebase64',
      body: {
        picFile: data
      },
      successType: UPLOAD_BASE64_SUCCESS,
      afterSuccess
    }
  }
}

/**
 * open article window to add a new article or edit an article
 */
export const OPEN_SUBJECT_WINDOW = Symbol('OPEN_SUBJECT_WINDOW')
export function openSubjectWindow() {
  return {
    type: OPEN_SUBJECT_WINDOW
  }
}
export const CLOSE_SUBJECT_WINDOW = Symbol('CLOSE_SUBJECT_WINDOW')
export function closeSubjectWindow() {
  return {
    type: CLOSE_SUBJECT_WINDOW
  }
}
export const EDIT_SUBJECT = Symbol('EDIT_SUBJECT')
export function editSubject(subject) {
  return {
    type: EDIT_SUBJECT,
    subject
  }
}
export const RESET_SUBJECT = Symbol('RESET_SUBJECT')
export function resetSubject() {
  return {
    type: RESET_SUBJECT
  }
}

//获取大类列表
export const GET_FIRST_CLASS = Symbol('GET_FIRST_CLASS')
export function getFirstClass(afterSuccess, afterError) {
  return {
    [CALL_API]: {
      successType: GET_FIRST_CLASS,
      method: 'post',
      path: '/api/v1/open/config/classes',
      query: {},
      afterSuccess,
      afterError
    }
  }
}

//获取中类列表
export const GET_SECOND_CLASS = Symbol('GET_SECOND_CLASS')
export function getSecondClass(classId, afterSuccess, afterError) {
  return {
    [CALL_API]: {
      successType: GET_SECOND_CLASS,
      method: 'post',
      path: '/api/v1/open/config/childrenClasses',
      query: {classId},
      afterSuccess,
      afterError
    }
  }
}
