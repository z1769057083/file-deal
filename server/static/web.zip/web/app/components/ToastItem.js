import React, { Component, PropTypes } from 'react'
import { connect } from 'react-redux'
import {bindActionCreators } from 'redux'
import * as globalActions from 'actions/global'
import cx from 'classnames'
import {randomToastBg} from 'util/index'

class ToastItem extends Component {
  constructor(props) {
    super(props)
    this.state = {
      animated: false
    }
  }
  componentDidMount() {
    const toast = this.props.toast
    setTimeout(() => {
      this.setState({animated: true})
    }, 0)
    this.setTimeOut(toast)
  }
  componentWillReceiveProps(props) {
    if (props.toast.tid != this.props.toast.tid) {
      this.setState({animated: false})
      this.forceUpdate()
      setTimeout(() => {
        this.setState({animated: true})
      }, 0)
      this.setTimeOut(props.toast)
    }
  }
  componentWillUnmount() {
    clearTimeout(this.timeout)
  }
  setTimeOut(toast) {
    const timeout = toast.timeout
    if (timeout > 0) {
      this.timeout = setTimeout(() => {
        this.props.actions.removeToast(toast.tid)
        if (toast.callback) {
          toast.callback()
        }
      }, timeout)
    }
  }
  render() {
    const toast = this.props.toast
    const key = toast.tid
    const className = cx("m-toast-item", {animated: this.state.animated})
    const styles = toast.pic ? {
      background: `url(${toast.pic}) no-repeat center center`,
      backgroundSize: 'cover'
    }: {}

    switch (toast.type) {
      case 'savedToOases': {
        return (
          <li className={cx(className, 'white')} key={key}>
            <div className="avatar" style={styles} />
            <div className="tips">
              <div className="msg">已成功签入ta了</div>
            </div>
            <a href={toast.link || ''} className="btn btn-link">查看</a>
          </li>
        )
      }
      case 'black':
        return (
          <li className={cx(className, "black")} style={{backgroundColor: randomToastBg()}} key={key}>
            <div className="avatar" style={styles}></div>
            <div className="tips">
              <div className="name">{toast.message}</div>
            </div>
          </li>
        )
      case 'singleMsg':
        return (
          <li className={className} style={{backgroundColor: randomToastBg()}} key={key}>
            <div className="single-msg">{toast.message}</div>
          </li>
        )
      default :
        return <div key={key}></div>
    }
  }
}

function mapStateToProps (state, ownProps) {
  return {
    global: state.global
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      removeToast: globalActions.removeToast
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(ToastItem)