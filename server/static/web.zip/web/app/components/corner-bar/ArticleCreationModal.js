import React from 'react'
import Modal from 'react-modal'
import ArticleCreation from './ArticleCreation'
import SubjectSelection from './SubjectSelection'
import ArticleSuccess from './ArticleSuccess'
import ArticleNewSubject from './ArticleNewSubject'
import {bindActionCreators} from 'redux'
import {connect} from 'react-redux'
import {browserHistory} from 'react-router'
import * as articleActions from 'actions/article'
import * as globalActions from 'actions/global'

const customStyles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    overflow: 'scroll',
    zIndex: 200
  },
  content: {
    border: 'none',
    padding: '0px 0 20px 0',
    position: 'relative',
    borderRadius: '6px'
  }
}
class ArticleCreationModal extends React.Component {
  state = {
    page: 'article', //article/subject/subject_creation
    modal: '' //success/confirm or empty
  }

  componentWillReceiveProps(props) {
    const isOpen = props.article.get('modalIsOpen')
    const prevIsOpen = this.props.article.get('modalIsOpen')
    if (!isOpen && prevIsOpen) {
      document.body.classList.remove('modal-is-open')
    } else if (isOpen && !prevIsOpen) {
      document.body.classList.add('modal-is-open')
    }
  }

  afterOpenModal = () => {
    document.querySelector('.ReactModal__Overlay').scrollTop = 0
  }

  handleNext = page => this.setState({page})

  showModal = modal => this.setState({modal})

  viewTopic = () => {
    const {article, auth} = this.props
    const themeId = article.get('themeId')
    if (themeId > 0) {
      browserHistory.push(`/topic/${themeId}`)
    } else {
      browserHistory.push(`/user/${auth.get('homePage')}`)
    }
    this.showModal('')
    this.closeMessage()
  }

  closeMessage = () => {
    this.showModal('')
    this.props.actions.closeArticleWindow()
    document.body.classList.remove('modal-is-open')
  }

  render() {
    const {article} = this.props
    const {page, modal} = this.state
    const titles = {
      article: '创建手贴',
      subject: '归入主题',
      subject_creation: '另建主题'
    }
    if (modal === 'success') {
      return <ArticleSuccess
        isOpen={true}
        onRequestClose={this.closeMessage}
        viewTopic={this.viewTopic}
      />
    }
    return (
      <Modal
        isOpen={article.get('modalIsOpen')}
        onRequestClose={this.closeMessage}
        onAfterOpen={this.afterOpenModal}
        style={customStyles}
        overlayClassName="modal-new-pin"
        contentLabel="Modal">
        <div className="header">
          <div className="title">
            {titles[page]}
          </div>
          <div className="icon icon-close-white" onClick={this.closeMessage} />
        </div>
        <div className="main">
          {page === 'article' &&
            <ArticleCreation handleNext={this.handleNext} />}
          {page === 'subject' &&
            <SubjectSelection
              handleNext={this.handleNext}
              showModal={this.showModal}
            />}
          {page === 'subject_creation' &&
            <ArticleNewSubject handleNext={this.handleNext} />}
        </div>
        <div className="footer" />
      </Modal>
    )
  }
}

const mapStateToProps = state => ({
  article: state.article,
  auth: state.auth
})

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators(articleActions, dispatch),
  globalActions: bindActionCreators(globalActions, dispatch)
})

export default connect(mapStateToProps, mapDispatchToProps)(
  ArticleCreationModal
)
