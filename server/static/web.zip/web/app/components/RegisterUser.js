import React, { Component, PropTypes } from 'react'
import AuthSingleCard from 'components/AuthSingleCard'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import {registerUser} from 'actions/register'
import {loginUser} from 'actions/auth'
import {
  REGISTER_USER_START,
  REGISTER_USER_SUCCESS
} from 'config/authPage'
import {
  Form,
  Input,
  Button
} from 'react-validation/lib/build/validation.rc'
import {SubmitDecorator} from 'decorators'

class RegisterUser extends Component {
  constructor(props, context) {
    super(props, context)
    this.state = {
      nickName: '',
      pwd: '',
      repeatPwd: ''
    }
    this.onSubmit = this.onSubmit.bind(this)
    this.onPrevStep = this.onPrevStep.bind(this)
    this.handleNickName = this.handleNickName.bind(this)
    this.handlePwd = this.handlePwd.bind(this)
    this.handleRepeatPwd = this.handleRepeatPwd.bind(this)
  }
  onSubmit(event) {
    event.preventDefault()
    const {nickName, pwd, repeatPwd} = this.state
    const registerInfo = this.props.register
    if (pwd !== repeatPwd) {
      this.props.showError('密码与重复密码不一致')
      return
    }
    if (nickName && pwd && pwd === repeatPwd) {
      const {dispatch} = this.context.store
      const phone = registerInfo.get('phone')
      dispatch(registerUser({
        nickName,
        pwd,
        phone,
        verifyCode: registerInfo.get('code'),
        afterSuccess: () => {
          dispatch(loginUser({
            pwd,
            phone
          }))
          this.props.switchPage(REGISTER_USER_SUCCESS)
        },
        afterError: (state) => {
          this.props.showError(state.message || '注册失败[001]')
        }
      }))
    }
  }
  onPrevStep() {
    this.props.switchPage(REGISTER_USER_START)
  }
  handleNickName(e) {
    this.setState({
      nickName: e.target.value
    })
  }
  handlePwd(e) {
    this.setState({
      pwd: e.target.value
    })
  }
  handleRepeatPwd(e) {
    this.setState({
      repeatPwd: e.target.value
    })
  }
  render() {
    return (
      <AuthSingleCard closeAuthModal={this.props.closeAuthModal}>
        <Form className="card-main register-user modal-form"
          ref={c => {this.form = c}}
          onSubmit={this.onSubmit}
          >
          <div className="header">注册</div>
          <div className="main">
            <Input type="text"
              name="nickName"
              className="m-text"
              containerClassName="input field-wrapper"
              errorClassName="error"
              onChange={this.handleNickName}
              value={this.state.nickName}
              validations={['required']}
              placeholder="昵称"
            />
            <Input type="password"
              name="pwd"
              className="m-text"
              containerClassName="input field-wrapper"
              errorClassName="error"
              onChange={this.handlePwd}
              value={this.state.pwd}
              validations={['required', 'password', 'passwordConfirm']}
              placeholder="密码（字母、数字至少8位）"
            />
            <Input type="password"
              name="repeatPwd"
              className="m-text"
              containerClassName="input field-wrapper"
              errorClassName="error"
              onChange={this.handleRepeatPwd}
              value={this.state.repeatPwd}
              validations={['required', 'password', 'passwordConfirm']}
              placeholder="再次输入密码"
            />
          </div>
          <div className="footer flexbox equal-group field-wrapper btn-footer">
            <div className="btn" onClick={this.onPrevStep}>上一步</div>
            <Button type="submit" className="btn btn-primary">注册</Button>
            {this.props.error && <div className="form-error active">{this.props.error}</div>}
          </div>
        </Form>
      </AuthSingleCard>
    )
  }
}

RegisterUser.propTypes = {
  switchPage: PropTypes.func,
  closeAuthModal: PropTypes.func.isRequired
}

RegisterUser.contextTypes = {
  store: PropTypes.object
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      registerUser,
      loginUser
    }, dispatch)
  }
}

function mapStateToProps(state) {
  return {register: state.register}
}

export default connect(mapStateToProps, mapDispatchToProps)(SubmitDecorator(RegisterUser))
