import React, { Component, PropTypes } from 'react'
import { connect } from 'react-redux'
import Header from 'components/Header'
import OthersHeader from 'components/OthersHeader'

class Others extends Component {
  render() {
    return (
      <div className="m-others m-header--wrap">
        <Header />
        <div className="bg-image">
          <div className="mask">
            <OthersHeader />
            {this.props.children}
          </div>
        </div>
      </div>
    )
  }
}

function mapStateToProps (state) {
  return {}
}

Others.propTypes = {

}

export { Others }
export default connect(mapStateToProps)(Others)
