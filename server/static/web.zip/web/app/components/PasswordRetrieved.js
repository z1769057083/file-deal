import React, { Component, PropTypes } from 'react'
import AuthSingleCard from 'components/AuthSingleCard'
import PhoneInput from 'components/forms/PhoneInput'
import { connect } from 'react-redux'

class PasswordRetrieved extends Component {
  render() {
    const {phone} = this.props
    return (
      <AuthSingleCard closeAuthModal={this.props.closeAuthModal}>
        <div className="card-main register-success">
          <div className="header">密码找回</div>
          <div className="main">
            <p className="account">
              <PhoneInput className="m-text read-only"
                          readOnly={true}
                          onChange={() => {}}
                          value={phone}
                          placeholder=""
                />
            </p>
            <div className="icon icon-success"></div>
            <p className="p2">密码重置成功！</p>
          </div>
          <div className="footer flexbox single-button">
            <a href="/" className="btn btn-primary">首页</a>
          </div>
        </div>
      </AuthSingleCard>
    )
  }
}

function mapStateToProps(state) {
  return {
    phone: state.auth.get('regPhone')
  }
}

export default connect(mapStateToProps)(PasswordRetrieved)