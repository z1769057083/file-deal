import * as ActionType from 'actions/artisan'
import {fromJS} from 'immutable'

let defaultState = fromJS({
  activeType: 'designer', // designer: 设计师，recommend: 热门
  home: {
    firstPage: [],
    designers: []
  },
  designerList: [],
  recommendList: [
  ]
})
function artisanReducer(state = defaultState, action) {
  switch (action.type) {
    case ActionType.UPDATE_ARTISAN:
    {
      return state.setIn(action.keyPath, action.value)
    }
    case ActionType.GET_ARTISAN_DESIGNER_HOME:
    {
      return state.set('home', fromJS(action.response.data))
    }

    case ActionType.GET_ARTISAN_DESIGNER:
    {
      return state.set('designerList', fromJS(state.get('designerList').toJS().concat(action.response.data)))
    }

    case ActionType.GET_ARTISAN_RECOMMEND:
    {
      return state.set('recommendList', fromJS(action.response.data))
    }

    default:
      return state
  }
}

export default artisanReducer
