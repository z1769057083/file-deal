import React, {PropTypes} from 'react'
import {connect} from 'react-redux'
import {bindActionCreators} from 'redux'
import BlockImages from './BlockImages'
import CountedTextarea from 'components/forms/CountedTextarea'
import {Form} from 'react-validation/lib/build/validation.rc'
import * as articleActions from 'actions/article'
import * as globalActions from 'actions/global'

class ArticleCreation extends React.Component {
  state = {
    current: 0
  }

  updateField = key => evt => {
    const {actions} = this.props
    const {current} = this.state
    actions.updateArticleField(current, key, evt.target.value)
  }

  onFocusImage = current => this.setState({current})

  onUpload = index => (data, success) => {
    const {actions} = this.props
    actions.uploadImg(data, success)
  }

  afterUpload = index => data => {
    const {fileName, width, height} = data
    const {actions} = this.props
    actions.updateArticleField(index, 'pic', fileName)
    actions.updateArticleField(index, 'picWidth', width)
    actions.updateArticleField(index, 'picHeight', height)
  }
  
  handleDelete = index => () => {
    this.props.actions.removeImage(index)
  }

  handleNext = e => {
    e.preventDefault()
    const {article, globalActions, handleNext} = this.props
    const filter = item => item.get('picHeight') > 0 && item.get('pic') !== ''
    const articles = article.get('articles').filter(filter).toJS()
    if (articles.length > 0) {
      handleNext('subject')
    } else {
      globalActions.addToast({
        type: 'singleMsg',
        message: '需要上传至少一张图片',
        timeout: 2000
      })
    }
  }

  render() {
    const {article} = this.props
    const articles = article.get('articles').toJS()
    const {current} = this.state
    const data = articles.length >= current + 1 ? articles[current] : {}
    return (
      <Form
        className="m-form-base no-margin-bottom"
        ref={c => {
          this.form = c
        }}
        onSubmit={this.handleNext}>
        <div className="m-article-creation">
          <div className="article__main">
            <div className="article__col article__col--left">
              <BlockImages
                onUpload={this.onUpload}
                current={current}
                data={articles}
                onDelete={this.handleDelete}
                onFocus={this.onFocusImage}
                afterUpload={this.afterUpload}
              />
            </div>
            <div className="article__col">
              <div className="article__form">
                <div className="article__section">
                  <div className="article__title">主题</div>
                  <div className="article__field">
                    <CountedTextarea
                      className="m-text"
                      placeholder=""
                      maxLength={32}
                      value={data.title || ''}
                      onChange={this.updateField('title')}
                    />
                  </div>
                </div>
                <div className="article__section">
                  <div className="article__title">随笔</div>
                  <div className="article__field">
                    <CountedTextarea
                      className="m-text"
                      placeholder=""
                      maxLength={120}
                      value={data.summary}
                      onChange={this.updateField('summary')}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="article__footer">
            <span className="footer__tips">*至多一次发布5个手贴</span>
            <button type="submit" className="btn btn-primary">
              下一步
            </button>
          </div>
        </div>
      </Form>
    )
  }
}

ArticleCreation.propTypes = {
  handleNext: PropTypes.func.isRequired
}

const mapStateToProps = state => ({
  article: state.article,
})

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators(articleActions, dispatch),
  globalActions: bindActionCreators(globalActions, dispatch)
})

export default connect(mapStateToProps, mapDispatchToProps)(ArticleCreation)
