/**
 * Upgrade Tips
 */
import React, { Component, PropTypes } from 'react'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import * as authActions from 'actions/auth'
import * as globalActions from 'actions/global'
import {
  PRO_APPLY
} from 'config/authPage'

class UpgradeTips extends Component {
  render() {
    const showUpgradeTips = this.props.global.get('showUpgradeTips')
    if (!showUpgradeTips) {
      return null
    }
    return (
      <div className="m-upgrade-tips" style={{width: this.props.width}}>
        <div className="title">发布权限</div>
        <div className="tips">
          你点击的是<span className="pro">「发手帖」</span>或<span className="pro">「建主题」</span>按键，
          在网页端，仅indie用户拥有权限；普通用户请点击“下载”去往苹果应用商店，搜「空中绿洲」下载应用。
        </div>
        <div className="btn-group flexbox">
          <div className="button" onClick={this.props.actions.hideUpgradeTips}>知道了</div>
        </div>
      </div>
    )
  }
}

UpgradeTips.propTypes = {
  width: PropTypes.number.isRequired
}

function mapStateToProps (state) {
  return {
    global: state.global
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      hideUpgradeTips: globalActions.hideUpgradeTips,
      showAuthWindow: globalActions.showAuthWindow,
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(UpgradeTips)