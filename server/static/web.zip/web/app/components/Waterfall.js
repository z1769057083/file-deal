import React, { Component, PropTypes } from 'react'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import Card from 'components/Card'
import { List } from 'immutable'
import _ from 'lodash'
import {withRouter} from 'react-router'
import * as util from 'util/index'
import * as cardActions from 'actions/card'
import * as articleActions from 'actions/article'
import * as globalActions from 'actions/global'
import { browserHistory } from 'react-router'

const CARD_WIDTH = 235
const CARD_BOTTOM_HEIGHT = 65
const CARD_MARGIN = 30
const CARD_MARGIN_TOP = 35
class Waterfall extends Component {
  constructor(props, context) {
    super(props, context)
    this.state = this.addPositions(this.props.cards, this.props.column)
  }

  componentWillReceiveProps(nextProps) {
    this.setState(this.addPositions(nextProps.cards, this.props.column))
  }

  // show inital background color according to card index
  getColor(index) {
    const remainer = index % 6
    const colors = [
      'rgb(155,155,155)',
      'rgb(198,198,198)',
      'rgb(230,230,230)',
      'rgb(84,84,84)',
      'rgb(46,46,46)',
    ]
    return colors[remainer]
  }

  // add positions for card
  addPositions(cardsOri, oldColumn) {
    const column = util.columnStrategy(oldColumn)
    const columns = Array.from({length: column}, k => 0)
    const cards = cardsOri.toJS()
    cards.map((card, index) => {
      const min = _.min(columns)
      const minPos = _.findIndex(columns, value => {return value == min})
      let {picWidth, picHeight} = card

      // TODO should remove this block if test data is removed
      if (picHeight == 0 && picHeight == 0) {
        picHeight = 550
        picWidth = 750
      }
      const scaledHeight = Math.ceil(picHeight * CARD_WIDTH / picWidth)
      const bottomHeight = CARD_BOTTOM_HEIGHT
      const descHeight = util.heightOfText(card.title, 195)
      card.scaledHeight = scaledHeight
      card.descHeight = descHeight
      card.bottomHeight = bottomHeight
      card.position = {
        height: scaledHeight + bottomHeight + descHeight,
        left: (minPos + 1) * CARD_MARGIN + minPos * CARD_WIDTH,
        top: min + CARD_MARGIN_TOP
      }
      card.topColor = this.getColor(index)
      columns[minPos] += CARD_MARGIN_TOP + card.position.height
    })
    return {
      cards,
      column: this.props.column,
      height: _.max(columns)
    }
  }

  linkTo(event, path) {
    event.preventDefault()
    const {returnTo} = this.props
    const {pathname, search} = location
    let toUrl = !returnTo ? pathname + search : returnTo
    if (toUrl === '/' && pathname === '/search') {
      toUrl = pathname + search
    }
    this.props.actions.updateCardMode({
      inModal: true,
      contextCards: this.props.cards.toJS(),
      returnTo: toUrl
    })
    browserHistory.push(path)
  }
  
  openArticleModal = () => {
    const {articleActions, auth, globalActions} = this.props
    if (!auth.get('id')) {
      return this.showLoginToast()
    }
    
    // check pro
    if (auth.get('userType') === '0') {
      return globalActions.showUpgradeTips()
    }
    
    articleActions.resetArticle()
    articleActions.openArticleWindow()
  }

  renderCreate() {
    const {user, userId} = this.props
    const column = util.columnStrategy(this.props.column)
    const cls = `m-waterfall column-${column}`
    const isSelf = user.getIn(['userInfo', 'ownerId']) === userId
    return (
      <div className={cls} style={{height: this.state.height + 'px'}}>
        <div className="count">0个贴</div>
        <div className="card__wrap">
          {
            isSelf?
            <div className="photo__wrap" onClick={this.openArticleModal}>
              <div className="photo__main photo__main--add">
                <div className="photo__add">
                  <div className="icon icon-add-white" />
                </div>
                <div className="photo__text">发布手帖</div>
              </div>
            </div>:
            null
          }
          
        </div>
      </div>
    )
  }

  renderList() {
    const column = util.columnStrategy(this.props.column)
    const {pathname} = this.props.location
    const isShoutieTab = util.isShoutie(pathname)
    const cls = `m-waterfall column-${column}`
    const {cards} = this.state
    return (
      <div className={cls} style={{height: this.state.height + 'px'}}>
        {isShoutieTab && <div className="count">{cards.length}个贴</div>}
        <div className="card__list">
          {cards.map((card, key) => {
            return <Card key={key} data={card}
                         onClickCard={this.linkTo.bind(this)}
                         type={this.props.type}
                         alt={card.alt}
                         canEdit={this.props.canEdit}
                         showUnCollect={this.props.showUnCollect}
                         location={this.props.location} />
          })}
        </div>
      </div>
    )
  }

  render() {
    const {cards} = this.state
    const {pathname} = this.props.location
    const isShoutieTab = util.isShoutie(pathname)
    if (!isShoutieTab) return this.renderList()
    return cards.length > 0 ? this.renderList() : this.renderCreate()
  }
}

Waterfall.propTypes = {
  cards: PropTypes.instanceOf(List).isRequired,
  column: PropTypes.number,
  location: PropTypes.object,
  type: PropTypes.number,
  canEdit: PropTypes.bool,
  // 签入后，是否显示已签入的icon (icon-edit)
  showUnCollect: PropTypes.bool
}

Waterfall.defaultProps = {
  column: 4,
  type: 0,
  location: {},
  canEdit: false,
  showUnCollect: false
}

function mapStateToProps(state, ownProps) {
  return {
    auth: state.auth,
    user: state.user,
    returnTo: state.cards.get('returnTo'),
    userId: state.auth.get('id')
  }
}

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators(cardActions, dispatch),
  articleActions: bindActionCreators(articleActions, dispatch),
  globalActions: bindActionCreators(globalActions, dispatch)
})

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Waterfall))
