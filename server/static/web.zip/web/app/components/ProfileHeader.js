import React, {Component, PropTypes} from 'react'
import {Link} from 'react-router'
import {connect} from 'react-redux'

class ProfileHeader extends Component {
  render() {
    const userType = this.props.auth.get('userType')
    return (
      <div className="m-sub-header">
        <div className="nav flexbox">
          <Link
            to={`/user/${this.props.userId}/profile`}
            className="flex"
            onlyActiveOnIndex
            activeClassName="active">
            帐户
          </Link>
          <Link to="/others" className="flex">
            下载
          </Link>
          <Link to="/about" className="flex">
            关于
          </Link>
          <Link to="/legal" className="flex">
            法务
          </Link>
          <Link to="/feedback" className="flex">
            反馈
          </Link>
        </div>
      </div>
    )
  }
}

ProfileHeader.propTypes = {}

function mapStateToProps(state, ownProps) {
  return {
    auth: state.auth
  }
}

export default connect(mapStateToProps)(ProfileHeader)
