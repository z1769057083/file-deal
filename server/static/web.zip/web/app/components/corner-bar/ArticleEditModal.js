import React, {PropTypes} from 'react'
import Modal from 'react-modal'
import {bindActionCreators} from 'redux'
import {connect} from 'react-redux'
import CountedTextarea from 'components/forms/CountedTextarea'
import ArticleConfirmation from 'components/corner-bar/ArticleConfirmation'
import {Form, Button} from 'react-validation/lib/build/validation.rc'
import * as articleActions from 'actions/article'
import * as globalActions from 'actions/global'
import * as userActions from 'actions/user'
import Select from 'react-select'

const customStyles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    overflow: 'scroll',
    zIndex: 200
  },
  content: {
    border: 'none',
    padding: '0px 0 20px 0',
    position: 'relative',
    borderRadius: '6px'
  }
}
class ArticleEditModal extends React.Component {
  state = {
    themes: [],
    data: this.props.data,
    confirm: false
  }

  componentDidMount() {
    this.getList();
  }

  getList = () => {
    console.log(this.props.article.get('id'),'this.props.articlethis.props.article')
    const {userActions, userId} = this.props
    const payload = {imageCount: 1, userId}
    const success = ({response}) => this.setState({themes: response.data})
    userActions.getUserThemes(payload, success)
    userActions.getUserArticlesDetail(this.props.data.articleId, res=>{
      let _data = this.state.data;
      _data.notes = res.response.data.notes;
      this.setState({
        data: _data
      });
      
    })
  }

  updateArticle = field => evt => {
    const value =
      field === 'themeId' ? parseInt(evt.value) : evt.target.value
    const data = {...this.state.data, [field]: value}
    this.setState({data})
  }

  message(message) {
    const {globalActions} = this.props
    globalActions.addToast({
      type: 'singleMsg',
      message,
      timeout: 1500
    })
  }

  handleSave = evt => {
    evt.stopPropagation()
    evt.preventDefault()
    const {actions, userId} = this.props
    const {data} = this.state
    data.userId = userId;
    const success = () => {
      this.message('保存成功')
      this.props.handleClose()
    }
    const fail = () => this.message('保存失败')
    actions.saveArticle(data, success, fail)
  }

  handleDelete = () => {
    const {actions} = this.props
    const {data} = this.state
    const {themeId, articleId} = data
    const success = () => {
      this.message('已成功签出ta了')
      this.props.handleClose()
    }
    const fail = () => this.message('签出失败')
    const payload = {themeId, articleId}
    actions.removeArticle(payload, success, fail)
  }
  
  closeConfirm = () => {
    this.setState({confirm: false})
    this.handleDelete()
  }
  
  giveUpDeletion = () => this.setState({confirm: false})
  
  confirmDeletion = () => this.setState({confirm: true})

  render() {
    const {isOpen, handleClose} = this.props
    const {themes, data, confirm} = this.state
    const topImg = data.pic || '/assets/images/default_pic.svg'
    const size = data.pic ? '/cover' : ''
    const styles = {
      background: `url(${topImg}) center center ${size} no-repeat #F1F1F1`,
      width: 244,
      height: 162
    }
    return (
      <Modal
        isOpen={isOpen}
        onRequestClose={handleClose}
        style={customStyles}
        overlayClassName="modal-new-pin"
        contentLabel="Modal">
        <div className="header">
          <div className="title">编辑手贴</div>
          <div className="icon icon-close-white" onClick={handleClose} />
        </div>
        <div className="main">
          <div className="m-article-edit">
            <Form
              className="m-form-base no-margin-bottom"
              onSubmit={this.handleSave}>
              <div className="row">
                <div className="col-1" />
                <div className="col-2">
                  <div className="article__img" style={styles} />
                </div>
              </div>
              <div className="row">
                <div className="col-1">备注</div>
                <div className="col-2">
                  <CountedTextarea
                    className="m-text"
                    placeholder="对头图做一些描述..."
                    maxLength={120}
                    value={data.notes || ''}
                    onChange={this.updateArticle('notes')}
                  />
                </div>
              </div>
              <div className="row">
                <div className="col-1">主题</div>
                <div className="col-2">
                  <Select
                    className="m-text"
                    value={String(data.themeId)}
                    onChange={this.updateArticle('themeId')}
                    options={
                      themes.map((item, key) => {
                        return {
                          value: item.id,
                          label: item.name
                        }
                      })
                    }
                    >
                  </Select>
                </div>
              </div>
              <div className="row">
                <div className="col-1" />
                <div className="col-2 article-footer">
                  <Button
                    type="button"
                    className="btn btn-delete"
                    onClick={this.confirmDeletion}>
                    签出
                  </Button>
                  <Button type="submit" className="btn btn-primary">
                    保存
                  </Button>
                </div>
              </div>
            </Form>
            <ArticleConfirmation
              isOpen={confirm}
              onRequestClose={this.closeConfirm}
              giveUp={this.giveUpDeletion}
            />
          </div>
        </div>
        <div className="footer" />
      </Modal>
    )
  }
}

ArticleEditModal.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  data: PropTypes.shape({
    themeId: PropTypes.number.isRequired,
    articleId: PropTypes.number.isRequired,
    pic: PropTypes.string.isRequired
  }).isRequired,
  handleClose: PropTypes.func.isRequired
}

const mapStateToProps = state => ({
  article: state.article,
  userId: state.user.getIn(['userInfo', 'ownerId']),
  auth: state.auth
})

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators(articleActions, dispatch),
  userActions: bindActionCreators(userActions, dispatch),
  globalActions: bindActionCreators(globalActions, dispatch)
})

export default connect(mapStateToProps, mapDispatchToProps)(ArticleEditModal)
