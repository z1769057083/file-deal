import React, { Component, PropTypes } from 'react'
import { connect } from 'react-redux'
import Helmet from 'react-helmet'
import { browserHistory } from 'react-router'
import * as authActions from 'actions/auth'
import * as globalActions from 'actions/global'
import * as searchActions from 'actions/search'
import Toast from 'components/Toast'
import Loading from 'components/global/Loading'
import {bindActionCreators } from 'redux'
import {Rules} from 'components/forms/Rules'
import {LOGIN_USER_START, LOGIN_COVER_START} from 'config/authPage'
import cx from 'classnames'

// set form validation rules
import {rules} from 'react-validation/lib/build/validation.rc'
Object.assign(rules, Rules)
class App extends Component {
  constructor(props) {
    super(props)
    this.state = {
      isLoading: false
    }
    this.timer = null
  }

  componentWillReceiveProps(nextProps) {
    // if we changed routes...
    const prevInModal = this.props.cards.get('inModal')
    const nextInModal = nextProps.cards.get('inModal')
    if (!prevInModal && nextInModal) {
      this.previousChildren = this.props.children
    } else if (!nextInModal && prevInModal) {
      this.previousChildren = null
    }
    //退出
    if (!nextProps.auth.get('id') && this.props.auth.get('id')) {
      this.next(true, true)
    }
  }

  componentDidMount() {
    const setInit = () => {
      this.props.actions.updateGlobal('init', true)
      const matches = this.props.location.pathname.match(/^\/user\/(\w+)\/profile.*/i)
      const isAuthenticated = !!this.props.auth.get('id')
      const toHome = !isAuthenticated && !!matches
      const showAuth = !isAuthenticated && !!matches
      // 当前页面为/user相关页面，却是未登录状态，则转向首页，且弹出登录框
      this.next(toHome, showAuth)
    }
    this.props.actions.getAuthInfo(setInit, setInit)
    this.props.actions.getHotWords()

    this.timer = setTimeout(() => {
      if (!this.props.auth.get('id') && !this.props.global.get('authWindowType')) {
        this.props.actions.showAuthWindow(LOGIN_COVER_START)
      }
    }, 2000)
  }

  componentWillUnmount() {
    clearTimeout(this.timer)
  }

  next(toHome, showAuth) {
    toHome && browserHistory.push('/')
    showAuth && this.setState({isLoading: true}, () => {
      const that = this
      window.setTimeout(() => {
        that.setState({isLoading: false})
        that.props.actions.showAuthWindow(LOGIN_USER_START)
      }, 2000)
    })
  }

  render() {
    const {cards, global, location} = this.props
    let inModal = cards.get('inModal')
    const hasFilter = !!global.get('authWindowType')
    const init = global.get('init')
    const isMobile = /^\/mobile\/\w+/i.test(location.pathname)
    const showLoading = !isMobile && (!init || this.state.isLoading)
    return (
      <div className={cx({"app-has-filter": hasFilter})}>
        <Helmet
          defaultTitle="空中绿洲"
          titleTemplate="%s - 空中绿洲"
          link={[
              {"rel": "apple-touch-icon", "href": "/assets/images/oasis_ico_64x64.png"},
              {"rel": "icon", "sizes": "16x16", "href": "/assets/images/oasis_ico_16x16.png"},
              {"rel": "icon", "sizes": "32x32", "href": "/assets/images/oasis_ico_32x32.png"},
              {"rel": "icon", "sizes": "64x64", "href": "/assets/images/oasis_ico_64x64.png"},
              {"rel": "icon", "sizes": "128x128", "href": "/assets/images/oasis_ico_128x128.png"}
          ]}
          meta={[
            {"name": "description", "content": "「空中绿洲」是一个富氧的泛设计资讯空间"},
            {"name": "keywords", "content": "建筑设计，视觉艺术，设计，工业设计，摄影"},
            {"name": "viewport", "content": "width=device-width, initial-scale=1.0, minimum-scale=1.0, " +
             "maximum-scale=1.0, user-scalable=no"}
          ]}
          htmlAttributes={{"lang": "en"}}
          />
        {inModal ?
          this.previousChildren :
          this.props.children
        }
        {inModal && (
          this.props.children
        )}
        <Loading isOpen={showLoading}/>
        <Toast />
      </div>
    )
  }
}

function mapStateToProps(state) {
  return {
    auth: state.auth,
    global: state.global,
    cards: state.cards
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      getAuthInfo: authActions.getAuthInfo,
      updateGlobal: globalActions.updateGlobal,
      showAuthWindow: globalActions.showAuthWindow,
      getHotWords: searchActions.getHotWords,
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(App)
