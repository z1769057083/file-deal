/**
 * Download page for mobile
 */
import React, { Component, PropTypes } from 'react'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'

class Download extends Component {
  render() {
    return (
      <div className="m-mobile">
        <div className="download">
          <div className="slides">
            <img src="/assets/images/mobile/share_pic@2x.jpg" alt=""/>
          </div>
          <div className="button-wrap">
            <a className="btn btn-download"
               href="https://itunes.apple.com/cn/app/%E7%A9%BA%E4%B8%AD%E7%BB%BF%E6%B4%B2/id1231916319?mt=8">IOS下载</a>
            <a className="btn btn-download"
               href="/assets/apk/app-release20170908_1.0.0.apk">android下载</a>
          </div>

          <div className="desc">「空中绿洲」 <br/>富氧的泛设计资讯空间</div>
        </div>
      </div>
    )
  }
}

function mapStateToProps (state) {
  return {}
}

export default connect(mapStateToProps)(Download)