import React, {Component, PropTypes} from 'react'
import {bindActionCreators} from 'redux'
import {connect} from 'react-redux'
import Modal from 'react-modal'
import * as cardActions from 'actions/card'
import Waterfall from 'components/Waterfall'
import Carousel from 'components/Carousel'
import Avatar from 'components/Avatar'
import {fromJS} from 'immutable'
import {browserHistory} from 'react-router'
import classNames from 'classnames'
import CardActionBar from 'components/card/CardActionBar'
import DownloadTips from 'components/works/DownloadTips'
import PageStatus from 'components/PageStatus'
import {truncateHtml} from 'util/index'
import WorksReference from './WorksReference'
import WorksFrom from './WorksFrom'

const customStyles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: '#000',
    overflow: 'hidden',
    zIndex: 300
  },
  content: {
    position: 'relative',
    top: 0,
    left: 0,
    width: '100%',
    bottom: 0,
    border: 'none',
    padding: '0',
    backgroundColor: '#000',
    borderRadius: '0',
    height: '100%'
  }
}

const propTypes = {
  inModal: PropTypes.bool.isRequired
}

class WorksDetail extends Component {
  constructor(props) {
    super(props)
    this.state = {
      data: {},
      index: -1,
      contextCards: [],
      type: 0,

      // related cards
      relatedCards: [],
      pageSize: 0,
      lastSortId: -1,
      isEnd: false,
      loading: false,

      modalIsOpen: false,
      clickedPicIndex: 0,
      folded: true,
      init: false,

      //scroll
      dom: null,
      morePending: false
    }
    this._onKeyup = this._onKeyup.bind(this)
    this.onScroll = this.onScroll.bind(this)
    this.onScrollBody = this.onScrollBody.bind(this)
  }

  componentWillReceiveProps(nexProps) {
    const props = this.props
    if (nexProps.id !== props.id) {
      this.initData(nexProps)
      this._scrollTop()
    }
  }

  componentDidMount() {
    this.initData(this.props)
    document.addEventListener('keyup', this._onKeyup)
    if (this.props.inModal) {
      const dom = document.querySelector('#m-works .ReactModal__Content')
      dom.addEventListener('scroll', this.onScroll)
      this.setState({dom})
    } else {
      window.addEventListener('scroll', this.onScrollBody)
    }
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this._onKeyup)
    if (this.props.inModal) {
      this.state.dom.removeEventListener('scroll', this.onScroll)
    } else {
      window.removeEventListener('scroll', this.onScrollBody)
    }
  }

  onScroll() {
    const {dom} = this.state;
    const isBottom = dom.scrollTop + dom.clientHeight >= dom.scrollHeight - 20
    if (isBottom) {
      this.loadMoreRelated()
    }
  }

  onScrollBody() {
    const isBottom =
      window.innerHeight + window.scrollY >= document.body.offsetHeight
    if (isBottom) {
      this.loadMoreRelated()
    }
  }

  _scrollTop() {
    window.setTimeout(function() {
      const container = document.querySelector(
        '.ReactModal__Content--after-open'
      )
      if (container) {
        container.scrollTop = 0
      }
    }, 0)
  }

  _onKeyup(e) {
    switch (e.keyCode) {
      case 37:
        this._navigateTo(this.state.index - 1)
        break
      case 39:
        this._navigateTo(this.state.index + 1)
        break
      case 27:
        if (this.state.modalIsOpen) {
          this._closeModal()
        } else {
        }
        break
    }
  }

  _navigateTo(id) {
    if (this.state.modalIsOpen) {
      return
    }
    const list = this.props.cards.get('contextCards').toJS()
    if (id > -1 && id < list.length) {
      browserHistory.push(`/works/${list[id]['id']}?type=${this.props.type}`)
    } else {
      const card = list[id - 1]
      if (card.nextPage) {
        const {nextPage} = card
        this.props.actions.loadNextPageCards(
          nextPage.path,
          nextPage.query,
          () => {
            const newList = this.props.cards.get('contextCards').toJS()
            if (newList.length > list.length) {
              browserHistory.push(
                `/works/${newList[id]['id']}?type=${this.props.type}`
              )
            }
          }
        )
      }
    }
  }

  _openModal(index) {
    this.setState({
      modalIsOpen: true,
      clickedPicIndex: index
    })
  }

  _closeModal() {
    this.setState({
      modalIsOpen: false
    });
  }

  /**
   * 获取更多关联文章
   */
  loadMoreRelated() {
    const {isEnd, lastSortId, loading} = this.state
    if (!isEnd && !loading) {
      this.setState({loading: true})

      const query = {
        articleId: this.props.id,
        sortId: lastSortId
      }
      this.props.actions.loadRelatedCards2(
        query,
        state => {
          const {lastSortId, artList, pageSize} = state.response.data
          if (query.articleId !== this.props.id) {
            return
          }
          this.setState({
            relatedCards: this.state.relatedCards.concat(artList),
            lastSortId,
            pageSize,
            isEnd: artList.length < pageSize,
            loading: false
          })
        },
        () => {
          this.setState({loading: false})
        }
      )
    }
  }

  initData(props) {
    const {cards, id} = props
    const contextCards = cards.get('contextCards')
    console.log(cards)
    const index = contextCards.findLastKey(item => item.get('id') == id)
    // const index = undefined
    /**
     * 如果在上下文卡片中找到了这个id对应的文章，则直接用卡片中的数据
     * 否则(index === undefined)，调用 loadArticleDetail来获取
     */
    this.setState({
      relatedCards: [],
      pageSize: 0,
      lastSortId: -1,
      isEnd: false,
      loading: false
    })
    if (index === undefined) {
      const type = props.type
      this.setState({type})
      this.props.actions.loadArticleDetail(
        id,
        type,
        state => {
          this.setState({
            data: state.response.data,
            init: true
          })
          this.loadMoreRelated()
        },
        () => this.setState({init: true})
      )
    } else {
      this.setState(
        {
          data: contextCards.get(index).toJS(),
          index
        },
        this.loadMoreRelated
      )

      if (props.type !== '0') {
        const type = props.type
        this.setState({type})
        this.props.actions.loadArticleDetail(
          id,
          type,
          state => {
            this.setState({
              data: state.response.data,
              init: true
            })
          },
          () => this.setState({init: true})
        )
      } else {
        this.setState({init: true})
      }
    }
  }

  renderProject(projects) {
    if (!projects || projects.length < 1) {
      return null
    }
    return (
      <div className="section-project">
        {projects.map((item, key) => {
          return (
            <div className="item" key={key}>
              <span className="key">
                {item.pname}
              </span>
              <span className="value">
                {item.pvalue}
              </span>
            </div>
          )
        })}
      </div>
    )
  }

  renderPics(pics) {
    if (!pics) {
      return null
    }
    return (
      <div className="section-pics">
        <div className="section-scroll">
          <div className="pics-wrap">
            {pics.map((item, key) => {
              return (
                <div className="item" key={key}>
                  <img
                    src={item.fileName}
                    alt=""
                    onClick={this._openModal.bind(this, key)}
                  />
                </div>
              )
            })}
          </div>
        </div>
      </div>
    )
  }

  renderModal(pics) {
    if (!pics) return null
    return this.state.modalIsOpen
      ? <Modal isOpen={true} contentLabel="Modal" style={customStyles}>
          <Carousel
            pictures={pics}
            onRequestClose={this._closeModal.bind(this)}
            startSlide={this.state.clickedPicIndex}
          />
        </Modal>
      : null
  }

  renderWorksSummary(data) {
    const summary = data.summary
      .replace('\r\n', '<br />')
      .replace('\n', '<br />')
    return (
      <div
        className="works-summary"
        dangerouslySetInnerHTML={{
          __html: summary
        }}
      />
    )
  }

  renderProSummary(data) {
    return (
      <div className="pro-summary">
        {data.summary}
        <div className="line" />
      </div>
    )
  }

  renderContent(data) {
    if (!data.content) {
      return null
    }
    const result = truncateHtml(data.content, 400)
    const folder = (
      <div
        className="folder"
        onClick={() => {
          this.setState({folded: !this.state.folded})
        }}>
        <div className="text">
          {this.state.folded ? 'Open' : 'Close'} &gt;&gt;
        </div>
        <div
          className={classNames('arrow', this.state.folded ? 'down' : 'up')}
        />
      </div>
    )
    return (
      <div className="content">
        <div
          className="main"
          dangerouslySetInnerHTML={{
            __html: this.state.folded ? result.content : data.content
          }}
        />
        {result.isOverflow ? folder : null}
      </div>
    )
  }

  renderCooperation(data) {
    if (!data.legalNotice) {
      return null
    }
    const legalNotice = (
      <div className="legal-notice">
        {data.legalNotice.value}
      </div>
    )
    const cooperation = (
      <div className="cooperation">
        合作说明: {data.cooperation}
      </div>
    )
    return (
      <div className="legal-cooperation">
        {data.cooperation ? cooperation : null}
        {data.legalNotice.key != '' ? legalNotice : null}
      </div>
    )
  }

  renderProFrom(data) {
    return (
      <div className="from pro-from flexbox">
        <div className="left-side flexbox">
          <div className="avatar">
            {data.authorPic ? <img src={data.authorPic} alt="" /> : null}
          </div>

          <div className="name">
            {data.authorName}
          </div>
        </div>
        <div className="date flexbox">
          <span className="icon icon-date" />
          <span className="publish-days">
            {data.publishDays}
          </span>
        </div>
      </div>
    )
  }

  renderPosition(data) {
    if (this.props.type < 1) {
      return null
    }
    const position = (this.props.type == 1 ? '有料' : '云库') + ' / 公社 '
    const fontSize = data.serialNo && data.serialNo.length > 2 ? '12px' : '16px'
    return (
      <div className="m-position">
        <div className="juan">
          <div className="p1" style={{fontSize}}>
            {data.serialNo}
          </div>
          <div className="p2">卷</div>
        </div>
        <div className="position">
          {data.authorName} ／ {position}
        </div>
      </div>
    )
  }

  renderCnt(data) {
    return (
      <div className="read-cnt">
        <span className="p1">{`${data.favoriteCnt || ''}`}</span> /{' '}
        <span className="p2">{`${data.readCnt || ''}`}</span>
      </div>
    )
  }

  render() {
    const {data, relatedCards, isEnd, loading, init} = this.state
    const {type} = this.props
    if (!init) {
      return null
    }
    const currentIndex = this.state.index

    let pageStatus = 'default'
    if (isEnd) {
      pageStatus = 'isEnd'
    } else if (loading) {
      pageStatus = 'loading'
    }
    return (
      <div className="m-works-detail">
        <DownloadTips />
        {currentIndex > -1
          ? <div className="navigation">
              <div
                className="prev item icon icon-prev"
                onClick={() => this._navigateTo(currentIndex - 1)}
              />
              <div
                className="next item icon icon-next"
                onClick={() => this._navigateTo(currentIndex + 1)}
              />
            </div>
          : null}
        <div className={classNames({'main-card': true})}>
          <div
            className="close icon 1232 icon-close-white"
            onClick={(e)=>{

              this.props.onRequestClose(e);
            }}
          />
          <CardActionBar
            id={parseInt(this.props.id)}
            title={data.title || ''}
            isFavorite={data.isFavorite}
            wechatUrl={data.wechatUrl || ''}
            firstPic={data.pic}
            showTrend={true}
            showInform={true}
            showUnCollect={false}
            type={parseInt(this.props.type)}
          />

          <div className="title">
            {data.title}
          </div>
          <div className="picture">
            {this.renderPosition(data)}
            {data.pic &&
              (data.alt
                ? <a href={data.sourceUrl} target="_blank">
                    <img src={data.pic} alt="" />
                  </a>
                : <img src={data.pic} alt="" />)}
          </div>
          <WorksFrom data={data} />
          {this.renderWorksSummary(data)}
          <div className="works-bottom">
            <WorksReference data={data} />
            {data.themeId > 0 &&
              <div className="works-subject">
                <div className="subject__p1">签入在</div>
                <div className="subject__p2">
                  <a href={`/topic/${data.themeId}`}>
                    「{data.themeName || data.theme}」
                  </a>主题
                </div>
              </div>}
          </div>
        </div>
        <div className="related-cards">
          {relatedCards.length > 0 && <div className="title">更多推荐</div>}
          <Waterfall
            cards={fromJS(relatedCards)}
            type={parseInt(type)}
            column={3}
            location={this.props.location}
          />
          {relatedCards.length > 0 &&
            <PageStatus status={pageStatus} height={100} />}
        </div>
        {(type == 1 || type == 2) && this.renderModal(data.picSuite)}
      </div>
    )
  }
}

WorksDetail.propsTypes = propTypes

function mapStateToProps(state, ownProps) {
  return {
    cards: state.cards
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(
      {
        loadCard: cardActions.loadCard,
        loadArticleDetail: cardActions.loadArticleDetail,
        updateCardMode: cardActions.updateCardMode,
        loadRelatedCards2: cardActions.loadRelatedCards2,
        loadNextPageCards: cardActions.loadNextPageCards
      },
      dispatch
    )
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(WorksDetail)
