import React, {Component, PropTypes} from 'react'
import {connect} from 'react-redux'
import {bindActionCreators} from 'redux'
import {fromJS} from 'immutable'
import Header from 'components/Header'
import CornerBar from 'components/CornerBar'
import Waterfall from 'components/Waterfall'
import UpgradeTips from 'components/UpgradeTips'
import UserTopicHeader from './partial/UserTopicHeader'
import * as actions from 'actions/article'
import * as subjectActions from 'actions/subject'
import * as articleActions from 'actions/article'
import * as globalActions from 'actions/global'

class UserTopic extends Component {
  state = {
    type: 0,
    data: [],
    theme: {},
    total: 0,
    init: false
  }

  componentDidMount() {
    this.getTheme()
    this.getArticles()
  }

  componentDidUpdate(prevProps) {
    const {themeId} = this.props.params
    if (themeId !== prevProps.params.themeId) {
      this.getTheme()
      this.getArticles()
    }
  }

  getTheme() {
    const {themeId} = this.props.params
    const {subjectActions} = this.props
    const success = ({response}) => this.setState({theme: response.data})
    subjectActions.getSubject(themeId, success)
  }

  getArticles() {
    const {actions} = this.props
    const {themeId} = this.props.params
    const succeed = ({response}) => {
      this.setState({
        data: response.data.artList,
        total: response.data.amount,
        init: true
      })
    }
    actions.getArticlesByTheme({themeId}, succeed)
  }
  showLoginToast = () => {
    const {globalActions} = this.props
    globalActions.addToast({
      type: 'singleMsg',
      message: '请先登录',
      timeout: 2000
    })
  }
  openArticleModal = () => {
    const {articleActions, auth, globalActions} = this.props
    if (!auth.get('id')) {
      return this.showLoginToast()
    }
    
    // check pro
    if (auth.get('userType') === '0') {
      return globalActions.showUpgradeTips()
    }
    
    articleActions.resetArticle()
    articleActions.openArticleWindow()
  }
  render() {
    const {user, userId} = this.props
    const {init} = this.state
    if (!init) {
      return null
    }
    const newtopic = sessionStorage.getItem('newtopic');
    const isSelf = user.getIn(['userInfo', 'ownerId']) === userId
    const noCardStyle = isSelf? {display: 'inline-block', margin: '110px 235px'}: {};
    const items = fromJS(this.state.data)
    const tips = (<div className="m-topic-wall">
                    {
                      isSelf || newtopic?
                      <div className="card__wrap" onClick={this.openArticleModal}>
                        <div className="photo__wrap">
                          <div className="photo__main photo__main--add">
                            <div className="photo__add">
                              <div className="icon icon-add-white" />
                            </div>
                            <div className="photo__text">创建手帖</div>
                          </div>
                        </div>
                      </div>:
                      null

                    }
                    <div className="no-cards" style={noCardStyle}>该主题暂无手贴</div>
                  </div>)
    // 
    const {theme, total} = this.state
    return (
      <div className="m-user m-user-new m-header--wrap">
        <Header />
        <UpgradeTips width={1030}/>
        <UserTopicHeader theme={theme} total={total} />
        <div className="user-oasis m-topic-wall">
          <Waterfall
            cards={items}
            type={this.state.type}
            showUnCollect={isSelf}
            location={this.props.location}
            column={4}
          />
          {items.size < 1 ? tips : null}
        </div>
        <CornerBar />
      </div>
    )
  }
}

const mapStateToProps = state => ({
  subject: state.subject,
  article: state.article,
  auth: state.auth,
  user: state.user,
  userId: state.auth.get('id')
})

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators(actions, dispatch),
  subjectActions: bindActionCreators(subjectActions, dispatch),
  articleActions: bindActionCreators(articleActions, dispatch),
  globalActions: bindActionCreators(globalActions, dispatch)
})

export default connect(mapStateToProps, mapDispatchToProps)(UserTopic)
