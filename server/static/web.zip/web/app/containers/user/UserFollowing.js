import React, { Component, PropTypes } from 'react'
import {bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import UserList from 'components/UserList'
import TypeNav from 'components/TypeNav'
import * as userActions from 'actions/user'

class UserFollowing extends Component {
  constructor(props) {
    super(props)
    this.state = {
      type: 0
    }
  }
  componentDidMount() {
    const user = this.props.user
    if (!user.get('followingInit')) {
      this._loadData(this.state.type)
    }
  }
  componentWillUnmount() {
    this.props.actions.clearUserInfo()
  }
  _loadData(type) {
    const user = this.props.user
    this.props.actions.getFollowing({
      ownerid: user.getIn(['userInfo', 'ownerId']),
      sortid: -1,
      attentiontype: type
    })
  }
  _changeType(type) {
    this._loadData(type)
    this.setState({
      type
    })
  }
  render() {
    if (!this.props.user.get('followingInit')) {
      return null
    }
    const items = this.props.user.getIn(['following', 'userList']).toJS()
    const isSelf = this.props.auth.get('id') == this.props.user.getIn(['userInfo', 'ownerId'])
    return (
      <div className="user-following">
        <TypeNav type={this.state.type} mode="following"
                 onChange={this._changeType.bind(this)} />
        <UserList items={items}
                  tips="还没有添加任何关注。"
                  showCancelButton={isSelf} />
      </div>
    )
  }
}

function mapStateToProps (state) {
  return {
    user: state.user,
    auth: state.auth,
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({
      getFollowing: userActions.getFollowing,
      clearUserInfo: userActions.clearUserInfo
    }, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(UserFollowing)
