/**
 * 获取用户资料完成之前，在页面最上层显示loading动效
 */

import React, {Component, PropTypes} from 'react'

class Loading extends Component {
  render() {
    if (!this.props.isOpen) {
      return null
    }
    return (
      <div className="m-loading">
        <div className="mask"></div>
        <div className="icon icon-loading"></div>
      </div>
    )
  }
}

Loading.propTypes = {
  isOpen: PropTypes.bool
}

Loading.defaultProps = {
  isOpen: false
}

export default Loading