export const local = {
  get: function(name) {
    const res = localStorage.getItem(name)
    if(res) {
      return JSON.parse(res)
    } else {
      return null
    }
  },
  set: function(name, jsonObj) {
    localStorage.setItem(name, JSON.stringify(jsonObj))
  },
  remove: function(name) {
    localStorage.removeItem(name)
  }
}

const localKey = 'searchHistory'

export const getSearchHistory = () => {
  let searchHistory = local.get(localKey)
  if(!searchHistory) return []
  return searchHistory
}

export const addSearchHistory = (word, queueMaxLen=10) => {
  let searchHistory = local.get(localKey)
  searchHistory = searchHistory? searchHistory: []

  searchHistory.unshift(word)
  searchHistory = [...new Set(searchHistory)] //去重
  if (searchHistory.length >= queueMaxLen) {
    searchHistory.pop()
  }

  local.set(localKey, searchHistory)
}
