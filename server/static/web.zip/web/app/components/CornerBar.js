import React from 'react'
import enhanceWithClickOutside from 'react-click-outside'
import SubjectCreationModal from 'components/corner-bar/SubjectCreationModal'
import ArticleCreationModal from 'components/corner-bar/ArticleCreationModal'
import {connect} from 'react-redux'
import {bindActionCreators} from 'redux'
import * as subjectActions from 'actions/subject'
import * as articleActions from 'actions/article'
import * as globalActions from 'actions/global'

class CornerBar extends React.Component {
  state = {
    popoverIsOpen: false
  }

  handleClickOutside() {
    this.setState({
      popoverIsOpen: false
    })
  }

  scrollTop = () => {
    window.scrollTo(0, 0)
  }
  
  showLoginToast = () => {
    const {globalActions} = this.props
    globalActions.addToast({
      type: 'singleMsg',
      message: '请先登录',
      timeout: 2000
    })
  }

  openSubjectModal = () => {
    this.setState({popoverIsOpen: false})
    const {actions, auth, globalActions} = this.props
    if (!auth.get('id')) {
      return this.showLoginToast()
    }

    // check pro
    if (auth.get('userType') === '0') {
      return globalActions.showUpgradeTips()
    }
    actions.openSubjectWindow()
  }
  
  openArticleModal = () => {
    this.setState({popoverIsOpen: false})
    const {articleActions, auth, globalActions} = this.props
    if (!auth.get('id')) {
      return this.showLoginToast()
    }
    
    // check pro
    if (auth.get('userType') === '0') {
      return globalActions.showUpgradeTips()
    }
    
    articleActions.resetArticle()
    articleActions.openArticleWindow()
  }
  
  togglePopover = () => {
    this.setState({
      popoverIsOpen: !this.state.popoverIsOpen
    })
  }

  render() {
    const {popoverIsOpen} = this.state
    return (
      <div className="m-corner">
        <span
          className="icon icon-add clickable"
          onClick={this.togglePopover}
        />
        <span className="icon icon-top clickable" onClick={this.scrollTop} />
        {popoverIsOpen &&
          <div className="popover-wrapper">
            <div className="m-popover">
              <div className="popover-inner">
                <ul className="corner-add">
                  <li className="item" onClick={this.openSubjectModal}>
                    创建主题
                  </li>
                  <li className="item" onClick={this.openArticleModal}>
                    发布手贴
                  </li>
                </ul>
              </div>
            </div>
          </div>}
        <SubjectCreationModal />
        <ArticleCreationModal />
      </div>
    )
  }
}

const mapStateToProps = state => ({
  subject: state.subject,
  article: state.article,
  auth: state.auth
})

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators(subjectActions, dispatch),
  articleActions: bindActionCreators(articleActions, dispatch),
  globalActions: bindActionCreators(globalActions, dispatch)
})

export default connect(mapStateToProps, mapDispatchToProps)(
  enhanceWithClickOutside(CornerBar)
)
