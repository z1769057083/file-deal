import * as ActionType from 'actions/register'
import {fromJS} from 'immutable'

let defaultState = fromJS({
  code: '',
  codeVerified: false,
  phone: '',
  success: false,
  // Forget Password Variables
  forgetPhone: '',
  forgetCode: '',
  // Team register
  teamEmail: '',
  teamPwd: '',

  // Team retrieve password
  forgetEmail: '',
})
function registerReducer(state = defaultState, action) {
  switch (action.type) {
    case ActionType.SEND_CODE_FOR_REGISTER:
      return state.set('code', '')
    case ActionType.SEND_CODE_FOR_PASSWORD:
      return state.set('forgetCode', '')
    case ActionType.VERIFY_CODE_REGISTER:
      return state.set('codeVerified', true)
    case ActionType.REGISTER:
      return state.set('success', true)
    case ActionType.UPDATE_CODE:
      return state.set('code', action.code)
    case ActionType.UPDATE_PHONE:
      return state.set('phone', action.phone)
    case ActionType.UPDATE_CODE_PASSWORD:
      return state.set('forgetCode', action.code)
    case ActionType.UPDATE_PHONE_PASSWORD:
      return state.set('forgetPhone', action.phone)
    case ActionType.RESET_PWD:
      return state
    case ActionType.TEAM_REGISTER:
      return state
    case ActionType.UPDATE_TEAM_EMAIL:
      return state.set('teamEmail', action.email)
    case ActionType.UPDATE_TEAM_EMAIL_PWD:
      return state.set('teamEmail', action.email).set('teamPwd', action.pwd)

    case ActionType.UPDATE_TEAM_FORGET_EMAIL:
      return state.set('forgetEmail', action.email)
    default:
      return state
  }
}

export default registerReducer